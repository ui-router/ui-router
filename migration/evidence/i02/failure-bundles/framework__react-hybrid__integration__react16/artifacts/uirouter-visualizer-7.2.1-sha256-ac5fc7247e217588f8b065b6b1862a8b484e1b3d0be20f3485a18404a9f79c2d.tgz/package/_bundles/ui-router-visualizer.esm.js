//#region ../../node_modules/preact/dist/preact.module.js
var n$1;
var l;
var u;
var i;
var r;
var o;
var e$1;
var f;
var c;
var a;
var s;
var h;
var p;
var v;
var d = {};
var w = [];
var _ = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
var g = Array.isArray;
function m(n, l) {
	for (var u in l) n[u] = l[u];
	return n;
}
function b(n) {
	n && n.parentNode && n.parentNode.removeChild(n);
}
function k(l, u, t) {
	var i, r, o, e = {};
	for (o in u) "key" == o ? i = u[o] : "ref" == o ? r = u[o] : e[o] = u[o];
	if (arguments.length > 2 && (e.children = arguments.length > 3 ? n$1.call(arguments, 2) : t), "function" == typeof l && null != l.defaultProps) for (o in l.defaultProps) void 0 === e[o] && (e[o] = l.defaultProps[o]);
	return x(l, e, i, r, null);
}
function x(n, t, i, r, o) {
	var e = {
		type: n,
		props: t,
		key: i,
		ref: r,
		__k: null,
		__: null,
		__b: 0,
		__e: null,
		__c: null,
		constructor: void 0,
		__v: null == o ? ++u : o,
		__i: -1,
		__u: 0
	};
	return null == o && null != l.vnode && l.vnode(e), e;
}
function S(n) {
	return n.children;
}
function C(n, l) {
	this.props = n, this.context = l;
}
function $(n, l) {
	if (null == l) return n.__ ? $(n.__, n.__i + 1) : null;
	for (var u; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) return u.__e;
	return "function" == typeof n.type ? $(n) : null;
}
function I(n) {
	if (n.__P && n.__d) {
		var u = n.__v, t = u.__e, i = [], r = [], o = m({}, u);
		o.__v = u.__v + 1, l.vnode && l.vnode(o), q(n.__P, o, u, n.__n, n.__P.namespaceURI, 32 & u.__u ? [t] : null, i, null == t ? $(u) : t, !!(32 & u.__u), r), o.__v = u.__v, o.__.__k[o.__i] = o, D(i, o, r), u.__e = u.__ = null, o.__e != t && P(o);
	}
}
function P(n) {
	if (null != (n = n.__) && null != n.__c) return n.__e = n.__c.base = null, n.__k.some(function(l) {
		if (null != l && null != l.__e) return n.__e = n.__c.base = l.__e;
	}), P(n);
}
function A(n) {
	(!n.__d && (n.__d = !0) && i.push(n) && !H.__r++ || r != l.debounceRendering) && ((r = l.debounceRendering) || o)(H);
}
function H() {
	try {
		for (var n, l = 1; i.length;) i.length > l && i.sort(e$1), n = i.shift(), l = i.length, I(n);
	} finally {
		i.length = H.__r = 0;
	}
}
function L(n, l, u, t, i, r, o, e, f, c, a) {
	var s, h, p, v, y, _, g = t && t.__k || w, m = l.length;
	for (f = T(u, l, g, f, m), s = 0; s < m; s++) null != (p = u.__k[s]) && (h = -1 != p.__i && g[p.__i] || d, p.__i = s, _ = q(n, p, h, i, r, o, e, f, c, a), v = p.__e, p.ref && h.ref != p.ref && (h.ref && J(h.ref, null, p), a.push(p.ref, p.__c || v, p)), null == y && null != v && (y = v), 4 & p.__u ? (f = j(p, f, n), h.__e && (h.__e = null)) : "function" == typeof p.type && void 0 !== _ ? f = _ : v && (f = v.nextSibling), p.__u &= -7);
	return u.__e = y, f;
}
function T(n, l, u, t, i) {
	var r, o, e, f, c, a = u.length, s = a, h = 0;
	for (n.__k = new Array(i), r = 0; r < i; r++) null != (o = l[r]) && "boolean" != typeof o && "function" != typeof o ? ("string" == typeof o || "number" == typeof o || "bigint" == typeof o || o.constructor == String ? o = n.__k[r] = x(null, o, null, null, null) : g(o) ? o = n.__k[r] = x(S, { children: o }, null, null, null) : void 0 === o.constructor && o.__b > 0 ? o = n.__k[r] = x(o.type, o.props, o.key, o.ref ? o.ref : null, o.__v) : n.__k[r] = o, f = r + h, o.__ = n, o.__b = n.__b + 1, e = null, -1 != (c = o.__i = O(o, u, f, s)) && (s--, (e = u[c]) && (e.__u |= 2)), null == e || null == e.__v ? (-1 == c && (i > a ? h-- : i < a && h++), "function" != typeof o.type && (o.__u |= 4)) : c != f && (c == f - 1 ? h-- : c == f + 1 ? h++ : (c > f ? h-- : h++, o.__u |= 4))) : n.__k[r] = null;
	if (s) for (r = 0; r < a; r++) null != (e = u[r]) && 0 == (2 & e.__u) && (e.__e == t && (t = $(e)), K(e, e));
	return t;
}
function j(n, l, u) {
	var t, i;
	if ("function" == typeof n.type) {
		for (t = n.__k, i = 0; t && i < t.length; i++) t[i] && (t[i].__ = n, l = j(t[i], l, u));
		return l;
	}
	n.__e != l && (l && n.type && !l.parentNode && (l = $(n)), l = u.insertBefore(n.__e, l || null));
	do
		l = l && l.nextSibling;
	while (null != l && 8 == l.nodeType);
	return l;
}
function O(n, l, u, t) {
	var i, r, o, e = n.key, f = n.type, c = l[u], a = null != c && 0 == (2 & c.__u);
	if (null === c && null == e || a && e == c.key && f == c.type) return u;
	if (t > (a ? 1 : 0)) {
		for (i = u - 1, r = u + 1; i >= 0 || r < l.length;) if (null != (c = l[o = i >= 0 ? i-- : r++]) && 0 == (2 & c.__u) && e == c.key && f == c.type) return o;
	}
	return -1;
}
function z(n, l, u) {
	"-" == l[0] ? n.setProperty(l, null == u ? "" : u) : n[l] = null == u ? "" : "number" != typeof u || _.test(l) ? u : u + "px";
}
function N(n, l, u, t, i) {
	var r, o;
	n: if ("style" == l) if ("string" == typeof u) n.style.cssText = u;
	else {
		if ("string" == typeof t && (n.style.cssText = t = ""), t) for (l in t) u && l in u || z(n.style, l, "");
		if (u) for (l in u) t && u[l] == t[l] || z(n.style, l, u[l]);
	}
	else if ("o" == l[0] && "n" == l[1]) r = l != (l = l.replace(s, "$1")), o = l.toLowerCase(), l = o in n || "onFocusOut" == l || "onFocusIn" == l ? o.slice(2) : l.slice(2), n.l || (n.l = {}), n.l[l + r] = u, u ? t ? u[a] = t[a] : (u[a] = h, n.addEventListener(l, r ? v : p, r)) : n.removeEventListener(l, r ? v : p, r);
	else {
		if ("http://www.w3.org/2000/svg" == i) l = l.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
		else if ("width" != l && "height" != l && "href" != l && "list" != l && "form" != l && "tabIndex" != l && "download" != l && "rowSpan" != l && "colSpan" != l && "role" != l && "popover" != l && l in n) try {
			n[l] = null == u ? "" : u;
			break n;
		} catch (n) {}
		"function" == typeof u || (null == u || !1 === u && "-" != l[4] ? n.removeAttribute(l) : n.setAttribute(l, "popover" == l && 1 == u ? "" : u));
	}
}
function V(n) {
	return function(u) {
		if (this.l) {
			var t = this.l[u.type + n];
			if (null == u[c]) u[c] = h++;
			else if (u[c] < t[a]) return;
			return t(l.event ? l.event(u) : u);
		}
	};
}
function q(n, u, t, i, r, o, e, f, c, a) {
	var s, h, p, v, y, d, _, k, x, M, I, P, A, H, T, j, F = u.type;
	if (void 0 !== u.constructor) return null;
	128 & t.__u && (c = !!(32 & t.__u), o = [f = u.__e = t.__e]), (s = l.__b) && s(u);
	n: if ("function" == typeof F) {
		h = e.length;
		try {
			if (x = u.props, M = F.prototype && F.prototype.render, I = (s = F.contextType) && i[s.__c], P = s ? I ? I.props.value : s.__ : i, t.__c ? k = (p = u.__c = t.__c).__ = p.__E : (M ? u.__c = p = new F(x, P) : (u.__c = p = new C(x, P), p.constructor = F, p.render = Q), I && I.sub(p), p.state || (p.state = {}), p.__n = i, v = p.__d = !0, p.__h = [], p._sb = []), M && null == p.__s && (p.__s = p.state), M && null != F.getDerivedStateFromProps && (p.__s == p.state && (p.__s = m({}, p.__s)), m(p.__s, F.getDerivedStateFromProps(x, p.__s))), y = p.props, d = p.state, p.__v = u, v) M && null == F.getDerivedStateFromProps && null != p.componentWillMount && p.componentWillMount(), M && null != p.componentDidMount && p.__h.push(p.componentDidMount);
			else {
				if (M && null == F.getDerivedStateFromProps && x !== y && null != p.componentWillReceiveProps && p.componentWillReceiveProps(x, P), u.__v == t.__v || !p.__e && null != p.shouldComponentUpdate && !1 === p.shouldComponentUpdate(x, p.__s, P)) {
					u.__v != t.__v && (p.props = x, p.state = p.__s, p.__d = !1), u.__e = t.__e, u.__k = t.__k, u.__k.some(function(n) {
						n && (n.__ = u);
					}), w.push.apply(p.__h, p._sb), p._sb = [], p.__h.length && e.push(p), f = $(t);
					break n;
				}
				null != p.componentWillUpdate && p.componentWillUpdate(x, p.__s, P), M && null != p.componentDidUpdate && p.__h.push(function() {
					p.componentDidUpdate(y, d, _);
				});
			}
			if (p.context = P, p.props = x, p.__P = n, p.__e = !1, A = l.__r, H = 0, M) p.state = p.__s, p.__d = !1, A && A(u), s = p.render(p.props, p.state, p.context), w.push.apply(p.__h, p._sb), p._sb = [];
			else do
				p.__d = !1, A && A(u), s = p.render(p.props, p.state, p.context), p.state = p.__s;
			while (p.__d && ++H < 25);
			p.state = p.__s, null != p.getChildContext && (i = m(m({}, i), p.getChildContext())), M && !v && null != p.getSnapshotBeforeUpdate && (_ = p.getSnapshotBeforeUpdate(y, d)), T = null != s && s.type === S && null == s.key ? E(s.props.children) : s, f = L(n, g(T) ? T : [T], u, t, i, r, o, e, f, c, a), p.base = u.__e, u.__u &= -161, p.__h.length && e.push(p), k && (p.__E = p.__ = null);
		} catch (n) {
			if (e.length = h, u.__v = null, c || null != o) {
				if (n.then) {
					for (u.__u |= c ? 160 : 128; f && 8 == f.nodeType && f.nextSibling;) f = f.nextSibling;
					null != o && (o[o.indexOf(f)] = null), u.__e = f;
				} else if (null != o) for (j = o.length; j--;) b(o[j]);
			} else u.__e = t.__e;
			u.__k ??= t.__k || [], n.then || B(u), l.__e(n, u, t);
		}
	} else null == o && u.__v == t.__v ? (u.__k = t.__k, u.__e = t.__e) : f = u.__e = G(t.__e, u, t, i, r, o, e, c, a);
	return (s = l.diffed) && s(u), 128 & u.__u ? void 0 : f;
}
function B(n) {
	n && (n.__c && (n.__c.__e = !0), n.__k && n.__k.some(B));
}
function D(n, u, t) {
	for (var i = 0; i < t.length; i++) J(t[i], t[++i], t[++i]);
	l.__c && l.__c(u, n), n.some(function(u) {
		try {
			n = u.__h, u.__h = [], n.some(function(n) {
				n.call(u);
			});
		} catch (n) {
			l.__e(n, u.__v);
		}
	});
}
function E(n) {
	return "object" != typeof n || null == n || n.__b > 0 ? n : g(n) ? n.map(E) : void 0 !== n.constructor ? null : m({}, n);
}
function G(u, t, i, r, o, e, f, c, a) {
	var s, h, p, v, y, w, _, m = i.props || d, k = t.props, x = t.type;
	if ("svg" == x ? o = "http://www.w3.org/2000/svg" : "math" == x ? o = "http://www.w3.org/1998/Math/MathML" : o || (o = "http://www.w3.org/1999/xhtml"), null != e) {
		for (s = 0; s < e.length; s++) if ((y = e[s]) && "setAttribute" in y == !!x && (x ? y.localName == x : 3 == y.nodeType)) {
			u = y, e[s] = null;
			break;
		}
	}
	if (null == u) {
		if (null == x) return document.createTextNode(k);
		u = document.createElementNS(o, x, k.is && k), c && (l.__m && l.__m(t, e), c = !1), e = null;
	}
	if (null == x) m === k || c && u.data == k || (u.data = k);
	else {
		if (e = "textarea" == x && null != k.defaultValue ? null : e && n$1.call(u.childNodes), !c && null != e) for (m = {}, s = 0; s < u.attributes.length; s++) m[(y = u.attributes[s]).name] = y.value;
		for (s in m) y = m[s], "dangerouslySetInnerHTML" == s ? p = y : "children" == s || s in k || "value" == s && "defaultValue" in k || "checked" == s && "defaultChecked" in k || N(u, s, null, y, o);
		for (s in k) y = k[s], "children" == s ? v = y : "dangerouslySetInnerHTML" == s ? h = y : "value" == s ? w = y : "checked" == s ? _ = y : c && "function" != typeof y || m[s] === y || N(u, s, y, m[s], o);
		if (h) c || p && (h.__html == p.__html || h.__html == u.innerHTML) || (u.innerHTML = h.__html), t.__k = [];
		else if (p && (u.innerHTML = ""), L("template" == t.type ? u.content : u, g(v) ? v : [v], t, i, r, "foreignObject" == x ? "http://www.w3.org/1999/xhtml" : o, e, f, e ? e[0] : i.__k && $(i, 0), c, a), null != e) for (s = e.length; s--;) b(e[s]);
		c && "textarea" != x || (s = "value", "progress" == x && null == w ? u.removeAttribute("value") : null != w && (w !== u[s] || "progress" == x && !w || "option" == x && w != m[s]) && N(u, s, w, m[s], o), s = "checked", null != _ && _ != u[s] && N(u, s, _, m[s], o));
	}
	return u;
}
function J(n, u, t) {
	try {
		if ("function" == typeof n) {
			var i = "function" == typeof n.__u;
			i && n.__u(), i && null == u || (n.__u = n(u));
		} else n.current = u;
	} catch (n) {
		l.__e(n, t);
	}
}
function K(n, u, t) {
	var i, r;
	if (l.unmount && l.unmount(n), (i = n.ref) && (i.current && i.current != n.__e || J(i, null, u)), null != (i = n.__c)) {
		if (i.componentWillUnmount) try {
			i.componentWillUnmount();
		} catch (n) {
			l.__e(n, u);
		}
		i.base = i.__P = i.__n = null;
	}
	if (i = n.__k) for (r = 0; r < i.length; r++) i[r] && K(i[r], u, t || "function" != typeof n.type);
	t || b(n.__e), n.__c = n.__ = n.__e = void 0;
}
function Q(n, l, u) {
	return this.constructor(n, u);
}
function R(u, t, i) {
	var r, o, e, f;
	t == document && (t = document.documentElement), l.__ && l.__(u, t), o = (r = "function" == typeof i) ? null : i && i.__k || t.__k, e = [], f = [], q(t, u = (!r && i || t).__k = k(S, null, [u]), o || d, d, t.namespaceURI, !r && i ? [i] : o ? null : t.firstChild ? n$1.call(t.childNodes) : null, e, !r && i ? i : o ? o.__e : t.firstChild, r, f), D(e, u, f), u.props.children = null;
}
n$1 = w.slice, l = { __e: function(n, l, u, t) {
	for (var i, r, o; l = l.__;) if ((i = l.__c) && !i.__) try {
		if ((r = i.constructor) && null != r.getDerivedStateFromError && (i.setState(r.getDerivedStateFromError(n)), o = i.__d), null != i.componentDidCatch && (i.componentDidCatch(n, t || {}), o = i.__d), o) return i.__E = i;
	} catch (l) {
		n = l;
	}
	throw n;
} }, u = 0, C.prototype.setState = function(n, l) {
	var u = null != this.__s && this.__s != this.state ? this.__s : this.__s = m({}, this.state);
	"function" == typeof n && (n = n(m({}, u), this.props)), n && m(u, n), null != n && this.__v && (l && this._sb.push(l), A(this));
}, C.prototype.forceUpdate = function(n) {
	this.__v && (this.__e = !0, n && this.__h.push(n), A(this));
}, C.prototype.render = S, i = [], o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, e$1 = function(n, l) {
	return n.__v.__b - l.__v.__b;
}, H.__r = 0, f = Math.random().toString(8), c = "__d" + f, a = "__a" + f, s = /(PointerCapture)$|Capture$/i, h = 0, p = V(!1), v = V(!0);
//#endregion
//#region src/selector/StateSelector.tsx
var StateSelector = class extends C {
	constructor(..._args) {
		super(..._args);
		this.state = {
			current: null,
			states: [],
			deregisterFn: null
		};
		this.selectState = (event) => {
			let $state = this.props.router.stateService;
			var to = event.target.value;
			if (to) $state.go(to);
		};
	}
	componentDidMount() {
		let router = this.props.router;
		const updateStates = () => this.setState({ states: router.stateRegistry.get().map((state) => state.name) });
		const updateCurrent = (trans) => this.setState({ current: trans.to().name });
		if (router.stateRegistry.onStatesChanged) this.deregisterStateListenerFn = router.stateRegistry.onStatesChanged(updateStates);
		let deregisterFn = router.transitionService.onSuccess({}, updateCurrent);
		this.setState({
			current: router.globals.current.name,
			states: [],
			deregisterFn
		});
		updateStates();
	}
	componentWillUnmount() {
		if (this.state.deregisterFn) this.state.deregisterFn();
		if (this.deregisterStateListenerFn) this.deregisterStateListenerFn();
	}
	render() {
		return /* @__PURE__ */ k("select", {
			value: this.state.current || "",
			onChange: this.selectState,
			style: { maxWidth: 120 }
		}, /* @__PURE__ */ k("option", { value: "" }, "Choose a state"), this.state.states.map((state) => /* @__PURE__ */ k("option", {
			key: state,
			value: state
		}, state)));
	}
};
//#endregion
//#region src/util/toggleClass.ts
const hasClass = (classname) => (el) => !!new RegExp(`\\b${classname}\\b`).exec(el.className);
const addClass = (classname) => (el) => el.className = el.className + " " + classname;
const removeClass = (classname) => (el) => el.className = el.className.replace(new RegExp(`\\b${classname}\\b`, "g"), "");
const toggleClass = (classname) => (el) => {
	if (hasClass(classname)(el)) removeClass(classname)(el);
	else addClass(classname)(el);
};
//#endregion
//#region src/util/draggable.ts
const moveElement = (elementToMove) => function _moveElement(elementBeingDragged, event, details) {
	let { initialClientX, initialClientY, lastClientX, lastClientY, newClientX, newClientY } = details;
	let el = elementToMove;
	let { left, top } = el.getBoundingClientRect();
	let dx = newClientX - lastClientX;
	let dy = newClientY - lastClientY;
	el.style.right = "auto";
	el.style.bottom = "auto";
	el.style.left = left + dx + "px";
	el.style.top = top + dy + "px";
};
const dragActions = { move: moveElement };
function draggable(el, callback) {
	let isDragging = false;
	let initialClientX = 0, initialClientY = 0;
	let lastClientX = 0, lastClientY = 0;
	const mouseDownListener = (e) => {
		isDragging = true;
		lastClientX = initialClientX = e.clientX;
		lastClientY = initialClientY = e.clientY;
		const dragListener = (e) => {
			if (!isDragging) return;
			e.preventDefault();
			let newClientX = e.clientX, newClientY = e.clientY;
			callback(el, e, {
				initialClientX,
				initialClientY,
				lastClientX,
				lastClientY,
				newClientX,
				newClientY
			});
			lastClientX = newClientX;
			lastClientY = newClientY;
		};
		const doneDragging = (e) => {
			isDragging = false;
			document.removeEventListener("mousemove", dragListener);
			document.removeEventListener("mouseup", doneDragging);
		};
		document.addEventListener("mousemove", dragListener);
		document.addEventListener("mouseup", doneDragging);
	};
	addClass("draggable")(el);
	el.addEventListener("mousedown", mouseDownListener);
	return () => el.removeEventListener("mousedown", mouseDownListener);
}
//#endregion
//#region src/statevis/tree/StateNode.tsx
var StateNode = class extends C {
	constructor(..._args) {
		super(..._args);
		this.goTimeout = null;
		this.handleCollapseClicked = () => {
			clearTimeout(this.goTimeout);
			this.props.node._collapsed = !this.props.node._collapsed;
			this.props.doLayout();
		};
		this.handleGoClicked = () => {
			clearTimeout(this.goTimeout);
			let stateName = this.props.node.name;
			stateName = stateName.replace(/\.\*\*$/, "");
			this.goTimeout = setTimeout(() => this.props.router.stateService.go(stateName), 200);
		};
	}
	render() {
		let renderer = this.props.renderer;
		let { node, x, y, nodeOptions } = this.props;
		let { baseRadius, baseFontSize, baseNodeStrokeWidth, zoom } = renderer;
		let r = baseRadius * zoom;
		let fontSize = baseFontSize * zoom;
		let nodeStrokeWidth = baseNodeStrokeWidth * (node.entered ? 1.5 : 1) * zoom;
		let defaultClasses = [
			"entered",
			"retained",
			"exited",
			"active",
			"inactive",
			"future",
			"highlight",
			"collapsed"
		].filter((clazz) => node[clazz]).join(" ");
		let nodeClasses = nodeOptions && nodeOptions.classes ? nodeOptions.classes(node) : "";
		let circleClasses = defaultClasses + " " + nodeClasses;
		let descendents = node.collapsed ? node.totalDescendents : 0;
		return /* @__PURE__ */ k("g", {
			transform: `translate(${x}, ${y})`,
			onClick: this.handleGoClicked,
			onDblClick: this.handleCollapseClicked
		}, /* @__PURE__ */ k("circle", {
			className: circleClasses,
			"stroke-width": nodeStrokeWidth,
			r
		}), !node.collapsed ? "" : /* @__PURE__ */ k("text", {
			className: "label",
			"text-anchor": "middle",
			"font-size": fontSize * (descendents < 10 ? 1 : .8)
		}, "(", descendents, ")"), renderer.labelRenderFn(x, y, node, nodeOptions, renderer), /* @__PURE__ */ k("text", {
			className: "label",
			"text-anchor": "middle",
			"font-size": fontSize,
			transform: `translate(0, ${r * 2})`
		}, node.label));
	}
};
//#endregion
//#region src/util/easing.ts
const easing = {
	easeInOutQuad: function(t, b, c, d) {
		if ((t /= d / 2) < 1) return c / 2 * t * t + b;
		return -c / 2 * (--t * (t - 2) - 1) + b;
	},
	easeInOutCubic: function(t, b, c, d) {
		if ((t /= d / 2) < 1) return c / 2 * t * t * t + b;
		return c / 2 * ((t -= 2) * t * t + 2) + b;
	},
	easeInOutQuart: function(t, b, c, d) {
		if ((t /= d / 2) < 1) return c / 2 * t * t * t * t + b;
		return -c / 2 * ((t -= 2) * t * t * t - 2) + b;
	},
	easeInOutQuint: function(t, b, c, d) {
		if ((t /= d / 2) < 1) return c / 2 * t * t * t * t * t + b;
		return c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
	},
	easeInOutSine: function(t, b, c, d) {
		return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
	},
	easeInOutExpo: function(t, b, c, d) {
		if (t == 0) return b;
		if (t == d) return b + c;
		if ((t /= d / 2) < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
		return c / 2 * (-Math.pow(2, -10 * --t) + 2) + b;
	},
	easeInOutCirc: function(t, b, c, d) {
		if ((t /= d / 2) < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
		return c / 2 * (Math.sqrt(1 - (t -= 2) * t) + 1) + b;
	},
	easeInElastic: function(t, b, c, d) {
		var s = 1.70158;
		var p = 0;
		var a = c;
		if (t == 0) return b;
		if ((t /= d) == 1) return b + c;
		if (!p) p = d * .3;
		if (a < Math.abs(c)) {
			a = c;
			var s = p / 4;
		} else var s = p / (2 * Math.PI) * Math.asin(c / a);
		return -(a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
	},
	easeOutElastic: function(t, b, c, d) {
		var s = 1.70158;
		var p = 0;
		var a = c;
		if (t == 0) return b;
		if ((t /= d) == 1) return b + c;
		if (!p) p = d * .3;
		if (a < Math.abs(c)) {
			a = c;
			var s = p / 4;
		} else var s = p / (2 * Math.PI) * Math.asin(c / a);
		return a * Math.pow(2, -10 * t) * Math.sin((t * d - s) * (2 * Math.PI) / p) + c + b;
	},
	easeInOutElastic: function(t, b, c, d) {
		var s = 1.70158;
		var p = 0;
		var a = c;
		if (t == 0) return b;
		if ((t /= d / 2) == 2) return b + c;
		if (!p) p = d * (.3 * 1.5);
		if (a < Math.abs(c)) {
			a = c;
			var s = p / 4;
		} else var s = p / (2 * Math.PI) * Math.asin(c / a);
		if (t < 1) return -.5 * (a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
		return a * Math.pow(2, -10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p) * .5 + c + b;
	},
	easeInOutBack: function(t, b, c, d, s) {
		if (s == void 0) s = 1.70158;
		if ((t /= d / 2) < 1) return c / 2 * (t * t * (((s *= 1.525) + 1) * t - s)) + b;
		return c / 2 * ((t -= 2) * t * (((s *= 1.525) + 1) * t + s) + 2) + b;
	}
};
//#endregion
//#region ../../node_modules/d3-color/src/define.js
function define_default(constructor, factory, prototype) {
	constructor.prototype = factory.prototype = prototype;
	prototype.constructor = constructor;
}
function extend(parent, definition) {
	var prototype = Object.create(parent.prototype);
	for (var key in definition) prototype[key] = definition[key];
	return prototype;
}
//#endregion
//#region ../../node_modules/d3-color/src/color.js
function Color() {}
var darker = .7;
var brighter = 1 / darker;
var reI = "\\s*([+-]?\\d+)\\s*";
var reN = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*";
var reP = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*";
var reHex = /^#([0-9a-f]{3,8})$/;
var reRgbInteger = new RegExp(`^rgb\\(${reI},${reI},${reI}\\)$`);
var reRgbPercent = new RegExp(`^rgb\\(${reP},${reP},${reP}\\)$`);
var reRgbaInteger = new RegExp(`^rgba\\(${reI},${reI},${reI},${reN}\\)$`);
var reRgbaPercent = new RegExp(`^rgba\\(${reP},${reP},${reP},${reN}\\)$`);
var reHslPercent = new RegExp(`^hsl\\(${reN},${reP},${reP}\\)$`);
var reHslaPercent = new RegExp(`^hsla\\(${reN},${reP},${reP},${reN}\\)$`);
var named = {
	aliceblue: 15792383,
	antiquewhite: 16444375,
	aqua: 65535,
	aquamarine: 8388564,
	azure: 15794175,
	beige: 16119260,
	bisque: 16770244,
	black: 0,
	blanchedalmond: 16772045,
	blue: 255,
	blueviolet: 9055202,
	brown: 10824234,
	burlywood: 14596231,
	cadetblue: 6266528,
	chartreuse: 8388352,
	chocolate: 13789470,
	coral: 16744272,
	cornflowerblue: 6591981,
	cornsilk: 16775388,
	crimson: 14423100,
	cyan: 65535,
	darkblue: 139,
	darkcyan: 35723,
	darkgoldenrod: 12092939,
	darkgray: 11119017,
	darkgreen: 25600,
	darkgrey: 11119017,
	darkkhaki: 12433259,
	darkmagenta: 9109643,
	darkolivegreen: 5597999,
	darkorange: 16747520,
	darkorchid: 10040012,
	darkred: 9109504,
	darksalmon: 15308410,
	darkseagreen: 9419919,
	darkslateblue: 4734347,
	darkslategray: 3100495,
	darkslategrey: 3100495,
	darkturquoise: 52945,
	darkviolet: 9699539,
	deeppink: 16716947,
	deepskyblue: 49151,
	dimgray: 6908265,
	dimgrey: 6908265,
	dodgerblue: 2003199,
	firebrick: 11674146,
	floralwhite: 16775920,
	forestgreen: 2263842,
	fuchsia: 16711935,
	gainsboro: 14474460,
	ghostwhite: 16316671,
	gold: 16766720,
	goldenrod: 14329120,
	gray: 8421504,
	green: 32768,
	greenyellow: 11403055,
	grey: 8421504,
	honeydew: 15794160,
	hotpink: 16738740,
	indianred: 13458524,
	indigo: 4915330,
	ivory: 16777200,
	khaki: 15787660,
	lavender: 15132410,
	lavenderblush: 16773365,
	lawngreen: 8190976,
	lemonchiffon: 16775885,
	lightblue: 11393254,
	lightcoral: 15761536,
	lightcyan: 14745599,
	lightgoldenrodyellow: 16448210,
	lightgray: 13882323,
	lightgreen: 9498256,
	lightgrey: 13882323,
	lightpink: 16758465,
	lightsalmon: 16752762,
	lightseagreen: 2142890,
	lightskyblue: 8900346,
	lightslategray: 7833753,
	lightslategrey: 7833753,
	lightsteelblue: 11584734,
	lightyellow: 16777184,
	lime: 65280,
	limegreen: 3329330,
	linen: 16445670,
	magenta: 16711935,
	maroon: 8388608,
	mediumaquamarine: 6737322,
	mediumblue: 205,
	mediumorchid: 12211667,
	mediumpurple: 9662683,
	mediumseagreen: 3978097,
	mediumslateblue: 8087790,
	mediumspringgreen: 64154,
	mediumturquoise: 4772300,
	mediumvioletred: 13047173,
	midnightblue: 1644912,
	mintcream: 16121850,
	mistyrose: 16770273,
	moccasin: 16770229,
	navajowhite: 16768685,
	navy: 128,
	oldlace: 16643558,
	olive: 8421376,
	olivedrab: 7048739,
	orange: 16753920,
	orangered: 16729344,
	orchid: 14315734,
	palegoldenrod: 15657130,
	palegreen: 10025880,
	paleturquoise: 11529966,
	palevioletred: 14381203,
	papayawhip: 16773077,
	peachpuff: 16767673,
	peru: 13468991,
	pink: 16761035,
	plum: 14524637,
	powderblue: 11591910,
	purple: 8388736,
	rebeccapurple: 6697881,
	red: 16711680,
	rosybrown: 12357519,
	royalblue: 4286945,
	saddlebrown: 9127187,
	salmon: 16416882,
	sandybrown: 16032864,
	seagreen: 3050327,
	seashell: 16774638,
	sienna: 10506797,
	silver: 12632256,
	skyblue: 8900331,
	slateblue: 6970061,
	slategray: 7372944,
	slategrey: 7372944,
	snow: 16775930,
	springgreen: 65407,
	steelblue: 4620980,
	tan: 13808780,
	teal: 32896,
	thistle: 14204888,
	tomato: 16737095,
	turquoise: 4251856,
	violet: 15631086,
	wheat: 16113331,
	white: 16777215,
	whitesmoke: 16119285,
	yellow: 16776960,
	yellowgreen: 10145074
};
define_default(Color, color, {
	copy(channels) {
		return Object.assign(new this.constructor(), this, channels);
	},
	displayable() {
		return this.rgb().displayable();
	},
	hex: color_formatHex,
	formatHex: color_formatHex,
	formatHex8: color_formatHex8,
	formatHsl: color_formatHsl,
	formatRgb: color_formatRgb,
	toString: color_formatRgb
});
function color_formatHex() {
	return this.rgb().formatHex();
}
function color_formatHex8() {
	return this.rgb().formatHex8();
}
function color_formatHsl() {
	return hslConvert(this).formatHsl();
}
function color_formatRgb() {
	return this.rgb().formatRgb();
}
function color(format) {
	var m, l;
	format = (format + "").trim().toLowerCase();
	return (m = reHex.exec(format)) ? (l = m[1].length, m = parseInt(m[1], 16), l === 6 ? rgbn(m) : l === 3 ? new Rgb(m >> 8 & 15 | m >> 4 & 240, m >> 4 & 15 | m & 240, (m & 15) << 4 | m & 15, 1) : l === 8 ? rgba(m >> 24 & 255, m >> 16 & 255, m >> 8 & 255, (m & 255) / 255) : l === 4 ? rgba(m >> 12 & 15 | m >> 8 & 240, m >> 8 & 15 | m >> 4 & 240, m >> 4 & 15 | m & 240, ((m & 15) << 4 | m & 15) / 255) : null) : (m = reRgbInteger.exec(format)) ? new Rgb(m[1], m[2], m[3], 1) : (m = reRgbPercent.exec(format)) ? new Rgb(m[1] * 255 / 100, m[2] * 255 / 100, m[3] * 255 / 100, 1) : (m = reRgbaInteger.exec(format)) ? rgba(m[1], m[2], m[3], m[4]) : (m = reRgbaPercent.exec(format)) ? rgba(m[1] * 255 / 100, m[2] * 255 / 100, m[3] * 255 / 100, m[4]) : (m = reHslPercent.exec(format)) ? hsla(m[1], m[2] / 100, m[3] / 100, 1) : (m = reHslaPercent.exec(format)) ? hsla(m[1], m[2] / 100, m[3] / 100, m[4]) : named.hasOwnProperty(format) ? rgbn(named[format]) : format === "transparent" ? new Rgb(NaN, NaN, NaN, 0) : null;
}
function rgbn(n) {
	return new Rgb(n >> 16 & 255, n >> 8 & 255, n & 255, 1);
}
function rgba(r, g, b, a) {
	if (a <= 0) r = g = b = NaN;
	return new Rgb(r, g, b, a);
}
function rgbConvert(o) {
	if (!(o instanceof Color)) o = color(o);
	if (!o) return new Rgb();
	o = o.rgb();
	return new Rgb(o.r, o.g, o.b, o.opacity);
}
function rgb(r, g, b, opacity) {
	return arguments.length === 1 ? rgbConvert(r) : new Rgb(r, g, b, opacity == null ? 1 : opacity);
}
function Rgb(r, g, b, opacity) {
	this.r = +r;
	this.g = +g;
	this.b = +b;
	this.opacity = +opacity;
}
define_default(Rgb, rgb, extend(Color, {
	brighter(k) {
		k = k == null ? brighter : Math.pow(brighter, k);
		return new Rgb(this.r * k, this.g * k, this.b * k, this.opacity);
	},
	darker(k) {
		k = k == null ? darker : Math.pow(darker, k);
		return new Rgb(this.r * k, this.g * k, this.b * k, this.opacity);
	},
	rgb() {
		return this;
	},
	clamp() {
		return new Rgb(clampi(this.r), clampi(this.g), clampi(this.b), clampa(this.opacity));
	},
	displayable() {
		return -.5 <= this.r && this.r < 255.5 && -.5 <= this.g && this.g < 255.5 && -.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
	},
	hex: rgb_formatHex,
	formatHex: rgb_formatHex,
	formatHex8: rgb_formatHex8,
	formatRgb: rgb_formatRgb,
	toString: rgb_formatRgb
}));
function rgb_formatHex() {
	return `#${hex(this.r)}${hex(this.g)}${hex(this.b)}`;
}
function rgb_formatHex8() {
	return `#${hex(this.r)}${hex(this.g)}${hex(this.b)}${hex((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function rgb_formatRgb() {
	const a = clampa(this.opacity);
	return `${a === 1 ? "rgb(" : "rgba("}${clampi(this.r)}, ${clampi(this.g)}, ${clampi(this.b)}${a === 1 ? ")" : `, ${a})`}`;
}
function clampa(opacity) {
	return isNaN(opacity) ? 1 : Math.max(0, Math.min(1, opacity));
}
function clampi(value) {
	return Math.max(0, Math.min(255, Math.round(value) || 0));
}
function hex(value) {
	value = clampi(value);
	return (value < 16 ? "0" : "") + value.toString(16);
}
function hsla(h, s, l, a) {
	if (a <= 0) h = s = l = NaN;
	else if (l <= 0 || l >= 1) h = s = NaN;
	else if (s <= 0) h = NaN;
	return new Hsl(h, s, l, a);
}
function hslConvert(o) {
	if (o instanceof Hsl) return new Hsl(o.h, o.s, o.l, o.opacity);
	if (!(o instanceof Color)) o = color(o);
	if (!o) return new Hsl();
	if (o instanceof Hsl) return o;
	o = o.rgb();
	var r = o.r / 255, g = o.g / 255, b = o.b / 255, min = Math.min(r, g, b), max = Math.max(r, g, b), h = NaN, s = max - min, l = (max + min) / 2;
	if (s) {
		if (r === max) h = (g - b) / s + (g < b) * 6;
		else if (g === max) h = (b - r) / s + 2;
		else h = (r - g) / s + 4;
		s /= l < .5 ? max + min : 2 - max - min;
		h *= 60;
	} else s = l > 0 && l < 1 ? 0 : h;
	return new Hsl(h, s, l, o.opacity);
}
function hsl(h, s, l, opacity) {
	return arguments.length === 1 ? hslConvert(h) : new Hsl(h, s, l, opacity == null ? 1 : opacity);
}
function Hsl(h, s, l, opacity) {
	this.h = +h;
	this.s = +s;
	this.l = +l;
	this.opacity = +opacity;
}
define_default(Hsl, hsl, extend(Color, {
	brighter(k) {
		k = k == null ? brighter : Math.pow(brighter, k);
		return new Hsl(this.h, this.s, this.l * k, this.opacity);
	},
	darker(k) {
		k = k == null ? darker : Math.pow(darker, k);
		return new Hsl(this.h, this.s, this.l * k, this.opacity);
	},
	rgb() {
		var h = this.h % 360 + (this.h < 0) * 360, s = isNaN(h) || isNaN(this.s) ? 0 : this.s, l = this.l, m2 = l + (l < .5 ? l : 1 - l) * s, m1 = 2 * l - m2;
		return new Rgb(hsl2rgb(h >= 240 ? h - 240 : h + 120, m1, m2), hsl2rgb(h, m1, m2), hsl2rgb(h < 120 ? h + 240 : h - 120, m1, m2), this.opacity);
	},
	clamp() {
		return new Hsl(clamph(this.h), clampt(this.s), clampt(this.l), clampa(this.opacity));
	},
	displayable() {
		return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
	},
	formatHsl() {
		const a = clampa(this.opacity);
		return `${a === 1 ? "hsl(" : "hsla("}${clamph(this.h)}, ${clampt(this.s) * 100}%, ${clampt(this.l) * 100}%${a === 1 ? ")" : `, ${a})`}`;
	}
}));
function clamph(value) {
	value = (value || 0) % 360;
	return value < 0 ? value + 360 : value;
}
function clampt(value) {
	return Math.max(0, Math.min(1, value || 0));
}
function hsl2rgb(h, m1, m2) {
	return (h < 60 ? m1 + (m2 - m1) * h / 60 : h < 180 ? m2 : h < 240 ? m1 + (m2 - m1) * (240 - h) / 60 : m1) * 255;
}
//#endregion
//#region ../../node_modules/d3-interpolate/src/constant.js
var constant_default = (x) => () => x;
//#endregion
//#region ../../node_modules/d3-interpolate/src/color.js
function linear(a, d) {
	return function(t) {
		return a + t * d;
	};
}
function exponential(a, b, y) {
	return a = Math.pow(a, y), b = Math.pow(b, y) - a, y = 1 / y, function(t) {
		return Math.pow(a + t * b, y);
	};
}
function gamma(y) {
	return (y = +y) === 1 ? nogamma : function(a, b) {
		return b - a ? exponential(a, b, y) : constant_default(isNaN(a) ? b : a);
	};
}
function nogamma(a, b) {
	var d = b - a;
	return d ? linear(a, d) : constant_default(isNaN(a) ? b : a);
}
//#endregion
//#region ../../node_modules/d3-interpolate/src/rgb.js
var rgb_default = (function rgbGamma(y) {
	var color = gamma(y);
	function rgb$1(start, end) {
		var r = color((start = rgb(start)).r, (end = rgb(end)).r), g = color(start.g, end.g), b = color(start.b, end.b), opacity = nogamma(start.opacity, end.opacity);
		return function(t) {
			start.r = r(t);
			start.g = g(t);
			start.b = b(t);
			start.opacity = opacity(t);
			return start + "";
		};
	}
	rgb$1.gamma = rgbGamma;
	return rgb$1;
})(1);
//#endregion
//#region ../../node_modules/d3-interpolate/src/numberArray.js
function numberArray_default(a, b) {
	if (!b) b = [];
	var n = a ? Math.min(b.length, a.length) : 0, c = b.slice(), i;
	return function(t) {
		for (i = 0; i < n; ++i) c[i] = a[i] * (1 - t) + b[i] * t;
		return c;
	};
}
function isNumberArray(x) {
	return ArrayBuffer.isView(x) && !(x instanceof DataView);
}
//#endregion
//#region ../../node_modules/d3-interpolate/src/array.js
function array_default(a, b) {
	return (isNumberArray(b) ? numberArray_default : genericArray)(a, b);
}
function genericArray(a, b) {
	var nb = b ? b.length : 0, na = a ? Math.min(nb, a.length) : 0, x = new Array(na), c = new Array(nb), i;
	for (i = 0; i < na; ++i) x[i] = value_default(a[i], b[i]);
	for (; i < nb; ++i) c[i] = b[i];
	return function(t) {
		for (i = 0; i < na; ++i) c[i] = x[i](t);
		return c;
	};
}
//#endregion
//#region ../../node_modules/d3-interpolate/src/date.js
function date_default(a, b) {
	var d = /* @__PURE__ */ new Date();
	return a = +a, b = +b, function(t) {
		return d.setTime(a * (1 - t) + b * t), d;
	};
}
//#endregion
//#region ../../node_modules/d3-interpolate/src/number.js
function number_default(a, b) {
	return a = +a, b = +b, function(t) {
		return a * (1 - t) + b * t;
	};
}
//#endregion
//#region ../../node_modules/d3-interpolate/src/object.js
function object_default(a, b) {
	var i = {}, c = {}, k;
	if (a === null || typeof a !== "object") a = {};
	if (b === null || typeof b !== "object") b = {};
	for (k in b) if (k in a) i[k] = value_default(a[k], b[k]);
	else c[k] = b[k];
	return function(t) {
		for (k in i) c[k] = i[k](t);
		return c;
	};
}
//#endregion
//#region ../../node_modules/d3-interpolate/src/string.js
var reA = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g;
var reB = new RegExp(reA.source, "g");
function zero(b) {
	return function() {
		return b;
	};
}
function one(b) {
	return function(t) {
		return b(t) + "";
	};
}
function string_default(a, b) {
	var bi = reA.lastIndex = reB.lastIndex = 0, am, bm, bs, i = -1, s = [], q = [];
	a = a + "", b = b + "";
	while ((am = reA.exec(a)) && (bm = reB.exec(b))) {
		if ((bs = bm.index) > bi) {
			bs = b.slice(bi, bs);
			if (s[i]) s[i] += bs;
			else s[++i] = bs;
		}
		if ((am = am[0]) === (bm = bm[0])) {
			if (s[i]) s[i] += bm;
			else s[++i] = bm;
		} else {
			s[++i] = null;
			q.push({
				i,
				x: number_default(am, bm)
			});
		}
		bi = reB.lastIndex;
	}
	if (bi < b.length) {
		bs = b.slice(bi);
		if (s[i]) s[i] += bs;
		else s[++i] = bs;
	}
	return s.length < 2 ? q[0] ? one(q[0].x) : zero(b) : (b = q.length, function(t) {
		for (var i = 0, o; i < b; ++i) s[(o = q[i]).i] = o.x(t);
		return s.join("");
	});
}
//#endregion
//#region ../../node_modules/d3-interpolate/src/value.js
function value_default(a, b) {
	var t = typeof b, c;
	return b == null || t === "boolean" ? constant_default(b) : (t === "number" ? number_default : t === "string" ? (c = color(b)) ? (b = c, rgb_default) : string_default : b instanceof color ? rgb_default : b instanceof Date ? date_default : isNumberArray(b) ? numberArray_default : Array.isArray(b) ? genericArray : typeof b.valueOf !== "function" && typeof b.toString !== "function" || isNaN(b) ? object_default : number_default)(a, b);
}
//#endregion
//#region src/util/animatepath.ts
/** This animation code was taken from trangular.js, and is used to interpolate 2 arrays of values using an easing fn */
function animatePath(newValue, oldValue, duration, updateFrame, finishFn = function() {}, easeFn = easing.easeOutElastic) {
	let start = null, interpolate = array_default(oldValue, newValue);
	let step = function(now) {
		if (duration === -1) return finishFn();
		if (start == null) start = now;
		let progress = now - start, percent = 1;
		if (progress < duration) {
			requestAnimationFrame(step);
			percent = easeFn(progress, 0, 1, duration);
		}
		updateFrame(interpolate(percent));
	};
	requestAnimationFrame(step);
	return function cancel() {
		duration = -1;
	};
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/cluster.js
function defaultSeparation$1(a, b) {
	return a.parent === b.parent ? 1 : 2;
}
function meanX(children) {
	return children.reduce(meanXReduce, 0) / children.length;
}
function meanXReduce(x, c) {
	return x + c.x;
}
function maxY(children) {
	return 1 + children.reduce(maxYReduce, 0);
}
function maxYReduce(y, c) {
	return Math.max(y, c.y);
}
function leafLeft(node) {
	var children;
	while (children = node.children) node = children[0];
	return node;
}
function leafRight(node) {
	var children;
	while (children = node.children) node = children[children.length - 1];
	return node;
}
function cluster_default() {
	var separation = defaultSeparation$1, dx = 1, dy = 1, nodeSize = false;
	function cluster(root) {
		var previousNode, x = 0;
		root.eachAfter(function(node) {
			var children = node.children;
			if (children) {
				node.x = meanX(children);
				node.y = maxY(children);
			} else {
				node.x = previousNode ? x += separation(node, previousNode) : 0;
				node.y = 0;
				previousNode = node;
			}
		});
		var left = leafLeft(root), right = leafRight(root), x0 = left.x - separation(left, right) / 2, x1 = right.x + separation(right, left) / 2;
		return root.eachAfter(nodeSize ? function(node) {
			node.x = (node.x - root.x) * dx;
			node.y = (root.y - node.y) * dy;
		} : function(node) {
			node.x = (node.x - x0) / (x1 - x0) * dx;
			node.y = (1 - (root.y ? node.y / root.y : 1)) * dy;
		});
	}
	cluster.separation = function(x) {
		return arguments.length ? (separation = x, cluster) : separation;
	};
	cluster.size = function(x) {
		return arguments.length ? (nodeSize = false, dx = +x[0], dy = +x[1], cluster) : nodeSize ? null : [dx, dy];
	};
	cluster.nodeSize = function(x) {
		return arguments.length ? (nodeSize = true, dx = +x[0], dy = +x[1], cluster) : nodeSize ? [dx, dy] : null;
	};
	return cluster;
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/count.js
function count(node) {
	var sum = 0, children = node.children, i = children && children.length;
	if (!i) sum = 1;
	else while (--i >= 0) sum += children[i].value;
	node.value = sum;
}
function count_default() {
	return this.eachAfter(count);
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/each.js
function each_default(callback, that) {
	let index = -1;
	for (const node of this) callback.call(that, node, ++index, this);
	return this;
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/eachBefore.js
function eachBefore_default(callback, that) {
	var node = this, nodes = [node], children, i, index = -1;
	while (node = nodes.pop()) {
		callback.call(that, node, ++index, this);
		if (children = node.children) for (i = children.length - 1; i >= 0; --i) nodes.push(children[i]);
	}
	return this;
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/eachAfter.js
function eachAfter_default(callback, that) {
	var node = this, nodes = [node], next = [], children, i, n, index = -1;
	while (node = nodes.pop()) {
		next.push(node);
		if (children = node.children) for (i = 0, n = children.length; i < n; ++i) nodes.push(children[i]);
	}
	while (node = next.pop()) callback.call(that, node, ++index, this);
	return this;
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/find.js
function find_default(callback, that) {
	let index = -1;
	for (const node of this) if (callback.call(that, node, ++index, this)) return node;
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/sum.js
function sum_default(value) {
	return this.eachAfter(function(node) {
		var sum = +value(node.data) || 0, children = node.children, i = children && children.length;
		while (--i >= 0) sum += children[i].value;
		node.value = sum;
	});
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/sort.js
function sort_default(compare) {
	return this.eachBefore(function(node) {
		if (node.children) node.children.sort(compare);
	});
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/path.js
function path_default(end) {
	var start = this, ancestor = leastCommonAncestor(start, end), nodes = [start];
	while (start !== ancestor) {
		start = start.parent;
		nodes.push(start);
	}
	var k = nodes.length;
	while (end !== ancestor) {
		nodes.splice(k, 0, end);
		end = end.parent;
	}
	return nodes;
}
function leastCommonAncestor(a, b) {
	if (a === b) return a;
	var aNodes = a.ancestors(), bNodes = b.ancestors(), c = null;
	a = aNodes.pop();
	b = bNodes.pop();
	while (a === b) {
		c = a;
		a = aNodes.pop();
		b = bNodes.pop();
	}
	return c;
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/ancestors.js
function ancestors_default() {
	var node = this, nodes = [node];
	while (node = node.parent) nodes.push(node);
	return nodes;
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/descendants.js
function descendants_default() {
	return Array.from(this);
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/leaves.js
function leaves_default() {
	var leaves = [];
	this.eachBefore(function(node) {
		if (!node.children) leaves.push(node);
	});
	return leaves;
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/links.js
function links_default() {
	var root = this, links = [];
	root.each(function(node) {
		if (node !== root) links.push({
			source: node.parent,
			target: node
		});
	});
	return links;
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/iterator.js
function* iterator_default() {
	var node = this, current, next = [node], children, i, n;
	do {
		current = next.reverse(), next = [];
		while (node = current.pop()) {
			yield node;
			if (children = node.children) for (i = 0, n = children.length; i < n; ++i) next.push(children[i]);
		}
	} while (next.length);
}
//#endregion
//#region ../../node_modules/d3-hierarchy/src/hierarchy/index.js
function hierarchy(data, children) {
	if (data instanceof Map) {
		data = [void 0, data];
		if (children === void 0) children = mapChildren;
	} else if (children === void 0) children = objectChildren;
	var root = new Node(data), node, nodes = [root], child, childs, i, n;
	while (node = nodes.pop()) if ((childs = children(node.data)) && (n = (childs = Array.from(childs)).length)) {
		node.children = childs;
		for (i = n - 1; i >= 0; --i) {
			nodes.push(child = childs[i] = new Node(childs[i]));
			child.parent = node;
			child.depth = node.depth + 1;
		}
	}
	return root.eachBefore(computeHeight);
}
function node_copy() {
	return hierarchy(this).eachBefore(copyData);
}
function objectChildren(d) {
	return d.children;
}
function mapChildren(d) {
	return Array.isArray(d) ? d[1] : null;
}
function copyData(node) {
	if (node.data.value !== void 0) node.value = node.data.value;
	node.data = node.data.data;
}
function computeHeight(node) {
	var height = 0;
	do
		node.height = height;
	while ((node = node.parent) && node.height < ++height);
}
function Node(data) {
	this.data = data;
	this.depth = this.height = 0;
	this.parent = null;
}
Node.prototype = hierarchy.prototype = {
	constructor: Node,
	count: count_default,
	each: each_default,
	eachAfter: eachAfter_default,
	eachBefore: eachBefore_default,
	find: find_default,
	sum: sum_default,
	sort: sort_default,
	path: path_default,
	ancestors: ancestors_default,
	descendants: descendants_default,
	leaves: leaves_default,
	links: links_default,
	copy: node_copy,
	[Symbol.iterator]: iterator_default
};
//#endregion
//#region ../../node_modules/d3-hierarchy/src/tree.js
function defaultSeparation(a, b) {
	return a.parent === b.parent ? 1 : 2;
}
function nextLeft(v) {
	var children = v.children;
	return children ? children[0] : v.t;
}
function nextRight(v) {
	var children = v.children;
	return children ? children[children.length - 1] : v.t;
}
function moveSubtree(wm, wp, shift) {
	var change = shift / (wp.i - wm.i);
	wp.c -= change;
	wp.s += shift;
	wm.c += change;
	wp.z += shift;
	wp.m += shift;
}
function executeShifts(v) {
	var shift = 0, change = 0, children = v.children, i = children.length, w;
	while (--i >= 0) {
		w = children[i];
		w.z += shift;
		w.m += shift;
		shift += w.s + (change += w.c);
	}
}
function nextAncestor(vim, v, ancestor) {
	return vim.a.parent === v.parent ? vim.a : ancestor;
}
function TreeNode(node, i) {
	this._ = node;
	this.parent = null;
	this.children = null;
	this.A = null;
	this.a = this;
	this.z = 0;
	this.m = 0;
	this.c = 0;
	this.s = 0;
	this.t = null;
	this.i = i;
}
TreeNode.prototype = Object.create(Node.prototype);
function treeRoot(root) {
	var tree = new TreeNode(root, 0), node, nodes = [tree], child, children, i, n;
	while (node = nodes.pop()) if (children = node._.children) {
		node.children = new Array(n = children.length);
		for (i = n - 1; i >= 0; --i) {
			nodes.push(child = node.children[i] = new TreeNode(children[i], i));
			child.parent = node;
		}
	}
	(tree.parent = new TreeNode(null, 0)).children = [tree];
	return tree;
}
function tree_default() {
	var separation = defaultSeparation, dx = 1, dy = 1, nodeSize = null;
	function tree(root) {
		var t = treeRoot(root);
		t.eachAfter(firstWalk), t.parent.m = -t.z;
		t.eachBefore(secondWalk);
		if (nodeSize) root.eachBefore(sizeNode);
		else {
			var left = root, right = root, bottom = root;
			root.eachBefore(function(node) {
				if (node.x < left.x) left = node;
				if (node.x > right.x) right = node;
				if (node.depth > bottom.depth) bottom = node;
			});
			var s = left === right ? 1 : separation(left, right) / 2, tx = s - left.x, kx = dx / (right.x + s + tx), ky = dy / (bottom.depth || 1);
			root.eachBefore(function(node) {
				node.x = (node.x + tx) * kx;
				node.y = node.depth * ky;
			});
		}
		return root;
	}
	function firstWalk(v) {
		var children = v.children, siblings = v.parent.children, w = v.i ? siblings[v.i - 1] : null;
		if (children) {
			executeShifts(v);
			var midpoint = (children[0].z + children[children.length - 1].z) / 2;
			if (w) {
				v.z = w.z + separation(v._, w._);
				v.m = v.z - midpoint;
			} else v.z = midpoint;
		} else if (w) v.z = w.z + separation(v._, w._);
		v.parent.A = apportion(v, w, v.parent.A || siblings[0]);
	}
	function secondWalk(v) {
		v._.x = v.z + v.parent.m;
		v.m += v.parent.m;
	}
	function apportion(v, w, ancestor) {
		if (w) {
			var vip = v, vop = v, vim = w, vom = vip.parent.children[0], sip = vip.m, sop = vop.m, sim = vim.m, som = vom.m, shift;
			while (vim = nextRight(vim), vip = nextLeft(vip), vim && vip) {
				vom = nextLeft(vom);
				vop = nextRight(vop);
				vop.a = v;
				shift = vim.z + sim - vip.z - sip + separation(vim._, vip._);
				if (shift > 0) {
					moveSubtree(nextAncestor(vim, v, ancestor), v, shift);
					sip += shift;
					sop += shift;
				}
				sim += vim.m;
				sip += vip.m;
				som += vom.m;
				sop += vop.m;
			}
			if (vim && !nextRight(vop)) {
				vop.t = vim;
				vop.m += sim - sop;
			}
			if (vip && !nextLeft(vom)) {
				vom.t = vip;
				vom.m += sip - som;
				ancestor = v;
			}
		}
		return ancestor;
	}
	function sizeNode(node) {
		node.x *= dx;
		node.y = node.depth * dy;
	}
	tree.separation = function(x) {
		return arguments.length ? (separation = x, tree) : separation;
	};
	tree.size = function(x) {
		return arguments.length ? (nodeSize = false, dx = +x[0], dy = +x[1], tree) : nodeSize ? null : [dx, dy];
	};
	tree.nodeSize = function(x) {
		return arguments.length ? (nodeSize = true, dx = +x[0], dy = +x[1], tree) : nodeSize ? [dx, dy] : null;
	};
	return tree;
}
//#endregion
//#region src/statevis/renderers.tsx
const RENDERER_PRESETS = {
	Tree: {
		layoutFn: TREE_LAYOUT,
		sortNodesFn: TOP_TO_BOTTOM_SORT,
		labelRenderFn: SLANTED_TEXT,
		edgeRenderFn: TREE_EDGE
	},
	Cluster: {
		layoutFn: CLUSTER_LAYOUT,
		sortNodesFn: TOP_TO_BOTTOM_SORT,
		labelRenderFn: SLANTED_TEXT,
		edgeRenderFn: TREE_EDGE
	},
	Radial: {
		layoutFn: RADIAL_LAYOUT,
		sortNodesFn: BOTTOM_TO_TOP_SORT,
		labelRenderFn: RADIAL_TEXT,
		edgeRenderFn: RADIAL_EDGE
	}
};
const tree = RENDERER_PRESETS.Tree;
const DEFAULT_RENDERER = {
	baseRadius: 10,
	baseFontSize: 12,
	baseStrokeWidth: 2,
	baseNodeStrokeWidth: 2,
	zoom: 1,
	layoutFn: tree.layoutFn,
	sortNodesFn: tree.sortNodesFn,
	labelRenderFn: tree.labelRenderFn,
	edgeRenderFn: tree.edgeRenderFn
};
function BOTTOM_TO_TOP_SORT(a, b) {
	let b2t = b.layoutY - a.layoutY;
	if (b2t !== 0) return b2t;
	return a.layoutX - b.layoutX;
}
function TOP_TO_BOTTOM_SORT(a, b) {
	let t2b = a.layoutY - b.layoutY;
	if (t2b !== 0) return t2b;
	return a.layoutX - b.layoutX;
}
function TREE_LAYOUT(rootNode) {
	let root = hierarchy(rootNode);
	return updateNodes(tree_default()(root));
}
function CLUSTER_LAYOUT(rootNode) {
	let root = hierarchy(rootNode);
	return updateNodes(cluster_default()(root));
}
/** For RADIAL_LAYOUT: projects x/y coords from a cluster layout to circular layout */
function project(x, y) {
	let angle = (x - 90) / 180 * Math.PI, radius = y;
	const CENTER = .5;
	return {
		x: CENTER + radius * Math.cos(angle),
		y: CENTER + radius * Math.sin(angle)
	};
}
function RADIAL_LAYOUT(rootNode) {
	let root = hierarchy(rootNode);
	cluster_default().size([360, .4]).separation(function(a, b) {
		return (a.parent == b.parent ? 1 : 2) / a.depth;
	})(root).each(function(node) {
		let projected = project(node.x, node.y);
		let visNode = node.data;
		visNode.layoutX = node.x;
		visNode.layoutY = node.y;
		visNode.x = projected.x;
		visNode.y = projected.y;
	});
}
/** Mutates each StateVisNode by copying the new x/y values from the d3 HierarchyPointNode structure */
function updateNodes(nodes) {
	nodes.each((node) => {
		node.data.layoutX = node.data.x = node.x;
		node.data.layoutY = node.data.y = node.y;
	});
	return nodes;
}
function RADIAL_TEXT(x, y, node, nodeOptions, renderer) {
	let { baseFontSize, zoom } = renderer;
	let fontSize = baseFontSize * zoom;
	const label = nodeOptions?.label ? nodeOptions.label(node, defaultLabel(node)) : defaultLabel(node);
	let angle = node.layoutX || 0;
	let textAnchor = angle < 180 === !!node.children ? "start" : "end";
	return /* @__PURE__ */ k("text", {
		className: "name",
		"text-anchor": textAnchor,
		transform: `rotate(${angle < 180 ? angle - 90 : angle + 90}),translate(${(textAnchor === "start" ? 15 : -15) * zoom}, 0)`,
		"font-size": fontSize
	}, " ", label, " ");
}
function defaultLabel(node) {
	let segments = node.name.split(".");
	let name = segments.pop();
	if (name == "**") name = segments.pop() + ".**";
	return name;
}
function SLANTED_TEXT(x, y, node, nodeOptions, renderer) {
	let { baseFontSize, zoom } = renderer;
	let fontSize = baseFontSize * zoom;
	const label = nodeOptions?.label ? nodeOptions.label(node, defaultLabel(node)) : defaultLabel(node);
	return /* @__PURE__ */ k("text", {
		className: "name",
		"text-anchor": "middle",
		transform: `rotate(-15),translate(0, ${-15 * zoom})`,
		"font-size": fontSize
	}, " ", label, " ");
}
/** Straight line */
function RADIAL_EDGE(node, renderer) {
	let strokeWidth = renderer.baseStrokeWidth * renderer.zoom;
	const makeLinkPath = (node) => {
		let s = {
			x: node.animX,
			y: node.animY
		};
		let p = {
			x: node._parent.animX,
			y: node._parent.animY
		};
		return "M" + [s.x, s.y] + " " + [p.x, p.y];
	};
	return /* @__PURE__ */ k("path", {
		d: makeLinkPath(node),
		"stroke-width": strokeWidth,
		className: "link"
	});
}
/** Bezier curve */
function TREE_EDGE(node, renderer) {
	let strokeWidth = renderer.baseStrokeWidth * renderer.zoom;
	const makeLinkPath = (node) => {
		let s = {
			x: node.animX,
			y: node.animY
		};
		let p = {
			x: node._parent.animX,
			y: node._parent.animY
		};
		let yAvg = (s.y + p.y) / 2;
		return `M ${s.x} ${s.y} C ${s.x} ${yAvg}, ${p.x} ${yAvg}, ${p.x} ${p.y}`;
	};
	return /* @__PURE__ */ k("path", {
		d: makeLinkPath(node),
		"stroke-width": strokeWidth,
		className: "link"
	});
}
//#endregion
//#region src/statevis/tree/stateVisNode.tsx
function createStateVisNode(state) {
	let node = Object.create(state);
	Object.defineProperty(node, "visible", { get() {
		if (this.entered) return true;
		return !(this._parent && (this._parent.collapsed || !this._parent.visible));
	} });
	Object.defineProperty(node, "children", { get() {
		return this._children.filter((child) => child.visible);
	} });
	Object.defineProperty(node, "totalDescendents", { get() {
		return this._children.reduce((acc, child) => acc + child.totalDescendents, this._children.length);
	} });
	Object.defineProperty(node, "collapsed", { get() {
		return !this.entered && this._collapsed && this._children.length;
	} });
	return node;
}
//#endregion
//#region src/statevis/tree/StateTree.tsx
let resetMetadata = {
	label: "",
	highlight: false,
	active: false,
	future: false,
	retained: false,
	entered: false,
	exited: false,
	inactive: true
};
var StateTree = class StateTree extends C {
	constructor(..._args) {
		super(..._args);
		this.state = {
			nodes: [],
			layout: {}
		};
		this.nodes = [];
		this.unmounted = false;
		this.cancelCurrentAnimation = () => null;
		this.doLayoutAnimation = () => {
			this.cancelCurrentAnimation();
			let nodes = this.getNodes();
			if (!nodes.length) return;
			let rootNode = nodes.filter((state) => state.name === "")[0];
			this.props.renderer.layoutFn(rootNode);
			nodes.filter((node) => !node.visible).forEach((node) => {
				let visibleAncestor = node._parent;
				while (visibleAncestor && !visibleAncestor.visible) visibleAncestor = visibleAncestor._parent;
				if (visibleAncestor) {
					node.x = visibleAncestor.x;
					node.y = visibleAncestor.y;
				}
			});
			let dimensions = this.dimensions();
			const transformX = (xval) => xval * dimensions.scaleX + dimensions.offsetX;
			const transformY = (yval) => yval * dimensions.scaleY + dimensions.offsetY;
			const getCurrentCoords = (node) => ({
				x: node.animX || this.props.width / 2,
				y: node.animY || this.props.height / 2
			});
			let currentCoords = nodes.map(getCurrentCoords).map((obj) => [obj.x, obj.y]).reduce((acc, arr) => acc.concat(arr), []);
			let targetCoords = nodes.map((node) => [transformX(node.x), transformY(node.y)]).reduce((acc, arr) => acc.concat(arr), []);
			const animationFrame = (xyValArray) => {
				let tupleCount = xyValArray.length / 2;
				for (let i = 0; i < tupleCount && i < nodes.length; i++) {
					let node = nodes[i];
					node.animX = xyValArray[i * 2];
					node.animY = xyValArray[i * 2 + 1];
				}
				this.setState({ nodes });
			};
			this.cancelCurrentAnimation = animatePath(targetCoords, currentCoords, 500, animationFrame, () => null, easing.easeInOutExpo);
		};
		this.nodeForState = (nodes, state) => nodes.filter((node) => node.name === state.name)[0];
		this.updateStates = () => {
			let states = this.props.router.stateService.get().map((s) => s.$$state());
			let known = this.nodes.map(Object.getPrototypeOf);
			let toAdd = states.filter((s) => known.indexOf(s) === -1);
			let toDel = known.filter((s) => states.indexOf(s) === -1);
			let nodes = this.nodes = this.nodes.slice();
			if (toAdd.length || toDel.length) {
				toAdd.map((s) => createStateVisNode(s)).forEach((n) => nodes.push(n));
				toDel.map((del) => nodes.filter((node) => del.isPrototypeOf(node))).reduce((acc, x) => acc.concat(x), []).forEach((node) => nodes.splice(nodes.indexOf(node), 1));
				nodes.forEach((n) => n._children = []);
				nodes.forEach((n) => {
					if (!n || !n.parent) return;
					let parentNode = this.nodeForState(nodes, n.parent);
					if (!parentNode) return;
					parentNode._children.push(n);
					n._parent = parentNode;
				});
				nodes.forEach((n) => n.future = !!n.lazyLoad);
			}
			if (!this.unmounted && !this.deregisterStateListenerFn) setTimeout(this.updateStates, 1e3);
			this.setState({ nodes }, this.doLayoutAnimation);
		};
		this.updateNodes = ($transition$) => {
			this.nodes.map((node) => Object.assign(node, resetMetadata)).forEach((n) => n.future = !!n.lazyLoad);
			if ($transition$) {
				let tc = $transition$.treeChanges();
				const getNode = (node) => this.nodeForState(this.nodes, node.state);
				tc.retained.concat(tc.entering).map(getNode).filter((x) => x).forEach((n) => n.entered = true);
				tc.retained.map(getNode).filter((x) => x).forEach((n) => n.retained = true);
				tc.exiting.map(getNode).filter((x) => x).forEach((n) => n.exited = true);
				tc.to.slice(-1).map(getNode).filter((x) => x).forEach((n) => {
					n.active = true;
					n.label = "active";
				});
			}
			this.setState({ nodes: this.nodes }, this.doLayoutAnimation);
		};
	}
	static create(router, element, props = {}) {
		if (!element) {
			element = document.createElement("div");
			element.id = "uirStateTree";
		}
		let initialProps = {
			...props,
			router
		};
		const _render = () => {
			document.body.appendChild(element);
			R(k(StateTree, initialProps), element);
		};
		if (document.readyState === "interactive" || document.readyState === "complete") _render();
		else document.addEventListener("DOMContentLoaded", _render, false);
		return element;
	}
	static {
		this.defaultProps = {
			height: 350,
			width: 250,
			renderer: DEFAULT_RENDERER
		};
	}
	componentDidMount() {
		let registry = this.props.router.stateRegistry;
		let $transitions = this.props.router.transitionService;
		if (registry.onStatesChanged) this.deregisterStateListenerFn = registry.onStatesChanged(() => this.updateStates());
		this.updateStates();
		this.deregisterHookFn = $transitions.onSuccess({}, (trans) => this.updateNodes(trans));
		this.updateNodes();
		let lastSuccessful = this.props.router.globals.successfulTransitions.peekTail();
		if (lastSuccessful) this.updateNodes(lastSuccessful);
		let pending = this.props.router.globals.transition;
		if (pending) pending.promise.then(() => this.updateNodes(pending));
	}
	componentWillReceiveProps() {
		let nodes = this.state.nodes;
		this.setState({ nodes }, this.updateStates);
	}
	dimensions() {
		let newProps = {};
		let radius = 15;
		let offsetX = 0;
		let offsetY = 30;
		let height = this.props.height || 500;
		let width = this.props.width || 500;
		return {
			radius,
			offsetX,
			offsetY,
			scaleX: newProps.scaleX || width - 0,
			scaleY: newProps.scaleY || height - 60
		};
	}
	componentWillUnmount() {
		this.unmounted = true;
		this.deregisterHookFn && this.deregisterHookFn();
	}
	getNodes() {
		return this.nodes.slice().sort(this.props.renderer.sortNodesFn);
	}
	render() {
		let renderer = this.props.renderer;
		let renderNodes = this.getNodes().filter((node) => node.visible && node.animX && node.animY);
		return /* @__PURE__ */ k("div", { className: "statevis" }, /* @__PURE__ */ k("svg", {
			width: this.props.width,
			height: this.props.height
		}, renderNodes.filter((node) => !!node.parent).map((node) => renderer.edgeRenderFn(node, renderer)), renderNodes.map((node) => /* @__PURE__ */ k(StateNode, {
			key: node.name,
			node,
			router: this.props.router,
			nodeOptions: this.props.nodeOptions,
			renderer: this.props.renderer,
			doLayout: this.doLayoutAnimation.bind(this),
			x: node.animX,
			y: node.animY
		}))));
	}
};
//#endregion
//#region src/statevis/LayoutPrefs.tsx
var LayoutPrefs = class extends C {
	constructor(..._args) {
		super(..._args);
		this.state = {
			renderer: DEFAULT_RENDERER,
			presetName: "Tree"
		};
	}
	componentDidMount() {
		this.props.onRendererChange(this.state.renderer);
	}
	handleZoom(event) {
		let el = event.target;
		let value = parseFloat(el["value"]);
		let renderer = {
			...this.state.renderer,
			zoom: value
		};
		this.setState({ renderer });
		this.props.onRendererChange(renderer);
	}
	handleLayout(event) {
		let presetName = event.target["value"];
		let settings = RENDERER_PRESETS[presetName];
		let renderer = {
			...this.state.renderer,
			...settings
		};
		this.setState({
			renderer,
			presetName
		});
		this.props.onRendererChange(renderer);
	}
	render() {
		return /* @__PURE__ */ k("div", {
			className: "uirStateVisLayoutPrefs",
			style: {
				display: "flex",
				flexFlow: "column nowrap"
			},
			onMouseDown: (evt) => evt.stopPropagation()
		}, /* @__PURE__ */ k("div", { style: {
			flex: "1 1 auto",
			display: "flex",
			flexFlow: "row nowrap",
			alignItems: "center"
		} }, /* @__PURE__ */ k("div", null, "Layout:"), /* @__PURE__ */ k("select", {
			style: {
				marginLeft: "auto",
				maxWidth: "100px"
			},
			onChange: this.handleLayout.bind(this),
			value: this.state.presetName
		}, Object.keys(RENDERER_PRESETS).map((preset) => /* @__PURE__ */ k("option", { value: preset }, preset)))), /* @__PURE__ */ k("div", { style: {
			flex: "1 1 auto",
			display: "flex",
			flexFlow: "row nowrap",
			alignItems: "center"
		} }, /* @__PURE__ */ k("span", null, "Node size:"), /* @__PURE__ */ k("input", {
			style: { marginLeft: "auto" },
			value: "" + this.state.renderer.zoom,
			type: "range",
			min: "0.3",
			max: "3.0",
			step: "0.1",
			onInput: this.handleZoom.bind(this)
		}), /* @__PURE__ */ k("span", null, this.state.renderer.zoom, "x")));
	}
};
//#endregion
//#region src/statevis/icons/ChevronDown.tsx
const ChevronDown = ({ size }) => /* @__PURE__ */ k("svg", {
	width: size,
	height: size,
	viewBox: "0 0 1792 1792",
	xmlns: "http://www.w3.org/2000/svg"
}, /* @__PURE__ */ k("path", { d: "M1683 808l-742 741q-19 19-45 19t-45-19l-742-741q-19-19-19-45.5t19-45.5l166-165q19-19 45-19t45 19l531 531 531-531q19-19 45-19t45 19l166 165q19 19 19 45.5t-19 45.5z" }));
//#endregion
//#region src/statevis/icons/Close.tsx
const Close = ({ size }) => /* @__PURE__ */ k("svg", {
	width: size,
	height: size,
	viewBox: "0 0 1792 1792",
	xmlns: "http://www.w3.org/2000/svg"
}, /* @__PURE__ */ k("path", { d: "M1490 1322q0 40-28 68l-136 136q-28 28-68 28t-68-28l-294-294-294 294q-28 28-68 28t-68-28l-136-136q-28-28-28-68t28-68l294-294-294-294q-28-28-28-68t28-68l136-136q28-28 68-28t68 28l294 294 294-294q28-28 68-28t68 28l136 136q28 28 28 68t-28 68l-294 294 294 294q28 28 28 68z" }));
//#endregion
//#region src/statevis/icons/Gear.tsx
const Gear = ({ size }) => /* @__PURE__ */ k("svg", {
	width: size,
	height: size,
	viewBox: "0 0 1792 1792",
	xmlns: "http://www.w3.org/2000/svg"
}, /* @__PURE__ */ k("path", { d: "M1152 896q0-106-75-181t-181-75-181 75-75 181 75 181 181 75 181-75 75-181zm512-109v222q0 12-8 23t-20 13l-185 28q-19 54-39 91 35 50 107 138 10 12 10 25t-9 23q-27 37-99 108t-94 71q-12 0-26-9l-138-108q-44 23-91 38-16 136-29 186-7 28-36 28h-222q-14 0-24.5-8.5t-11.5-21.5l-28-184q-49-16-90-37l-141 107q-10 9-25 9-14 0-25-11-126-114-165-168-7-10-7-23 0-12 8-23 15-21 51-66.5t54-70.5q-27-50-41-99l-183-27q-13-2-21-12.5t-8-23.5v-222q0-12 8-23t19-13l186-28q14-46 39-92-40-57-107-138-10-12-10-24 0-10 9-23 26-36 98.5-107.5t94.5-71.5q13 0 26 10l138 107q44-23 91-38 16-136 29-186 7-28 36-28h222q14 0 24.5 8.5t11.5 21.5l28 184q49 16 90 37l142-107q9-9 24-9 13 0 25 10 129 119 165 170 7 8 7 22 0 12-8 23-15 21-51 66.5t-54 70.5q26 50 41 98l183 28q13 2 21 12.5t8 23.5z" }));
//#endregion
//#region src/statevis/icons/Help.tsx
const Help = ({ size }) => /* @__PURE__ */ k("svg", {
	width: size,
	height: size,
	viewBox: "0 0 1792 1792",
	xmlns: "http://www.w3.org/2000/svg"
}, /* @__PURE__ */ k("path", { d: "M1008 1200v160q0 14-9 23t-23 9h-160q-14 0-23-9t-9-23v-160q0-14 9-23t23-9h160q14 0 23 9t9 23zm256-496q0 50-15 90t-45.5 69-52 44-59.5 36q-32 18-46.5 28t-26 24-11.5 29v32q0 14-9 23t-23 9h-160q-14 0-23-9t-9-23v-68q0-35 10.5-64.5t24-47.5 39-35.5 41-25.5 44.5-21q53-25 75-43t22-49q0-42-43.5-71.5t-95.5-29.5q-56 0-95 27-29 20-80 83-9 12-25 12-11 0-19-6l-108-82q-10-7-12-20t5-23q122-192 349-192 129 0 238.5 89.5t109.5 214.5zm-368-448q-130 0-248.5 51t-204 136.5-136.5 204-51 248.5 51 248.5 136.5 204 204 136.5 248.5 51 248.5-51 204-136.5 136.5-204 51-248.5-51-248.5-136.5-204-204-136.5-248.5-51zm768 640q0 209-103 385.5t-279.5 279.5-385.5 103-385.5-103-279.5-279.5-103-385.5 103-385.5 279.5-279.5 385.5-103 385.5 103 279.5 279.5 103 385.5z" }));
//#endregion
//#region src/statevis/Controls.tsx
var Controls = class extends C {
	constructor(..._args) {
		super(..._args);
		this.state = { showRendererPrefs: false };
	}
	render() {
		return /* @__PURE__ */ k("div", { style: { width: "100%" } }, /* @__PURE__ */ k("div", { className: "uirStateVisControls" }, /* @__PURE__ */ k(StateSelector, { router: this.props.router }), /* @__PURE__ */ k("div", {
			style: {
				marginLeft: "auto",
				cursor: "pointer"
			},
			className: "uirStateVisIcons"
		}, /* @__PURE__ */ k("span", { className: "uirStateVisHover" }, /* @__PURE__ */ k(Help, { size: "16px" }), /* @__PURE__ */ k("div", { className: "hoverBlock" }, /* @__PURE__ */ k("ul", null, /* @__PURE__ */ k("li", null, "Click a node to activate that state."), /* @__PURE__ */ k("li", null, "Select a state from the dropdown to activate that state."), /* @__PURE__ */ k("li", null, "Double click a node to auto-collapse that section of the tree when inactive. Collapsed nodes are displayed with a dotted outline and the count of collapsed children."), /* @__PURE__ */ k("li", null, "Lazy loaded states (including future states) are displayed with a dashed outline.")))), /* @__PURE__ */ k("span", { className: "uirStateVisHover" }, /* @__PURE__ */ k(Gear, { size: "16px" }), /* @__PURE__ */ k("div", { className: "hoverBlock" }, /* @__PURE__ */ k(LayoutPrefs, { onRendererChange: this.props.onRendererChange }))), /* @__PURE__ */ k("span", {
			className: "uirStateVisHover",
			onClick: this.props.onMinimize
		}, /* @__PURE__ */ k(ChevronDown, { size: "16px" }), /* @__PURE__ */ k("div", null, /* @__PURE__ */ k("span", { style: { float: "right" } }, "Minimize")), /* @__PURE__ */ k("div", null, "Minimize")), /* @__PURE__ */ k("span", {
			className: "uirStateVisHover",
			onClick: this.props.onClose
		}, /* @__PURE__ */ k(Close, { size: "16px" }), /* @__PURE__ */ k("div", null, /* @__PURE__ */ k("span", { style: { float: "right" } }, "Close"))))));
	}
};
//#endregion
//#region src/statevis/StateVisWindow.tsx
/** A floating window that supports minimization and resizing  */
var StateVisWindow = class extends C {
	constructor(props) {
		super(props);
		this.deregisterFns = [];
		this.minimize = () => {
			let el = this.el;
			let bounds = el.getBoundingClientRect();
			this.top = bounds.top + "px";
			this.left = bounds.left + "px";
			this.right = window.innerWidth - bounds.right + "px";
			this.bottom = window.innerHeight - bounds.bottom + "px";
			el.style.top = "auto";
			el.style.left = "auto";
			el.style.right = this.right;
			el.style.bottom = this.bottom;
			let unminimize = () => {
				el.style.top = "auto";
				el.style.left = "auto";
				el.style.right = this.right;
				el.style.bottom = this.bottom;
				toggleClass("minimized")(el);
				el.removeEventListener("click", unminimize);
				const animationEndListener = (evt) => {
					let bounds = el.getBoundingClientRect();
					el.style.top = bounds.top + "px";
					el.style.left = bounds.left + "px";
					el.style.right = "auto";
					el.style.bottom = "auto";
					el.removeEventListener("transitionend", animationEndListener);
				};
				el.addEventListener("transitionend", animationEndListener);
			};
			addClass("minimized")(el);
			setTimeout(() => el.style.right = el.style.bottom = "0", 50);
			return unminimize;
		};
		this.state = { unminimize: null };
	}
	componentWillReceiveProps(nextProps) {
		if (this.props.minimized !== nextProps.minimized) {
			const { unminimize } = this.state;
			if (unminimize) this.setState({ unminimize: null }, () => unminimize());
			else this.setState({ unminimize: this.minimize() });
		}
	}
	componentWillUnmount() {
		this.deregisterFns.forEach((fn) => fn());
	}
	componentDidMount() {
		if (typeof MutationObserver === "function") this.monitorResizeEvents();
	}
	/** The uirStateVisContainer class enables resize: both. This function listens for resize events */
	monitorResizeEvents() {
		let _width = this.el.style.width;
		let _height = this.el.style.height;
		let observer = new MutationObserver((mutations) => {
			mutations.forEach((mutation) => {
				if (mutation.attributeName == "style") {
					let el = mutation.target, newwidth = el["style"].width, newheight = el["style"].height;
					if (newwidth !== _width || newheight !== _height) {
						_width = newwidth;
						_height = newheight;
						let width = parseInt(newwidth.replace(/px$/, ""));
						let height = parseInt(newheight.replace(/px$/, ""));
						this.props.onResize({
							width,
							height
						});
					}
				}
			});
		});
		observer.observe(this.el, {
			attributes: true,
			childList: false,
			characterData: false,
			subtree: false,
			attributeFilter: ["style"]
		});
		this.deregisterFns.push(() => observer.disconnect());
	}
	render() {
		return /* @__PURE__ */ k("div", {
			className: "uirStateVisContainer",
			ref: (el) => {
				this.el = el;
			}
		}, this.props.children);
	}
};
//#endregion
//#region node_modules/rollup-plugin-styles/dist/runtime/inject-css.js
var e = [];
var t = [];
function n(n, r) {
	if (n && "undefined" != typeof document) {
		var a, s = !0 === r.prepend ? "prepend" : "append", d = !0 === r.singleTag, i = "string" == typeof r.container ? document.querySelector(r.container) : document.getElementsByTagName("head")[0];
		if (d) {
			var u = e.indexOf(i);
			-1 === u && (u = e.push(i) - 1, t[u] = {}), a = t[u] && t[u][s] ? t[u][s] : t[u][s] = c();
		} else a = c();
		65279 === n.charCodeAt(0) && (n = n.substring(1)), a.styleSheet ? a.styleSheet.cssText += n : a.appendChild(document.createTextNode(n));
	}
	function c() {
		var e = document.createElement("style");
		if (e.setAttribute("type", "text/css"), r.attributes) for (var t = Object.keys(r.attributes), n = 0; n < t.length; n++) e.setAttribute(t[n], r.attributes[t[n]]);
		var a = "prepend" === s ? "afterbegin" : "beforeend";
		return i.insertAdjacentElement(a, e), e;
	}
}
n("/* http://meyerweb.com/eric/tools/css/reset/\n   v2.0 | 20110126\n   License: none (public domain)\n*/\n\n#uirStateVisualizer {\n  margin: 0;\n  padding: 0;\n  border: 0;\n  font-size: 16px;\n  font-family: sans-serif;\n  font-weight: normal;\n  vertical-align: baseline;\n  line-height: 1;\n  display: block;\n  box-sizing: content-box;\n}\n#uirStateVisualizer svg {\n  box-sizing: content-box;\n}\n\n.uirStateVisContainer {\n  z-index: 999;\n  position: fixed;\n  right: 32px;\n  bottom: 64px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  background-color: rgba(255, 255, 255, 0.8);\n  transform: scale(1);\n  transform-origin: right bottom;\n  transition: right 0.5s ease, bottom 0.5s ease, transform 0.5s ease;\n  overflow: hidden;\n  resize: both;\n}\n\n.uirStateVisContainer.minimized {\n  cursor: pointer;\n  transform: scale(0.25);\n  z-index: 1000;\n}\n\n.uirStateVisContainer:hover {\n  outline: 2px solid rgba(0, 0, 0, 0.35);\n}\n\n.uirStateVisContainer:hover .uirStateVisControls {\n  visibility: visible;\n}\n\n.uirStateVisContainer .uirStateVisControls {\n  visibility: hidden;\n  display: flex;\n  width: 100%;\n  flex-flow: row nowrap;\n  justify-content: space-between;\n  flex: 1 0 auto;\n  z-index: 1;\n}\n\n.uirStateVisContainer .uirStateVisControls .uirStateVisIcons span svg {\n  padding: 3px;\n  fill: #777777;\n}\n\n.uirStateVisContainer .uirStateVisControls .uirStateVisIcons span:hover svg {\n  fill: black;\n}\n\n.uirStateVisHover > div {\n  transition: opacity 500ms ease;\n  opacity: 0;\n  height: 0;\n  padding: 0;\n\n  position: absolute;\n  top: 0;\n  right: 0;\n  overflow: hidden;\n\n  margin-top: 26px;\n  font-size: 14px;\n}\n\n.uirStateVisHover > div.hoverBlock {\n  left: 0;\n  border-bottom: none;\n  background: white;\n}\n\n.uirStateVisHover:hover > div.hoverBlock {\n  border-bottom: 2px solid lightgrey;\n}\n\n.uirStateVisHover:hover > div {\n  opacity: 1;\n  height: auto;\n}\n\n.uirStateVisHover .uirStateVisLayoutPrefs {\n  padding: 12px 24px;\n}\n\n.uirStateVisContainer .statevis {\n  flex: 1 1 auto;\n  transition: all 1s ease;\n}\n\n.uirStateVisWindowOverlay {\n  display: none;\n}\n\n.minimized .uirStateVisWindowOverlay {\n  display: block;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  z-index: 1000;\n}\n\n.statevis circle {\n  /*r: 10;*/\n  fill: #fff;\n  stroke: grey;\n  /*stroke-width: 3px;*/\n\n  transition-property: r, fill, stroke, stroke-width;\n  transition-duration: 350ms;\n  transition-timing-function: ease-in-out;\n\n  cursor: pointer;\n}\n\n.statevis text {\n  transition-property: x, y, font-size, stroke, stroke-width;\n  transition-duration: 350ms;\n  transition-timing-function: ease-in-out;\n}\n\n.statevis circle.future {\n  /*r: 10;*/\n  stroke: grey;\n  stroke-dasharray: 7, 5;\n  /*stroke-width: 1px;*/\n}\n\n.statevis circle.entered {\n  /*r: 10;*/\n  stroke: black;\n  fill: lightgreen;\n}\n\n.statevis circle.entered:after {\n  content: '<text>Entered</text>';\n}\n\n.statevis circle.active {\n  /*r: 15;*/\n  fill: green;\n  stroke: black;\n}\n\n.statevis circle.collapsed {\n  stroke-dasharray: 2, 2;\n}\n\n.statevis text {\n  font-family: sans-serif;\n}\n\n.statevis .link {\n  fill: none;\n  stroke: #ccc;\n  /*stroke-width: 2px;*/\n}\n\n.statevis text.label {\n  fill: grey;\n  alignment-baseline: middle;\n}\n\n.draggable {\n  cursor: move;\n}\n\n/*.draggable:hover {*/\n/*outline: 3px solid rgba(0,0,0,0.15)*/\n/*}*/\n", {});
//#endregion
//#region src/statevis/StateVisualizer.tsx
var StateVisualizer = class StateVisualizer extends C {
	constructor(..._args) {
		super(..._args);
		this.state = {
			height: null,
			width: null,
			renderer: DEFAULT_RENDERER,
			minimized: false
		};
		this.deregisterFns = [];
		this.svgWidth = () => this.props.width || this.state.width || 350;
		this.svgHeight = () => (this.props.height || this.state.height || 250) - 25;
	}
	/**
	* Creates a new StateVisualizer and adds it to the document.
	*
	* @param router the UIRouter object
	* @param element (optional) the element where the StateVisualizer should be placed.
	*                If no element is passed, an element will be created in the body.
	* @param props height/width properties default: { height: 350, width: 250 }
	* @param options StateVisualizerOptions used to customise the styling of the visualizer
	*
	* # Angular 1 + UI-Router (1.0.0-beta.2 and higher):
	*
	* Inject the router (`$uiRouter`) in a run block, then call StateVisualizer.create();
	*
	* ```
	* app.run(function($uiRouter) {
	*   StateVisualizer.create($uiRouter);
	* });
	* ```
	*
	* # Angular 1 + UI-Router 1.0.0-alpha.1 through 1.0.0-beta.1:
	*
	* Inject the router (`ng1UIRouter`) in a run block, then call StateVisualizer.create();
	*
	* ```
	* app.run(function(ng1UIRouter) {
	*   StateVisualizer.create(ng1UIRouter);
	* });
	* ```
	*
	* Angular 2:
	*
	* Call StateVisualizer.create() from your UIRouterConfig
	*
	* ```
	* export class MyUIRouterConfig extends UIRouterConfig {
	*   configure(router: UIRouter) {
	*     StateVisualizer.create(router);
	*   }
	* }
	* ```
	*
	* React:
	*
	* Call StateVisualizer.create() from your bootstrap
	*
	* ```
	* let router = new UIRouterReact();
	* StateVisualizer.create(router);
	* router.start();
	* ```
	*
	* @return the element that was bootstrapped.
	*         You can destroy the component using:
	*         [ReactDOM.unmountComponentAtNode](https://facebook.github.io/react/docs/top-level-api.html#reactdom.unmountcomponentatnode)
	*/
	static create(router, element, props = {}, options) {
		if (!element) {
			element = document.createElement("div");
			element.id = "uirStateVisualizer";
		}
		let initialProps = Object.assign({}, props, {
			router,
			minimizeAfter: 2500,
			visualizationOptions: options
		});
		const _render = () => {
			document.body.appendChild(element);
			R(k(StateVisualizer, initialProps), element);
		};
		if (document.readyState === "interactive" || document.readyState === "complete") _render();
		else document.addEventListener("DOMContentLoaded", _render, false);
		return element;
	}
	dispose() {
		R(null, document.getElementById("uirStateVisualizer"), this.rootEl);
	}
	handleRendererChange(renderer) {
		this.setState({ renderer });
	}
	cancelAutoMinimize() {
		if (this.minimizeTimeout) {
			clearTimeout(this.minimizeTimeout);
			this.minimizeTimeout = null;
		}
	}
	componentWillUnmount() {
		this.deregisterFns.forEach((fn) => fn());
	}
	draggable() {
		let controlsEl = this.windowEl.querySelector(".uirStateVisControls");
		let visEl = this.windowEl.querySelector(".statevis");
		this.deregisterFns.push(draggable(controlsEl, dragActions.move(this.windowEl)));
		this.deregisterFns.push(draggable(visEl, dragActions.move(this.windowEl)));
	}
	componentDidMount() {
		this.draggable();
		if (this.props.minimizeAfter) {
			const doMinimize = () => this.setState({ minimized: true });
			this.minimizeTimeout = setTimeout(doMinimize, this.props.minimizeAfter);
		}
	}
	render() {
		const { minimized } = this.state;
		return /* @__PURE__ */ k("div", {
			ref: (el) => {
				this.rootEl = el;
			},
			onMouseDown: this.cancelAutoMinimize.bind(this),
			onMouseEnter: this.cancelAutoMinimize.bind(this)
		}, /* @__PURE__ */ k(StateVisWindow, {
			minimized: this.state.minimized,
			ref: (windowRef) => {
				this.windowEl = windowRef && windowRef.el || this.windowEl;
			},
			onResize: ({ width, height }) => this.setState({
				width,
				height
			})
		}, /* @__PURE__ */ k("div", {
			onClick: () => this.setState({ minimized: false }),
			className: `uirStateVisWindowOverlay ${minimized ? "minimized" : ""}`
		}), /* @__PURE__ */ k(Controls, {
			router: this.props.router,
			onRendererChange: this.handleRendererChange.bind(this),
			onMinimize: () => this.setState({ minimized: true }),
			onClose: () => this.dispose()
		}), /* @__PURE__ */ k(StateTree, {
			router: this.props.router,
			nodeOptions: this.props.visualizationOptions.node,
			width: this.svgWidth(),
			height: this.svgHeight(),
			renderer: this.state.renderer
		})));
	}
};
//#endregion
//#region src/transition/PopoverHeading.tsx
var PopoverHeading = class extends C {
	render() {
		const tackClass = () => "uir-icon uir-icon-thumb-tack " + (this.props.pinned ? "" : "uir-rotate-35");
		const expandClass = () => "uir-icon uirTranVis_tooltipRight " + (this.props.expanded ? "uir-icon-toggle-on" : "uir-icon-toggle-off");
		return /* @__PURE__ */ k("div", { className: "uirTranVis_panelHeading uirTranVis_heading" }, /* @__PURE__ */ k("div", {
			style: { cursor: "pointer" },
			onClick: this.props.togglePinned
		}, /* @__PURE__ */ k("i", { className: tackClass() })), /* @__PURE__ */ k("h3", { className: "uirTranVis_panelTitle" }, "Transition #", this.props.transition.$id), /* @__PURE__ */ k("div", {
			style: { cursor: "pointer" },
			onClick: this.props.toggleExpand
		}, /* @__PURE__ */ k("i", { className: expandClass() })));
	}
};
//#endregion
//#region src/util/modal.tsx
var Modal = class extends C {
	static {
		this.show = (modalTitle, id, value, component) => {
			let modal = document.body.querySelector("#uirTranVis_modal");
			if (!modal) {
				modal = document.createElement("div");
				modal.id = "uirTranVis_modal";
				document.body.appendChild(modal);
			}
			const Nothing = () => null;
			const close = () => R(/* @__PURE__ */ k(Nothing, null), document.body, modal);
			R(k(component, {
				close,
				modalTitle,
				id,
				value
			}), modal);
		};
	}
	componentDidMount() {
		let el = this._ref;
		setTimeout(() => {
			let fades = el.getElementsByClassName("uir-fade");
			[].slice.apply(fades).forEach((node) => node.className += " in");
		}, 35);
	}
	render() {
		return /* @__PURE__ */ k("div", { ref: (ref) => {
			this._ref = ref;
		} }, /* @__PURE__ */ k("div", {
			className: "uirTranVis_modal-backdrop uir-fade",
			style: { zIndex: 1040 }
		}), /* @__PURE__ */ k("div", {
			tabIndex: -1,
			className: "uirTranVis_modal uir-fade",
			style: {
				zIndex: 1050,
				display: "block"
			}
		}, /* @__PURE__ */ k("div", { className: "uirTranVis_modal-dialog modal-lg" }, /* @__PURE__ */ k("div", { className: "uirTranVis_modal-content" }, this.props.children))));
	}
};
//#endregion
//#region src/util/pretty.tsx
var Pretty = class extends C {
	constructor(..._args) {
		super(..._args);
		this.preStyle = {
			display: "block",
			padding: "10px 30px",
			margin: "0"
		};
		this.state = { show: true };
	}
	toggle() {
		this.setState({ show: !this.state.show });
	}
	render() {
		return /* @__PURE__ */ k("div", null, this.state.show ? /* @__PURE__ */ k("pre", { style: this.preStyle }, JSON.stringify(this.props.data, null, 2)) : false);
	}
};
//#endregion
//#region src/transition/ResolveData.tsx
var ResolveData = class extends C {
	constructor(..._args) {
		super(..._args);
		this.close = () => this.props.close();
	}
	render() {
		return /* @__PURE__ */ k("div", null, /* @__PURE__ */ k(Modal, null, /* @__PURE__ */ k("div", { className: "uirTranVis_modal-header uir-resolve-header" }, /* @__PURE__ */ k("div", { style: { fontSize: "20px" } }, this.props.modalTitle, ": ", this.props.id), /* @__PURE__ */ k("button", {
			className: "uirTranVis_btn uirTranVis_btnXs uirTranVis_btnPrimary",
			onClick: this.close
		}, /* @__PURE__ */ k("i", { className: "uir-icon uir-iconw-close" }))), /* @__PURE__ */ k("div", { className: "uirTranVis_modalBody" }, /* @__PURE__ */ k(Pretty, { data: this.props.value })), /* @__PURE__ */ k("div", { className: "uirTranVis_modalFooter" }, /* @__PURE__ */ k("button", {
			className: "uirTranVis_btn uirTranVis_btnPrimary",
			onClick: this.close
		}, "Close"))));
	}
};
//#endregion
//#region src/util/strings.ts
/**
* Returns a string shortened to a maximum length
*
* If the string is already less than the `max` length, return the string.
* Else return the string, shortened to `max - 3` and append three dots ("...").
*
* @param max the maximum length of the string to return
* @param str the input string
*/
function maxLength(max, str) {
	if (str.length <= max) return str;
	return str.substr(0, max - 3) + "...";
}
function stringifyPattern(value) {
	if (value === void 0) return "undefined";
	if (value === null) return "null";
	if (typeof value === "object" && typeof value.then === "function") return "[Promise]";
	return value;
}
function stringify(o) {
	var seen = [];
	function format(val) {
		if (typeof val === "object") {
			if (seen.indexOf(val) !== -1) return "[circular ref]";
			seen.push(val);
		}
		return stringifyPattern(val);
	}
	return JSON.stringify(o, (key, val) => format(val)).replace(/\\"/g, "\"");
}
//#endregion
//#region src/transition/KeysAndValues.tsx
var KeyValueRow = class extends C {
	render() {
		const { tuple: { key, val }, classes, modalTitle } = this.props;
		const showModal = () => Modal.show(modalTitle, key, val, ResolveData);
		const renderValue = () => {
			if (val === void 0) return /* @__PURE__ */ k("span", { className: "uirTranVis_code" }, "undefined");
			if (val === null) return /* @__PURE__ */ k("span", { className: "uirTranVis_code" }, "null");
			if (typeof val === "string") return /* @__PURE__ */ k("span", { className: "uirTranVis_code" }, "\"", maxLength(100, val), "\"");
			if (typeof val === "number") return /* @__PURE__ */ k("span", { className: "uirTranVis_code" }, val.toString());
			if (typeof val === "boolean") return /* @__PURE__ */ k("span", { className: "uirTranVis_code" }, val.toString());
			if (Array.isArray(val)) return /* @__PURE__ */ k("span", {
				className: "link",
				onClick: showModal
			}, "[Array]");
			if (typeof val === "object") return /* @__PURE__ */ k("span", {
				className: "link",
				onClick: showModal
			}, "[Object]");
			if (typeof val.toString === "function") return /* @__PURE__ */ k("span", null, maxLength(100, val.toString()));
		};
		return /* @__PURE__ */ k("div", { className: classes.div }, /* @__PURE__ */ k("div", { className: classes.key }, key, ":"), /* @__PURE__ */ k("div", { className: classes.val }, renderValue()));
	}
};
var KeysAndValues = class KeysAndValues extends C {
	constructor(..._args) {
		super(..._args);
		this.state = { collapseFalsy: true };
	}
	static {
		this.falsyGroupDefinitions = [
			{
				value: void 0,
				label: "undefined"
			},
			{
				value: null,
				label: "null"
			},
			{
				value: "",
				label: "empty string"
			}
		];
	}
	makeBuckets(definitions, data) {
		const makeBucket = (def) => ({
			label: def.label,
			is: (val) => val === def.value,
			value: def.value,
			count: 0,
			data: {}
		});
		const buckets = definitions.map(makeBucket).concat({
			label: "default",
			is: () => true,
			count: 0,
			data: {}
		});
		Object.keys(data).forEach((key) => {
			const bucket = buckets.find((bucket) => bucket.is(data[key]));
			bucket.data[key] = data[key];
			bucket.value = data[key];
			bucket.count++;
		});
		return buckets;
	}
	render() {
		const { data, classes, modalTitle } = this.props;
		const groupedValues = this.props.groupedValues || KeysAndValues.falsyGroupDefinitions;
		const enableGroupToggle = this.props.enableGroupToggle || false;
		const isCollapsed = this.state.collapseFalsy;
		const buckets = this.makeBuckets(groupedValues, data);
		const defaultBucket = buckets.find((bucket) => bucket.label === "default");
		const groupedBuckets = buckets.filter((bucket) => !!bucket.count && bucket !== defaultBucket);
		const groupedCount = groupedBuckets.reduce((total, bucket) => total += bucket.count, 0);
		const tuples = Object.keys(defaultBucket.data).map((key) => ({
			key,
			val: defaultBucket.data[key]
		}));
		const groupedTuples = groupedBuckets.map((bucket) => {
			return {
				key: Object.keys(bucket.data).sort().join(", "),
				val: bucket.value
			};
		});
		const showGroupToggle = enableGroupToggle && groupedCount > 1;
		return /* @__PURE__ */ k("div", { className: "uirTranVis_keysAndValues" }, tuples.map((tuple) => /* @__PURE__ */ k(KeyValueRow, {
			key: tuple.key,
			tuple,
			classes,
			modalTitle
		})), showGroupToggle && !!groupedTuples.length && /* @__PURE__ */ k("a", {
			href: "javascript:void(0)",
			onClick: () => this.setState({ collapseFalsy: !isCollapsed }),
			className: "uirTranVis_keyValue"
		}, isCollapsed ? "show" : "hide", " ", groupedCount, " ", groupedBuckets.map((bucket) => bucket.label).join(" or "), " ", "parameter values"), (!showGroupToggle || !this.state.collapseFalsy) && groupedTuples.map((tuple) => /* @__PURE__ */ k(KeyValueRow, {
			key: tuple.key,
			tuple,
			classes,
			modalTitle
		})));
	}
};
//#endregion
//#region src/transition/TransSummary.tsx
var TransSummary = class extends C {
	render() {
		return /* @__PURE__ */ k("div", { className: "uirTranVis_transSummary" }, /* @__PURE__ */ k("div", { className: "uirTranVis_summaryData" }, /* @__PURE__ */ k("span", null, "From:"), /* @__PURE__ */ k("strong", null, this.props.trans.from().name || "(root)")), /* @__PURE__ */ k("div", { className: "uirTranVis_summaryData" }, /* @__PURE__ */ k("span", null, "To:"), /* @__PURE__ */ k("strong", null, this.props.trans.to().name || "(root)")), /* @__PURE__ */ k("div", { className: "uirTranVis_summaryData" }, /* @__PURE__ */ k("span", null, "Result:"), /* @__PURE__ */ k("div", null, /* @__PURE__ */ k("strong", null, this.props.status), this.props.rejection ? /* @__PURE__ */ k("span", null, ": ", this.props.rejection) : null)), /* @__PURE__ */ k("div", { className: "uirTranVis_summaryHeading" }, "Parameter Values:"), /* @__PURE__ */ k("div", null, /* @__PURE__ */ k(KeysAndValues, {
			groupedValues: KeysAndValues.falsyGroupDefinitions,
			enableGroupToggle: true,
			data: this.props.trans.params(),
			modalTitle: "Parameter value",
			classes: {
				div: "uirTranVis_keyValue",
				key: "",
				val: ""
			}
		})));
	}
};
//#endregion
//#region src/transition/NodeDetail.tsx
var NodeDetail = class extends C {
	stateName() {
		let node = this.props.node;
		let name = node && node.state && node.state.name;
		if (name === "") name = "(root)";
		return name && name.split(".").reverse()[0];
	}
	params() {
		let node = this.props.node;
		return node && node.paramSchema.reduce((params, param) => {
			params[param.id] = node.paramValues[param.id];
			return params;
		}, {});
	}
	resolves() {
		const asString = (val) => typeof val === "string" ? val : maxLength(30, stringify(val));
		let node = this.props.node;
		let ignoredTokens = [
			"$stateParams",
			"$transition$",
			"$state$",
			this.props.trans.constructor
		];
		return node && node.resolvables.filter((r) => ignoredTokens.indexOf(r.token) === -1).reduce((acc, r) => {
			acc[asString(r.token)] = r.data;
			return acc;
		}, {});
	}
	render() {
		if (!this.props.node) return null;
		const params = this.params();
		const resolves = this.resolves();
		return !this.props.node ? null : /* @__PURE__ */ k("div", { className: "uirTranVis_nodeDetail" }, /* @__PURE__ */ k("div", { className: "uirTranVis_heading" }, /* @__PURE__ */ k("div", { className: "uirTranVis_nowrap uirTranVis_deemphasize" }, "(", this.props.type, " state)"), /* @__PURE__ */ k("div", { className: "uirTranVis_stateName" }, this.stateName())), !!Object.keys(params).length && /* @__PURE__ */ k("div", { className: "params" }, /* @__PURE__ */ k("div", { className: "uirTranVis_paramsLabel uirTranVis_deemphasize" }, "Parameter values"), /* @__PURE__ */ k(KeysAndValues, {
			data: this.params(),
			classes: { div: "uirTranVis_keyValue" },
			modalTitle: "Parameter value"
		})), !!Object.keys(resolves).length && /* @__PURE__ */ k("div", { className: "params resolve" }, /* @__PURE__ */ k("div", { className: "uirTranVis_resolveLabel uirTranVis_deemphasize" }, "Resolved data"), /* @__PURE__ */ k(KeysAndValues, {
			data: this.resolves(),
			classes: { div: "uirTranVis_keyValue" },
			modalTitle: "Resolved value"
		})));
	}
};
//#endregion
//#region src/transition/FlowArrow.tsx
var FlowArrow = class extends C {
	constructor(..._args) {
		super(..._args);
		this.height = 1e3;
		this.renderCurve = () => /* @__PURE__ */ k("path", {
			stroke: "white",
			"stroke-width": "20",
			fill: "none",
			d: `M50 ${this.height} V 70 Q50 20, 100 20 Q150 20, 150 70 V ${this.height}`
		});
		this.renderVerticalLine = () => /* @__PURE__ */ k("svg", {
			viewBox: `0 70 100 ${this.height - 70}`,
			className: "flowArrowSvg"
		}, this.renderCurve());
		this.renderCurveRU = () => /* @__PURE__ */ k("svg", {
			viewBox: `0 0 100 ${this.height}`,
			className: "flowArrowSvg top"
		}, this.renderCurve());
		this.renderCurveRD = () => /* @__PURE__ */ k("svg", {
			viewBox: `100 0 100 ${this.height}`,
			className: "flowArrowSvg top"
		}, this.renderCurve());
		this.renderArrowU = () => /* @__PURE__ */ k("svg", {
			viewBox: `0 0 100 ${this.height}`,
			className: "flowArrowSvg top"
		}, /* @__PURE__ */ k("path", {
			stroke: "white",
			"stroke-width": "20",
			fill: "none",
			d: `M50 ${this.height} V 20 `
		}), /* @__PURE__ */ k("polygon", {
			fill: "white",
			stroke: "white",
			"stroke-width": "20",
			points: "50,20 35,40 65,40"
		}));
		this.renderArrowD = () => /* @__PURE__ */ k("svg", {
			viewBox: `0 0 100 ${this.height}`,
			className: "flowArrowSvg bottom"
		}, /* @__PURE__ */ k("path", {
			stroke: "white",
			"stroke-width": "20",
			fill: "none",
			d: `M50 0 V ${this.height - 20}`
		}), /* @__PURE__ */ k("polygon", {
			fill: "white",
			stroke: "white",
			"stroke-width": "20",
			points: `50,${this.height - 20} 35,${this.height - 40} 65,${this.height - 40}`
		}));
	}
	render() {
		const renderSvg = (type) => {
			switch (type) {
				case "V": return this.renderVerticalLine();
				case "RU": return this.renderCurveRU();
				case "RD": return this.renderCurveRD();
				case "AU": return this.renderArrowU();
				case "AD": return this.renderArrowD();
				default: return null;
			}
		};
		return /* @__PURE__ */ k("div", { className: "flowArrowCell" }, /* @__PURE__ */ k("div", { style: {
			overflow: "hidden",
			position: "relative",
			flex: "1"
		} }, renderSvg(this.props.top)), /* @__PURE__ */ k("div", { style: {
			overflow: "hidden",
			position: "relative",
			flex: "1"
		} }, renderSvg(this.props.bottom)));
	}
};
//#endregion
//#region src/transition/NodePaths.tsx
var NodePaths = class extends C {
	constructor(..._args) {
		super(..._args);
		this.state = {
			retained: [],
			enterExit: []
		};
	}
	componentDidMount() {
		let trans = this.props.transition;
		let tcPaths = Object.assign({}, trans.treeChanges());
		[
			"entering",
			"exiting",
			"retained"
		].forEach((key) => tcPaths[key] = tcPaths[key].filter((node) => !!node.state.name));
		const partialKey = (pathname, idx) => {
			let node = tcPaths[pathname][idx];
			return node ? node.state.name : "";
		};
		const key = (pathname1, pathname2, idx) => `${trans.$id}.${partialKey(pathname1, idx)}-${partialKey(pathname2, idx)}`;
		let retained = tcPaths.retained.map((node, idx) => ({
			key: key("retained", "retained", idx),
			to: node,
			toType: "retain",
			from: node,
			fromType: "retain"
		}));
		let enterExit = [];
		let maxPathLength = Math.max(tcPaths.exiting.length, tcPaths.entering.length);
		for (let i = 0; i < maxPathLength; i++) enterExit.push({
			key: key("exiting", "entering", i),
			to: tcPaths.entering[i],
			toType: tcPaths.entering[i] && "enter",
			from: tcPaths.exiting[i],
			fromType: tcPaths.exiting[i] && "exit"
		});
		this.setState({
			retained,
			enterExit
		});
	}
	render() {
		var retained = this.state.retained || [];
		var enterExit = this.state.enterExit || [];
		var lastEnterIdx = enterExit.filter((x) => !!x.toType).length - 1;
		return /* @__PURE__ */ k("table", { className: "uirTranVis_paths" }, /* @__PURE__ */ k("thead", null, /* @__PURE__ */ k("tr", null, /* @__PURE__ */ k("th", null, "From Path"), /* @__PURE__ */ k("th", null, "To Path"))), /* @__PURE__ */ k("tbody", null, retained.map((elem) => /* @__PURE__ */ k("tr", { key: elem.key }, /* @__PURE__ */ k("td", {
			className: elem.fromType,
			colSpan: 2
		}, /* @__PURE__ */ k(NodeDetail, {
			trans: this.props.transition,
			node: elem.from,
			type: elem.fromType
		})))), enterExit.map((elem, idx) => /* @__PURE__ */ k("tr", { key: elem.key }, /* @__PURE__ */ k("td", { colSpan: 2 }, /* @__PURE__ */ k("div", { className: "uirTranVis_Row" }, /* @__PURE__ */ k("div", { className: `${elem.fromType}` }, !elem.fromType ? null : /* @__PURE__ */ k("div", { className: "uirTranVis_nodeContent" }, /* @__PURE__ */ k(NodeDetail, {
			trans: this.props.transition,
			node: elem.from,
			type: elem.fromType
		}), /* @__PURE__ */ k(FlowArrow, {
			bottom: "V",
			top: idx ? "V" : elem.toType ? "RU" : "AU"
		}))), /* @__PURE__ */ k("div", { className: `${elem.toType}` }, !elem.toType ? null : /* @__PURE__ */ k("div", { className: "uirTranVis_nodeContent" }, /* @__PURE__ */ k(FlowArrow, {
			top: idx ? "V" : elem.fromType ? "RD" : "V",
			bottom: idx == lastEnterIdx ? "AD" : "V"
		}), /* @__PURE__ */ k(NodeDetail, {
			trans: this.props.transition,
			node: elem.to,
			type: elem.toType
		})))))))));
	}
};
//#endregion
//#region src/transition/TransitionPopover.tsx
var TransitionPopover = class extends C {
	render() {
		if (!this.props.open && !this.props.pinned) return null;
		const classes = () => "uirTranVis_transitionDetail uirTranVis_panel panel-default " + (this.props.pinned ? "pin " : "") + (this.props.expanded ? "expand " : "") + (this.props.open ? "showDetail " : "");
		return /* @__PURE__ */ k("div", { className: classes() }, /* @__PURE__ */ k(PopoverHeading, {
			transition: this.props.transition,
			pinned: this.props.pinned,
			expanded: this.props.expanded,
			togglePinned: this.props.togglePinned,
			toggleExpand: this.props.toggleExpand
		}), /* @__PURE__ */ k("div", { className: "uirTranVis_panelBody" }, /* @__PURE__ */ k(TransSummary, {
			trans: this.props.transition,
			status: this.props.status,
			rejection: this.props.rejection
		}), /* @__PURE__ */ k("hr", null), /* @__PURE__ */ k(NodePaths, { transition: this.props.transition })), /* @__PURE__ */ k("div", { className: "uirTranVis_downArrow" }));
	}
};
//#endregion
//#region src/transition/BreadcrumbArrow.tsx
var BreadcrumbArrow = class extends C {
	constructor(..._args) {
		super(..._args);
		this.handleClick = () => this.props.toggleExpand();
	}
	iconClass() {
		return {
			running: "uir-icon uir-spin uir-iconw-spinner",
			success: "uir-icon uir-iconw-check",
			redirected: "uir-icon uir-iconw-share",
			ignored: "uir-icon uir-iconw-circle-o",
			error: "uir-icon uir-iconw-close"
		}[this.props.status];
	}
	render() {
		return !this.props.transition ? null : /* @__PURE__ */ k("div", {
			className: this.props.status + " uirTranVis_historyEntry",
			onClick: this.handleClick
		}, /* @__PURE__ */ k("div", { className: "uirTranVis_historyEntrySummary" }, /* @__PURE__ */ k("div", { className: "uirTranVis_transId" }, this.props.transition.$id), /* @__PURE__ */ k("div", { className: "uirTranVis_status" }, this.props.status, !this.props.message ? null : /* @__PURE__ */ k("span", null, ": ", this.props.message)), /* @__PURE__ */ k("div", { className: "uirTranVis_transName" }, /* @__PURE__ */ k("i", { className: this.iconClass() }), /* @__PURE__ */ k("span", null, this.props.transition.to().name))));
	}
};
//#endregion
//#region src/util/cancelablePromise.ts
const makeCancelable = (promise) => {
	let hasCanceled_ = false;
	var cancelablePromise = {
		promise: new Promise((resolve, reject) => {
			promise.then((val) => hasCanceled_ ? reject({ isCanceled: true }) : resolve(val), (error) => hasCanceled_ ? reject({ isCanceled: true }) : reject(error));
		}),
		isCanceled: false,
		cancel() {
			cancelablePromise.isCanceled = hasCanceled_ = true;
		}
	};
	return cancelablePromise;
};
//#endregion
//#region src/transition/TransitionView.tsx
var TransitionView = class extends C {
	constructor(..._args) {
		super(..._args);
		this.transitionPromise = null;
		this.state = {
			status: "running",
			message: null,
			rejection: null,
			pinned: false,
			expanded: false,
			open: false,
			deregisterFunctions: []
		};
		this.togglePin = () => this.setState({ pinned: !this.state.pinned });
		this.toggleExpand = () => this.setState({ expanded: !this.state.expanded });
		this.open = () => this.setState({ open: true });
		this.close = () => this.setState({ open: false });
	}
	componentDidMount() {
		let trans = this.props.transition;
		const setMessage = (message) => {
			if (!this.transitionPromise.isCanceled) this.setState({ message });
		};
		const statename = (state) => state.name || "(root)";
		let fns = [];
		fns.push(trans.onStart({}, () => setMessage("Starting..."), { priority: 1e4 }));
		fns.push(trans.onExit({}, (t, state) => setMessage(`Exiting ${statename(state)}`), { priority: 1e4 }));
		fns.push(trans.onRetain({}, (t, state) => setMessage(`Retained ${statename(state)}`), { priority: 1e4 }));
		fns.push(trans.onEnter({}, (t, state) => setMessage(`Entering ${statename(state)}`), { priority: 1e4 }));
		fns.push(trans.onFinish({}, () => setMessage(`Finishing...`)));
		this.setState({ deregisterFunctions: fns });
		const success = () => this.setState({
			status: "success",
			message: null
		});
		const error = (err) => {
			if (err && err.isCanceled) return;
			let status = "error", rejection = null;
			if (err) {
				rejection = err && err.message;
				let type = err && err.type;
				if (type == 2 && err.redirected === true) {
					status = "redirected";
					let targetState = err["detail"];
					rejection = maxLength(100, `${targetState.name()}(${JSON.stringify(targetState.params())}`) + ")";
				}
				if (type == 5) {
					status = "ignored";
					rejection = "All states and parameters in the To and From paths are identical.";
				}
			}
			this.setState({
				status,
				rejection,
				message: null
			});
		};
		this.transitionPromise = makeCancelable(trans.promise);
		this.transitionPromise.promise.then(success, error);
	}
	componentWillUnmount() {
		this.transitionPromise.cancel();
		if (this.state.deregisterFunctions) this.state.deregisterFunctions.forEach((fn) => fn());
	}
	render() {
		return /* @__PURE__ */ k("div", {
			onMouseEnter: this.open,
			onMouseLeave: this.close
		}, /* @__PURE__ */ k(TransitionPopover, {
			transition: this.props.transition,
			status: this.state.status,
			rejection: this.state.rejection,
			pinned: this.state.pinned,
			expanded: this.state.expanded,
			open: this.state.open,
			togglePinned: this.togglePin,
			toggleExpand: this.toggleExpand
		}), /* @__PURE__ */ k(BreadcrumbArrow, {
			transition: this.props.transition,
			status: this.state.status,
			message: this.state.message,
			toggleExpand: this.toggleExpand
		}));
	}
};
n("/*\n    .uirTranVis_history is the breadcrumbs and transition details block.\n    It fills the footer of the screen, and scrolls horizontally.\n    Mouse clicks should pass through to the elements underneath.\n*/\n\n.uirTranVis_history {\n    display: flex;\n    align-items: flex-end;\n    position: fixed;\n    left: 0;\n    bottom: 0;\n    right: 0;\n    padding: 0 16px;\n    overflow-x: scroll;\n    z-index: 999;\n    /* disable mouse clicks, hover, etc, for the overall div */\n    pointer-events: none;\n}\n\n.uirTranVis_history > * {\n    /* Enable mouse for any sub-elements (the breadcrumb elemetns and detail elements) */\n    pointer-events: all;\n    flex: 0 0 auto;\n}\n\n/*  workaround for modal screen, and chrome and safari not allowing it to be\n    visible outside the .uirTranVis_history overflow while the .uirTranVis_history div is scrolled */\n.fullScreen .uirTranVis_history {\n    top: 0;\n}\n\n/* A single history entry (breadcrumb) arrow looking thing */\n.uirTranVis_history .uirTranVis_historyEntry {\n    position: relative;\n    text-align: center;\n    padding: 12px 30px;\n    margin-bottom: 6px;\n    margin-right: 6px;\n    color: #000;\n    cursor: pointer;\n}\n\n\n/* History entry arrow CSS */\n.uirTranVis_history .uirTranVis_historyEntry:before,.uirTranVis_historyEntry:after {\n    content: '';\n    position: absolute;\n    background: darkgrey;\n    left: 0;\n    height: 50.2%; /* +0.2% so firefox doesn't render a white line down the center */\n    width: 100%;\n    border: 1px solid black;\n    box-sizing: border-box;\n    z-index: -1;\n}\n\n.uirTranVis_history .uirTranVis_historyEntry:before {\n    top: 0;\n    border-bottom: 0;\n    -webkit-transform: skew(40deg, 0deg);\n    -ms-transform: skew(40deg, 0deg);\n    transform: skew(40deg, 0deg);\n}\n\n.uirTranVis_history .uirTranVis_historyEntry:after {\n    bottom: 0;\n    border-top: 0;\n    -webkit-transform: skew(-40deg, 0deg);\n    -ms-transform: skew(-40deg, 0deg);\n    transform: skew(-40deg, 0deg);\n}\n\n/*.uirTranVis_historyEntry::before height: 51% (|| ::after) */\n\n/* Styling for breadcrumb contents */\n.uirTranVis_historyEntry .uirTranVis_historyEntrySummary {\n    color: white;\n    white-space: nowrap;\n    font-size: small;\n}\n.uirTranVis_historyEntry .uirTranVis_historyEntrySummary .uirTranVis_transId {\n    position: absolute;\n    top: 3px;\n    left: 10px;\n    font-size: smaller;\n}\n.uirTranVis_historyEntry .uirTranVis_historyEntrySummary .uirTranVis_status {\n    position: absolute;\n    bottom: 3px;\n    left: 10px;\n    font-size: smaller;\n}\n.uirTranVis_historyEntry .uirTranVis_historyEntrySummary .uirTranVis_transName {\n    font-weight: bold;\n    display: flex;\n    flex-flow: row nowrap;\n    align-items: center;\n    justify-content: center\n}\n.uirTranVis_historyEntry .uirTranVis_historyEntrySummary .uirTranVis_transName span {\n    overflow: hidden;\n    text-overflow: ellipsis;\n    direction: rtl;\n}\n\n.uirTranVis_transSummary {\n    margin: 8px 0;\n}\n.uirTranVis_transSummary .uirTranVis_summaryHeading {\n    background-color: #f5f5f5;\n    margin: 8px -16px;\n    padding: 4px 16px;\n}\n.uirTranVis_transSummary .uirTranVis_summaryData {\n    display: flex;\n    flex-flow: row nowrap;\n    align-items: baseline;\n}\n.uirTranVis_transSummary .uirTranVis_summaryData span {\n    min-width: 60px;\n    text-align: right;\n    padding-right: 6px;\n}\n.uirTranVis_transSummary .uirTranVis_summaryData strong {\n    overflow: hidden;\n    text-overflow: ellipsis;\n    direction: rtl;\n}\n\n.uirTranVis_history .uirTranVis_code {\n    padding: 0px 2px;\n    color: black;\n    background: #e6e6e6;\n    margin: 0;\n    font-family: monospace;\n}\n\n/* breadcrumb/history entry color coding */\n.uirTranVis_history .uirTranVis_historyEntry:before,.uirTranVis_historyEntry:after {\n    background: #737373;\n}\n.uirTranVis_history .uirTranVis_historyEntry:hover:before,.uirTranVis_historyEntry:hover:after {\n    background: #a6a6a6;\n}\n\n.uirTranVis_history .uirTranVis_historyEntry.success:before,.uirTranVis_historyEntry.success:after {\n    background: #45803b;\n}\n.uirTranVis_history .uirTranVis_historyEntry.success:hover:before,.uirTranVis_historyEntry.success:hover:after {\n    background: #19a600;\n}\n\n\n.uirTranVis_history .uirTranVis_historyEntry.error:before,.uirTranVis_historyEntry.error:after {\n    background: #bf1f1d;\n}\n.uirTranVis_history .uirTranVis_historyEntry.error:hover:before,.uirTranVis_historyEntry.error:hover:after {\n    background: #e62622;\n}\n\n\n.uirTranVis_history .uirTranVis_historyEntry.ignored:before,.uirTranVis_historyEntry.ignored:after {\n    background: #e68b05;\n}\n.uirTranVis_history .uirTranVis_historyEntry.ignored:hover:before,.uirTranVis_historyEntry.ignored:hover:after {\n    background: #ff9808;\n}\n\n.uirTranVis_history .uirTranVis_historyEntry.redirected:before,.uirTranVis_historyEntry.redirected:after {\n    background: #e68b05;\n}\n.uirTranVis_history .uirTranVis_historyEntry.redirected:hover:before,.uirTranVis_historyEntry.redirected:hover:after {\n    background: #ff9808;\n}\n\n.uirTranVis_history .uirTranVis_keyValue {\n    display: flex;\n    flex-flow: row nowrap;\n    justify-content: space-between;\n    align-items: baseline;\n}\n\n.uirTranVis_history .uirTranVis_keyValue + .uirTranVis_keyValue {\n    margin-top: 3px;\n}\n\n\n\n\n/* The transition detail popover (when hovering over a breadcrumb) */\n.uirTranVis_transitionDetail {\n    border: 1px solid lightgrey;\n    font-size: small;\n    transition: box-shadow 0.5s ease,  border 1.0s ease\n}\n\n/* Pointer element points from the uirTranVis_transitionDetail to the breadcrumb */\n.uirTranVis_transitionDetail .uirTranVis_downArrow {\n    position: relative;\n    width: 100%;\n    bottom: -10px;\n    margin-bottom: 10px;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_downArrow:before, .uirTranVis_transitionDetail .uirTranVis_downArrow:after {\n    content: \"\";\n    position: absolute;\n    border-left: 10px solid transparent;\n    border-right: 10px solid transparent;\n    top: 100%;\n    left: 50%;\n    margin-left: -10px;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_downArrow:before {\n    border-top: 10px solid lightgray;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_downArrow:after{\n    border-top: 10px solid white;\n    margin-top: -1px;\n    z-index: 1;\n}\n\n\n/* The layout and styling of the transition detail popover */\n/*.uirTranVis_transitionDetail .panel-heading {*/\n    /*text-align: center;*/\n/*}*/\n\n.uirTranVis_transitionDetail table {\n    border-collapse: collapse;\n}\n\n.uirTranVis_transitionDetail th {\n    text-align: center;\n    font-size: small;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_heading {\n    display: flex;\n    flex-flow: row-reverse nowrap;\n    justify-content: space-between;\n    align-items: baseline;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_heading > *  {\n    flex: 0 1 auto;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_heading > * i {\n    transition: all 0.5s ease;\n}\n\n.uirTranVis_transitionDetail table.uirTranVis_paths {\n    width: 100%;\n}\n\n.uirTranVis_transitionDetail table.uirTranVis_paths td {\n    color: white;\n    border: 0;\n    font-size: small;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_transSummary .uirTranVis_keyValue > div:nth-child(2){\n    padding-left: 8px;\n    font-weight: normal;\n}\n\n\n.uirTranVis_transitionDetail td {\n    padding: 0;\n}\n\n.uirTranVis_transitionDetail td .flowArrowCell {\n    display: flex;\n    flex-flow: column nowrap;\n    align-items: stretch;\n    justify-content: space-between;\n    width: 12px;\n    transition: width 0.25s ease;\n    height: auto;\n    flex: 0 0 auto;\n}\n.uirTranVis_transitionDetail.expand td .flowArrowCell { width: 24px; }\n\n.uirTranVis_transitionDetail .exit  .flowArrowSvg          { right: 0; }\n.uirTranVis_transitionDetail .enter .flowArrowSvg          { left: 0; }\n.uirTranVis_transitionDetail        .flowArrowSvg.bottom   { bottom: 0 }\n.uirTranVis_transitionDetail        .flowArrowSvg.top      { top: 0 }\n.uirTranVis_transitionDetail        .flowArrowSvg {\n    position: absolute;\n    width: 100%;\n    height: auto;\n    transition: width 0.25s ease;\n}\n\n/* color code path elements by retained/exited/entered */\n.uirTranVis_transitionDetail .retain {\n    background-color: #737273;\n}\n\n.uirTranVis_transitionDetail .exit {\n    background-color: #7c1010;\n}\n\n.uirTranVis_transitionDetail .enter {\n    background-color: #31592a;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_deemphasize {\n    color: #eaeaea;\n    font-size: x-small;\n}\n\n/* Styling for parameter values and resolve values */\n.uirTranVis_transitionDetail .params {\n    background-color: rgba(255,255,255,0.15);\n    padding: 0;\n    opacity: 0;\n    overflow: hidden;\n    transition: opacity 1s ease;\n    max-height: 0;\n}\n\n.uirTranVis_transitionDetail.expand .params {\n    display: block;\n    border-radius: 4px;\n    box-shadow: 1px 1px 2px black;\n    padding: 8px;\n    max-height: 250px;\n    overflow-y: auto;\n    opacity: 1;\n    margin: 8px 0;\n}\n\n.uirTranVis_transitionDetail.pin {\n    box-shadow: 4px 4px 12px rgba(0,0,0,0.3);\n    border: 1px solid black;\n}\n\n.uirTranVis_transitionDetail.pin .uirTranVis_downArrow:before {\n    border-top-color: black;\n}\n\n\n/* When showing expanded details, put space between path elements */\n.uirTranVis_transitionDetail.expand table.uirTranVis_paths td {\n    max-height: 100px;\n    vertical-align: top;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_Row {\n    display: flex;\n    flex-flow: row nowrap;\n    justify-content: space-between;\n    align-items: stretch;\n    min-width: 400px;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_Row > div {\n    flex: 1 0 50%;\n    min-width: 0;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_nodeContent {\n    display: flex;\n    flex-flow: row nowrap;\n    min-height: 16px;\n    transition: min-height 0.25s ease;\n}\n\n.uirTranVis_transitionDetail.expand .uirTranVis_nodeContent {\n    height: 100%;\n    min-height: 65px;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_nodeDetail {\n    flex: 1 1 auto;\n    padding: 3px 7px;\n    min-width: 0;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_stateName {\n    font-weight: bolder;\n    margin-right: 16px;\n    margin-left: 0;\n}\n.uirTranVis_transitionDetail .enter .uirTranVis_stateName {\n    margin-right: 0;\n    margin-left: 16px;\n}\n\n.uirTranVis_transitionDetail .uirTranVis_nowrap {\n    white-space: nowrap;\n}\n\n.uirTranVis_history .uirTranVis_paramsLabel,\n.uirTranVis_history .uirTranVis_resolveLabel {\n    color: white;\n    margin-top: -8px;\n    text-align: center;\n    font-weight: bold;\n}\n\n\nspan.link {\n    cursor: pointer;\n    text-decoration: underline;\n}\n\n\n.uirTranVis_tooltipRight {\n    display: inline;\n    position: relative;\n    transition: all 1.5s ease;\n}\n\n.uirTranVis_tooltipRight:after {\n    color: rgba(0,0,0,0);\n    text-decoration: none;\n    transition: all 1.5s ease;\n}\n\n.uirTranVis_tooltipRight:hover:after {\n    bottom: 0;\n    color: rgba(0,0,0,0.5);\n    content: attr(title);\n    display: block;\n    position: absolute;\n    white-space: nowrap;\n    font-size: smaller;\n}\n\n\n\n/* Bootstrap stuff */\n\n.uirTranVis_modal .uirTranVis_btnPrimary {\n    color: #fff;\n    background-color: #337ab7;\n    border-color: #2e6da4;\n}\n\n.uirTranVis_modal .uirTranVis_btn {\n    display: inline-block;\n    padding: 6px 12px;\n    margin-bottom: 0;\n    font-size: 14px;\n    font-weight: normal;\n    line-height: 1.42857143;\n    text-align: center;\n    white-space: nowrap;\n    vertical-align: middle;\n    -ms-touch-action: manipulation;\n    touch-action: manipulation;\n    cursor: pointer;\n    -webkit-user-select: none;\n    -moz-user-select: none;\n    -ms-user-select: none;\n    user-select: none;\n    background-image: none;\n    border: 1px solid transparent;\n    border-radius: 4px;\n}\n\n.uirTranVis_modal .uirTranVis_btnXs, .uirTranVis_btnGroupXs > .uirTranVis_btn {\n    padding: 1px 5px;\n    font-size: 12px;\n    line-height: 1.5;\n    border-radius: 3px;\n}\n\n.uirTranVis_transition {\n    max-width: 550px;\n}\n\n.uirTranVis_transitionDetail span.link {\n    color: white;\n}\n\n.uirTranVis_history *:not(.fa):not(pre):not(.uirTranVis_code) {\n    font-family: Arial, Helvetica, sans-serif;\n}\n\n.uirTranVis_transitionDetail .enter .uirTranVis_heading {\n    flex-flow: row nowrap;\n}\n.uirTranVis_transitionDetail .uirTranVis_heading {\n    display: flex;\n    flex-flow: row-reverse nowrap;\n    justify-content: space-between;\n    align-items: baseline;\n}\n\n.uirTranVis_transitionDetail .retain .uirTranVis_heading {\n    justify-content: center;\n}\n\n.uirTranVis_panel {\n    margin-bottom: 20px;\n    background-color: #fff;\n    border: 1px solid lightgrey;\n    border-radius: 4px;\n    -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .05);\n    box-shadow: 0 1px 1px rgba(0, 0, 0, .05);\n}\n\n.uirTranVis_panelHeading {\n    color: #333;\n    background-color: #f5f5f5;\n    border-color: #ddd;\n\n    padding: 10px 16px;\n    border-bottom: 1px solid transparent;\n    border-top-left-radius: 3px;\n    border-top-right-radius: 3px;\n}\n\n.uirTranVis_panelTitle {\n    margin-top: 0;\n    margin-bottom: 0;\n    font-size: 16px;\n    color: inherit;\n}\n\n.uirTranVis_panelBody {\n    padding: 0 16px;\n}\n\n\n\n\n\n/* Styles go here */\n.uir-fade {\n    opacity: 0;\n    -webkit-transition: opacity .15s linear;\n    -o-transition: opacity .15s linear;\n    transition: opacity .15s linear;\n}\n\n.uir-fade.in {\n    opacity: 1;\n}\n\n.uirTranVis_modal-backdrop {\n    position: fixed;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    z-index: 1040;\n    background-color: #000;\n}\n\n.uirTranVis_modal-backdrop.in {\n    filter: alpha(opacity=50);\n    opacity: .5;\n}\n\n.uirTranVis_modal {\n    position: fixed;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    z-index: 1050;\n    display: block;\n    overflow-y: auto;\n    -webkit-overflow-scrolling: touch;\n    outline: 0;\n}\n\n\n.uirTranVis_modal-dialog {\n    position: relative;\n    width: auto;\n    margin: 10px;\n}\n\n.uirTranVis_modal-content {\n    position: relative;\n    background-color: #fff;\n    -webkit-background-clip: padding-box;\n    background-clip: padding-box;\n    border: 1px solid #999;\n    border: 1px solid rgba(0, 0, 0, .2);\n    border-radius: 6px;\n    outline: 0;\n    -webkit-box-shadow: 0 3px 9px rgba(0, 0, 0, .5);\n    box-shadow: 0 3px 9px rgba(0, 0, 0, .5);\n}\n\n.uirTranVis_modal-header {\n    padding: 16px;\n    border-bottom: 1px solid #e5e5e5;\n}\n\n.uir-resolve-header {\n    display: flex;\n    flex-flow: row nowrap;\n    justify-content: space-between;\n    background-color: cornflowerblue;\n}\n\n.uirTranVis_modalBody {\n    color: black;\n    position: relative;\n    padding: 16px;\n}\n\n.uirTranVis_modalFooter {\n    padding: 16px;\n    text-align: right;\n    border-top: 1px solid #e5e5e5;\n}\n\n.uir-icon {\n    display: inline-block;\n    height: 16px; width: 16px;\n    margin: 4px;\n    background-size: cover;\n    background-position: 0 0;\n}\n\n.uir-spin {\n    animation: uirspin 2s infinite;\n    transform: rotate(0deg);\n}\n\n.uir-rotate-35 {\n    transform: rotate(35deg);\n    opacity: 0.5;\n}\n\n@keyframes uirspin {\n    0% { transform: rotate(0deg); }\n    100% { transform: rotate(360deg); }\n}\n\n\n.uir-iconw-spinner       { background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAABCElEQVQ4ja2SMU4CYRCF34Db6RISmi04gCZacgDuYElDYcFZLLWx1c4b6BE0sbaysBEh0aCdm3w2szKQ/1cTmGSz+795897Mzm/KBGCSjv14bWbkuDmBCcuY5HitUNAGxsDQoSrwKuAAeATegVHKcexuX0AFdIELf7rAVejoranbCRpPkmpJU0kfZvYp6SQYvARu/F7pogJ2M7k94BS4BPbXkwYUSdW0WOFb+gFugVeg94/iHjADbqTlFlh7/6mzwt14hK0E0AHugbNfOOfAHVA2WLwHpaRDhdman2pmc4cGko4kdSQtUg79Rt3nnPl2CsdKoB9rYgcys+dwrCU9eEe15xdJ503iGzoj4fOiDj0FAAAAAElFTkSuQmCC\"); }\n.uir-iconw-check         { background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAAc0lEQVQ4jeXQuwmAQBCE4SvEOwOtwjK0KEEQDOzORyD28Rt4wnLoPYwEJ935Jlil/hUgB0agfItXzuyAScFG4Cu1WyqAAdARuHOxBjZ7nIFM4MWLbbFxShNQRWEx0uJPH/Osp5Ew9ozE45uRdCxGdLj1hRzpQwNP2Cwv6wAAAABJRU5ErkJggg==\"); }\n.uir-iconw-circle-o      { background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAAzElEQVQ4jaWTPQ7CMAyFnzkL7IUNRtoDlPugSkxciwlWFrr0CHCGfgw4qGrTFBVLUST7+fnnJdKfZjEnYJLWkpbuaiTdzYxJRuAA1AytBsqp5BPQesIFOPu5uK8FqlTlFngCeSSeAy/HlP2gddreJzrMHfPwPX0Dm9B2csYPNoyTSdLC/WHb1ykCSTe/V12C2RYIGr93P+RsezmDJQ4U6OCK6BI9GGR8jchYjMrYAVU/PKRjckCg9Bb79ohVjn4mJ8rkUklqzOyerDzX3pD9HgkYdWTVAAAAAElFTkSuQmCC\"); }\n.uir-iconw-share         { background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAA0UlEQVQ4jb2SvQ4BQRSFz/WXSESF0G6j8g7iAXQa4QE0ai+ip9ZIRDTeQUGjUJJ4BUs+hdlkbVixEqeZyZ05352ZM9K/BCyAzi+AA3AFuuF65s3mvKSqpLKkoivnJaUlTQHfzGZRUw4YAGvgQrz8p+sAFWDzwfQK0gwAyy/NAEfAE+AlNNeD7r3IscZAC6gB2UgKz2aXQsnNb5LaZraKSfMkqWVm+/AD9h15HmMUMAp3Di80HGAYB3inlJltJe0knRMB3DjR45clE1AAvMSAX3QHLbpPOaoNWa0AAAAASUVORK5CYII=\"); }\n.uir-iconw-close         { background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAAlElEQVQ4jd3QMQqDQBhEYU8kpBZio41pTBov5B31IEFEhC+NkkU2a7pABrYZeI+dP8v+L7ggj/Q5LmdwgxkT6qCvt25GkxKM3pk2cIf3jClBi+UgCeEF7dmM2/bVYxbck3Ag6SOC/lv4imdEMKE6g6vI5uNNPkswHODH9kLJkBJ0WHc46HfJiu5sRoki0hcok/BP8gJcS0AygPBo+gAAAABJRU5ErkJggg==\"); }\n\n.uir-icon-thumb-tack     { background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAArElEQVQ4jbXSPQ5BQRiF4cdfZQWXpdgBW1LZjaugsgoqDdFfKpVEQ2huMcb9E3GSU8yXM2/OZD5+VKtglmCMTjR/YI1THTTFs8TzJq0myHDBLbic5c0aKc29CQBpUbDdlFimvwJ6ub9SHyvcff7AHcs8U6pZwcXYs6onjBq0fMvEm5hgEJwXOGAazDLBNnYjwMn7qu5wxLasTgyItce5KlAHOOBak6lUgmFV4AV5rTJf7ROKuAAAAABJRU5ErkJggg==\"); }\n.uir-icon-toggle-on      { background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAApUlEQVQ4jcXSPQrCQBQE4E9B8Rg2gmW0UvEyegQP41XsDWirheDPIbQRtBAtTEACu4opMrDFsjPvvZl9VI1a4d5BF60A/4Y9TsWHPtZ4Bs4DG6Q4Y4VeLh7hGhEv0P5o1sQsKzSQjRMSL9EI2JngKCJ+YhwQ885vFytwRz1SAObfCD+htIVYiKlwiFMcYKjkN0LivRyxRdpmE10ybpL7+MTfq1wdXiIXWWLHZLTUAAAAAElFTkSuQmCC\"); }\n.uir-icon-toggle-off     { background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAA4UlEQVQ4jcXSsUoDURAF0JPFDWmsrOxshBQKwcqI+Re3ttLCT/AP9FsEI2gW0wqSJUEb/YKk0ybEYp+wbHbXwiIXXvFm7p2Zd+exabRK93100anhf2OG93KBI9wE8QTbOESEZ3wFXgcHmOIcL3CCOS7QLnTbwx0eEBfibVwGzbEwTlIzcowRripyCd4gs+5FEaf4rIi3kEV4xKqhwBi72CnFV3iKGoTFTo346wkDfNQUziK5q2c14hjXuK3IJdiCvuY1Dn+JAWtrhJ7crAVSvGIpNyrFfThp4IyD5v9fefP4AeEQL7aw+eK/AAAAAElFTkSuQmCC\"); }\n", {});
//#endregion
//#region src/transition/TransitionVisualizer.tsx
/**
* This outer component manages the list of all transitions (history), and provides a fixed, scrolling viewport.
* It attaches hooks for lifecycle events and decorates the transition with a descriptive message.
*/
var TransitionVisualizer = class TransitionVisualizer extends C {
	constructor(..._args) {
		super(..._args);
		this.deregisterFns = [];
		this.state = {
			transitions: [],
			pointerEvents: "auto"
		};
		this.cancelPreviousAnim = null;
		this.onMouseMove = (evt) => {
			var pointerEvents = Math.max(document.documentElement.clientHeight, window.innerHeight || 0) - evt.clientY < 65 ? "auto" : "none";
			if (this.state.pointerEvents != pointerEvents) this.setState({ pointerEvents });
		};
	}
	/**
	* Creates a new TransitionVisualizer and adds it to the document.
	*
	* @param router the UIRouter object
	* @param element (optional) the element where the TransitionVisualizer should be placed.
	*                If no element is passed, an element will be created in the body.
	* @param props maximum transitions default: { maximumTransitions: 15 }
	*
	*
	* # Angular 1 + UI-Router (1.0.0-beta.2 and higher):
	*
	* Inject the router (`$uiRouter`) in a run block, then call TransitionVisualizer.create();
	*
	* ```
	* app.run(function($uiRouter) {
	*   TransitionVisualizer.create($uiRouter);
	* });
	* ```
	*
	* # Angular 1 + UI-Router 1.0.0-alpha.1 through 1.0.0-beta.1:
	*
	* Inject the router (`ng1UIRouter`) in a run block, then call TransitionVisualizer.create();
	*
	* ```
	* app.run(function(ng1UIRouter) {
	*   TransitionVisualizer.create(ng1UIRouter);
	* });
	* ```
	*
	* Angular 2:
	*
	* Call TransitionVisualizer.create() from your UIRouterConfig
	*
	* ```
	* export class MyUIRouterConfig extends UIRouterConfig {
	*   configure(router: UIRouter) {
	*     TransitionVisualizer.create(router);
	*   }
	* }
	* ```
	*
	* React:
	*
	* Call TransitionVisualizer.create() from your bootstrap
	*
	* ```
	* let router = new UIRouterReact();
	* TransitionVisualizer.create(router);
	* router.start();
	* ```
	*
	* @return the element that was bootstrapped.
	*         You can destroy the component using:
	*         [ReactDOM.unmountComponentAtNode](https://facebook.github.io/react/docs/top-level-api.html#reactdom.unmountcomponentatnode)
	*/
	static create(router, element, props = {}) {
		if (!element) {
			element = document.createElement("div");
			element.id = "uirTransitionVisualizer";
		}
		let initialProps = Object.assign({}, props, { router });
		const _render = () => {
			document.body.appendChild(element);
			R(k(TransitionVisualizer, initialProps), element);
		};
		if (document.readyState === "interactive" || document.readyState === "complete") _render();
		else document.addEventListener("DOMContentLoaded", _render, false);
		return element;
	}
	static {
		this.defaultProps = {
			router: null,
			maximumTransitions: 15
		};
	}
	componentDidMount() {
		let dereg = this.props.router.transitionService.onBefore({}, (trans) => {
			this.setState({ transitions: this.state.transitions.concat(trans) });
			let duration = 750, el = this._div.children[0];
			let scrollToRight = () => {
				let targetScrollX = el.scrollWidth - el.clientWidth + 200;
				this.cancelPreviousAnim && this.cancelPreviousAnim();
				let newVal = [targetScrollX], oldVal = [el.scrollLeft];
				let max = this.props.maximumTransitions;
				let enforceMax = () => {
					let list = this.state.transitions;
					if (list.length <= max) return;
					this.setState({ transitions: list.slice(list.length - max) });
				};
				let callback = (vals) => el.scrollLeft = vals[0];
				this.cancelPreviousAnim = animatePath(newVal, oldVal, duration, callback, enforceMax, easing.easeInOutCubic);
			};
			setTimeout(scrollToRight, 25);
		});
		this.deregisterFns.push(dereg);
		document.body.addEventListener("mousemove", this.onMouseMove);
		this.deregisterFns.push(() => document.body.removeEventListener("mousemove", this.onMouseMove));
	}
	componentWillUnmount() {
		while (this.deregisterFns.length) this.deregisterFns.pop()();
	}
	render() {
		let pointerEvents = this.state.pointerEvents;
		return /* @__PURE__ */ k("div", { ref: (el) => {
			this._div = el;
		} }, /* @__PURE__ */ k("div", {
			className: "uirTranVis_history",
			style: { pointerEvents }
		}, this.state.transitions.map((trans) => /* @__PURE__ */ k("div", {
			key: trans.$id,
			className: "uirTranVis_transition"
		}, /* @__PURE__ */ k(TransitionView, { transition: trans }), /* @__PURE__ */ k("div", { style: {
			minWidth: "18em",
			border: "1px solid transparent"
		} }))), /* @__PURE__ */ k("div", { style: {
			width: "200px",
			height: "1px"
		} })));
	}
};
//#endregion
//#region src/visualizer.ts
const visualizer = (router) => new Visualizer(router, {});
function unmountComponent(node) {
	let Nothing = () => null;
	R(k(Nothing, null), document.body, node);
}
const DEFAULTS = {
	state: true,
	stateVisualizer: {},
	transition: true
};
var Visualizer = class {
	dispose(router) {
		this.stateVisualizerEl && unmountComponent(this.stateVisualizerEl);
		this.transitionVisualizerEl && unmountComponent(this.transitionVisualizerEl);
		this.stateVisualizerEl = null;
		this.transitionVisualizerEl = null;
	}
	constructor(router, options) {
		this.router = router;
		this.name = "visualizer";
		options = Object.assign({}, DEFAULTS, options);
		if (options.state) this.stateVisualizerEl = StateVisualizer.create(router, void 0, void 0, options.stateVisualizer);
		if (options.transition) this.transitionVisualizerEl = TransitionVisualizer.create(router);
	}
};
//#endregion
export { StateSelector, StateTree, StateVisualizer, TransitionVisualizer, Visualizer, visualizer };

//# sourceMappingURL=ui-router-visualizer.esm.js.map
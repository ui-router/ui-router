import { createRoot } from 'react-dom/client';
import { registerReactUIViewAdapter } from './ReactUIViewAdapterComponent.base';
// React 18+ adapter using createRoot API
var roots = new WeakMap();
var adapter = {
    render: function (element, container) {
        var root = roots.get(container);
        if (!root) {
            root = createRoot(container);
            roots.set(container, root);
        }
        root.render(element);
    },
    unmount: function (container) {
        var root = roots.get(container);
        if (root) {
            root.unmount();
            roots.delete(container);
        }
    },
};
registerReactUIViewAdapter(adapter);
//# sourceMappingURL=ReactUIViewAdapterComponent.js.map
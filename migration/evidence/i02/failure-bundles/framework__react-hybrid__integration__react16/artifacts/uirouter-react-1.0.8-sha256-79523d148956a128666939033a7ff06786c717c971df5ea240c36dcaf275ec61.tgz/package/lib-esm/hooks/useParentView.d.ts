import { UIViewAddress } from '../components';
/** @internal Gets the parent UIViewAddress from context, or the root UIViewAddress */
export declare function useParentView(): UIViewAddress;

/** @packageDocumentation @publicapi @module rx */
import { StateDeclaration, UIRouter, UIRouterPlugin } from '@uirouter/core';
export interface StatesChangedEvent {
    currentStates: StateDeclaration[];
    registered: StateDeclaration[];
    deregistered: StateDeclaration[];
}
/** Augments UIRouterGlobals with observables for transition starts, successful transitions, and state parameters */
export declare class UIRouterRx implements UIRouterPlugin {
    name: string;
    private deregisterFns;
    constructor(router: UIRouter);
    dispose(): void;
}
export declare const UIRouterRxPlugin: typeof UIRouterRx;

import * as React from 'react';
export interface ReactDOMAdapter {
    render: (element: React.ReactElement, container: Element) => void;
    unmount: (container: Element) => void;
}
export declare function registerReactUIViewAdapter(reactDOMAdapter: ReactDOMAdapter): void;

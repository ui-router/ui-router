/**
 * undefined
 * @version v2.0.0
 * @link https://github.com/ui-router/ui-router/tree/main/frameworks/react-hybrid/uirouter-react-hybrid#readme
 * @license MIT License, http://www.opensource.org/licenses/MIT
 */
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@uirouter/angularjs'), require('@uirouter/react'), require('react'), require('angular'), require('react-dom/client'), require('@uirouter/core'), require('react-dom')) :
    typeof define === 'function' && define.amd ? define(['exports', '@uirouter/angularjs', '@uirouter/react', 'react', 'angular', 'react-dom/client', '@uirouter/core', 'react-dom'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["@uirouter/react-hybrid"] = {}, global["@uirouter/angularjs"], global["@uirouter/react"], global.React, global.angular, global.ReactDOM, global["@uirouter/core"], global.ReactDOM));
})(this, (function (exports, angularjs, react, React, angular, client, core, ReactDOM) { 'use strict';

    function _interopNamespaceDefault(e) {
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n.default = e;
        return Object.freeze(n);
    }

    var React__namespace = /*#__PURE__*/_interopNamespaceDefault(React);
    var angular__namespace = /*#__PURE__*/_interopNamespaceDefault(angular);
    var ReactDOM__namespace = /*#__PURE__*/_interopNamespaceDefault(ReactDOM);

    var UI_ROUTER_REACT_HYBRID = 'ui.router.react.hybrid';
    var hybridModule = angular__namespace.module(UI_ROUTER_REACT_HYBRID, ['ui.router']);

    /**
     * Registers a `react` view config factory which is invoked when `view.$type === 'react'`.
     *
     * Decorates the `views: {}` registered on states.
     * Detects if a `component:` is a React Component and sets `view.$type = 'react'` if so
     */
    hybridModule.config([
        '$uiRouterProvider',
        function (router) {
            var factory = function (path, config) { return new react.ReactViewConfig(path, config); };
            // Add the react view config factory for react views
            router.viewService._pluginapi._viewConfigFactory('react', factory);
            // Decorate states at registration time with the view type
            router.stateRegistry.decorator('views', function (state, parentDecorator) {
                var views = parentDecorator(state);
                var self = state.self;
                var selfViews = self.views || { $default: self };
                var isReactComponent = function (cmp) {
                    return cmp instanceof React__namespace.Component ||
                        (cmp && cmp.prototype && cmp.prototype.isReactComponent) ||
                        (cmp && cmp.prototype && typeof cmp.prototype.render === 'function') ||
                        (cmp && typeof cmp === 'function');
                };
                Object.keys(views).forEach(function (key) {
                    var view = views[key];
                    selfViews[key || '$default'];
                    var reactType = isReactComponent(view.component) && 'react';
                    view.$type = selfViews[key].$type || reactType || view.$type;
                });
                return views;
            });
        },
    ]);

    var initialState = { router: undefined, addr: undefined };
    /**
     * Provide react context necessary for UIView, UISref and UISrefActive
     *
     * Gets the context from the parent react UIView (if component tree is all react)
     * Gets the context from the from parent angular ui-view if no parent reat UIView is available
     */
    function UIRouterContextComponent(_a) {
        var _b = _a.parentContextLevel, parentContextLevel = _b === void 0 ? '0' : _b, _c = _a.inherited, inherited = _c === void 0 ? true : _c, children = _a.children;
        var _d = React.useState(initialState), contextFromAngularJS = _d[0], setContextFromAngularJS = _d[1];
        var routerFromReactContext = React.useContext(react.UIRouterContext);
        var parentUIViewFromReactContext = React.useContext(react.UIViewContext);
        var domRef = React.useRef(null);
        // Once we have a DOM node, get the AngularJS injector and walk up the DOM to find the AngularJS $uiView
        var refCallback = function (el) {
            if (el && el !== domRef.current) {
                domRef.current = el;
                var injector = angular__namespace.element(el).injector();
                // get router from angularjs
                var router = injector === null || injector === void 0 ? void 0 : injector.get('$uiRouter');
                // get parent uiview from angularjs
                var steps = parseInt(parentContextLevel, 10);
                steps = isNaN(steps) ? 0 : steps;
                while (el && steps--)
                    el = el.parentElement;
                var $uiView = el && angular__namespace.element(el).inheritedData('$uiView');
                var addr = $uiView && new ParentUIViewAddressAdapter($uiView);
                setContextFromAngularJS({ router: router, addr: addr });
            }
        };
        // render a div once to get a ref into the dom
        // Use the dom ref to access the AngularJS state
        if (!domRef.current) {
            return React__namespace.createElement("div", { ref: refCallback });
        }
        // We know the AngularJS state. Now render the {children}
        var childrenCount = React__namespace.Children.count(children);
        var isArray = Array.isArray(children);
        return (React__namespace.createElement(react.UIRouterContext.Provider, { value: (inherited && routerFromReactContext) || contextFromAngularJS.router },
            React__namespace.createElement(react.UIViewContext.Provider, { value: (inherited && parentUIViewFromReactContext) || contextFromAngularJS.addr }, childrenCount === 1 && !isArray ? React__namespace.Children.only(children) : React__namespace.createElement("div", null, children))));
    }
    /**
     * Get the fqn and context from the parent angularjs ui-view.
     * Uses the ui-view element's data
     */
    var ParentUIViewAddressAdapter = /** @class */ (function () {
        function ParentUIViewAddressAdapter(_ngdata) {
            this._ngdata = _ngdata;
            if (!_ngdata)
                throw new Error('@uirouter/react-hybrid: Address Adapter created with no _ngdata parameter.');
        }
        Object.defineProperty(ParentUIViewAddressAdapter.prototype, "fqn", {
            get: function () {
                return this._ngdata.$uiView.fqn;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ParentUIViewAddressAdapter.prototype, "context", {
            get: function () {
                if (!this._ngdata || !this._ngdata.$cfg || !this._ngdata.$cfg.viewDecl) {
                    console.log(this._ngdata);
                    throw new Error('@uirouter/react-hybrid: Uh oh. Views are in an invalid state. Parent UIView has no $cfg or viewDecl');
                }
                return this._ngdata.$cfg.viewDecl.$context || this._ngdata.$uiView.creationContext;
            },
            enumerable: false,
            configurable: true
        });
        return ParentUIViewAddressAdapter;
    }());

    var __spreadArray$2 = (undefined && undefined.__spreadArray) || function (to, from, pack) {
        if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
        return to.concat(ar || Array.prototype.slice.call(from));
    };
    var debugLog = function (angularOrReact, component, id, method, message) {
        var args = [];
        for (var _i = 5; _i < arguments.length; _i++) {
            args[_i - 5] = arguments[_i];
        }
        if (window && window['debugReactHybrid'] !== true)
            return;
        console.log.apply(console, __spreadArray$2(["".concat(core.padString(12, angularOrReact), " ").concat(core.padString(40, "".concat(component, "[").concat(id, "]")), " ").concat(core.padString(35, "".concat(method, ":")), " ").concat(message)], args, false));
    };

    var __assign$4 = (undefined && undefined.__assign) || function () {
        __assign$4 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$4.apply(this, arguments);
    };
    var __rest$1 = (undefined && undefined.__rest) || function (s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    };
    var InternalUIView = react.UIView.__internalViewComponent;
    var ReactUIView = function (_a) {
        var refFn = _a.refFn, props = __rest$1(_a, ["refFn"]);
        debugLog('react', 'ReactUIView', "?/".concat(props['name']), '.render()', '');
        // InternalUIView is an internal API that accepts ref, but its types don't expose it
        var internalProps = __assign$4(__assign$4({}, props), { ref: refFn });
        return (React__namespace.createElement(UIRouterContextComponent, { parentContextLevel: "3", inherited: false },
            React__namespace.createElement(InternalUIView, __assign$4({}, internalProps))));
    };

    var __assign$3 = (undefined && undefined.__assign) || function () {
        __assign$3 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$3.apply(this, arguments);
    };
    var __spreadArray$1 = (undefined && undefined.__spreadArray) || function (to, from, pack) {
        if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
        return to.concat(ar || Array.prototype.slice.call(from));
    };
    function registerReactUIViewAdapter(reactDOMAdapter) {
        // When an angularjs `ui-view` is instantiated, also create an react-ui-view-adapter (which creates a react UIView)
        hybridModule.directive('uiView', function () {
            return {
                restrict: 'AE',
                compile: function (tElem, tAttrs) {
                    var name = tAttrs.name, uiView = tAttrs.uiView;
                    name = name || uiView || '$default';
                    debugLog('angularjs', 'ui-view', '?', '.compile()', 'Creating react-ui-view-adapter', tElem);
                    tElem.html("<react-ui-view-adapter name=\"".concat(name, "\"></react-ui-view-adapter>"));
                },
            };
        });
        var id = 0;
        // This angularjs adapter (inside an angularjs ui-view) creates the react UIView and provides it the correct context
        // It also allows angularjs children created inside the react view (via angular2react or whatever) to access the correct
        // context from the react UIView
        hybridModule.directive('reactUiViewAdapter', function () {
            return {
                restrict: 'E',
                link: function (scope, elem, attrs) {
                    var debug = function (method, message) {
                        var args = [];
                        for (var _i = 2; _i < arguments.length; _i++) {
                            args[_i - 2] = arguments[_i];
                        }
                        return debugLog.apply(void 0, __spreadArray$1(['angularjs', 'react-ui-view-adapter', "".concat($id, "/").concat(attrs.name), method, message], args, false));
                    };
                    var el = elem[0];
                    var _ref = null;
                    var destroyed = false;
                    var $id = id++;
                    var ignoredAttrKeys = ['$$element', '$attr'];
                    attrs = core.filter(attrs, function (val, key) { return ignoredAttrKeys.indexOf(key) === -1; });
                    debug('.link()', 'linking react-ui-view-adapter into ', el, attrs);
                    // The UIView ref callback, which is called after the initial render
                    // the ref value will be the component instance
                    var ref = function (ref) {
                        // If refs are the same - don't re-render React component.
                        var isSameRef = ref && _ref === ref;
                        // If previously there was a ref, and the new `ref` is empty - the component was unmounted.
                        // Leave the unmounted component as it was, and don't try to re-mount it.
                        var isComponentUnmounted = !ref && _ref;
                        if (isSameRef || isComponentUnmounted) {
                            return;
                        }
                        _ref = ref;
                        debug('.ref()', 'Received new React UIView ref', ref);
                        // Add the $uiView data to the adapter element to provide context to child angular elements
                        provideContextToAngularJSChildren();
                        renderReactUIView();
                    };
                    // The render callback for the React UIView
                    var render = function (cmp, props) {
                        debug('.render()', "has ref: ".concat(!!_ref));
                        provideContextToAngularJSChildren();
                        // Only create the children when the _ref is ready
                        return !_ref ? null : React__namespace.createElement(cmp, props);
                    };
                    var provideContextToAngularJSChildren = function () {
                        var _a;
                        var $cfg = (_a = _ref === null || _ref === void 0 ? void 0 : _ref.uiViewData) === null || _a === void 0 ? void 0 : _a.config;
                        var $uiView = _ref === null || _ref === void 0 ? void 0 : _ref.uiViewAddress;
                        debug('.provideContextToAngularJSChildren', '', el, $cfg, $uiView);
                        if (!$cfg || !$uiView) {
                            elem.removeData('$uiView');
                        }
                        else {
                            elem.data('$uiView', { $cfg: $cfg, $uiView: $uiView });
                        }
                    };
                    function renderReactUIView() {
                        if (destroyed) {
                            debug('.renderReactUIView()', "already destroyed -- will not render React UIView");
                            return;
                        }
                        var childUIViewProps = __assign$3(__assign$3({}, attrs), { render: render, wrap: false, refFn: ref });
                        var portalView = scope.$uiRouterReactHybridPortalView;
                        if (portalView) {
                            debug('.renderReactUIView()', "will createPortalToChildUIView({ name: '".concat(childUIViewProps['name'], "' })"), el);
                            portalView.createPortalToChildUIView($id, { childUIViewProps: childUIViewProps, portalTarget: el });
                        }
                        else {
                            debug('.renderReactUIView()', "rendering <ReactUIView name=\"".concat(childUIViewProps['name'], "\"/>"), el);
                            var element = React__namespace.createElement(ReactUIView, __assign$3({}, childUIViewProps));
                            reactDOMAdapter.render(element, el);
                        }
                    }
                    scope.$on('$destroy', function () {
                        destroyed = true;
                        var portalView = scope.$uiRouterReactHybridPortalView;
                        if (portalView) {
                            portalView.removePortalToChildUIView($id);
                        }
                        else {
                            reactDOMAdapter.unmount(el);
                            debug('.$on("$destroy")', "unmounted", el);
                        }
                        // Remove using jQLite element for cross-browser compatibility.
                        elem.remove();
                    });
                    renderReactUIView();
                },
            };
        });
    }

    // React 18+ adapter using createRoot API
    var roots = new WeakMap();
    var adapter = {
        render: function (element, container) {
            var root = roots.get(container);
            if (!root) {
                root = client.createRoot(container);
                roots.set(container, root);
            }
            root.render(element);
        },
        unmount: function (container) {
            var root = roots.get(container);
            if (root) {
                root.unmount();
                roots.delete(container);
            }
        },
    };
    registerReactUIViewAdapter(adapter);

    var __extends$1 = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __assign$2 = (undefined && undefined.__assign) || function () {
        __assign$2 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$2.apply(this, arguments);
    };
    var __rest = (undefined && undefined.__rest) || function (s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    };
    var $rootScope, $compile;
    hybridModule.run([
        '$injector',
        function (_$injector_) {
            $rootScope = _$injector_.get('$rootScope');
            $compile = _$injector_.get('$compile');
        },
    ]);
    /**
     * A React component which renders an AngularJS <ui-view>
     * This was heavily influenced by https://github.com/coatue-oss/angular2react
     */
    var AngularUIView = /** @class */ (function (_super) {
        __extends$1(AngularUIView, _super);
        function AngularUIView(props) {
            var _this = _super.call(this, props) || this;
            _this.$scope = $rootScope.$new();
            _this.$scope.$uiRouterReactHybridPortalView = _this.props.portalView;
            return _this;
        }
        AngularUIView.prototype.componentWillUnmount = function () {
            this.$scope.$destroy();
        };
        AngularUIView.prototype.render = function () {
            var _this = this;
            var _a = this.props, className = _a.className, restProps = __rest(_a, ["className"]);
            var ref = function (htmlRef) { return $compile(htmlRef)(_this.$scope); };
            var props = __assign$2(__assign$2({}, restProps), { class: className, ref: ref });
            return React__namespace.createElement('ui-view', props);
        };
        /** Only render once */
        AngularUIView.prototype.shouldComponentUpdate = function () {
            return false;
        };
        return AngularUIView;
    }(React__namespace.Component));

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __assign$1 = (undefined && undefined.__assign) || function () {
        __assign$1 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$1.apply(this, arguments);
    };
    var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
        if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
        return to.concat(ar || Array.prototype.slice.call(from));
    };
    var id = 0;
    /**
     * This react component renders the AngularUIView react component
     * and also creates React Portals as needed for child React UIViews.
     */
    var PortalView = /** @class */ (function (_super) {
        __extends(PortalView, _super);
        function PortalView() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.$id = id++;
            _this.state = { portals: [] };
            _this.debug = function (method, message) {
                var args = [];
                for (var _i = 2; _i < arguments.length; _i++) {
                    args[_i - 2] = arguments[_i];
                }
                return debugLog.apply(void 0, __spreadArray(['react', 'PortalView', "".concat(_this.$id, "/").concat(_this.props['name']), method, message], args, false));
            };
            _this.createPortalToChildUIView = function (uiViewId, childUIView) {
                _this.debug('.createPortalToChildUIView()', JSON.stringify(childUIView.childUIViewProps), childUIView.portalTarget);
                _this.setState(function (prev) {
                    var _a;
                    var portals = __assign$1(__assign$1({}, prev.portals), (_a = {}, _a[uiViewId] = childUIView, _a));
                    return { portals: portals };
                });
            };
            _this.removePortalToChildUIView = function (uiViewId) {
                var childUIView = _this.state.portals[uiViewId] || {};
                _this.debug('.removePortalToChildUIView()', "".concat(uiViewId), childUIView.childUIViewProps, childUIView.portalTarget);
                _this.setState(function (prev) {
                    var portals = __assign$1({}, prev.portals);
                    delete portals[uiViewId];
                    return { portals: portals };
                });
            };
            return _this;
        }
        PortalView.prototype.componentWillUnmount = function () {
            this.debug('.componentWillUnmount()', '');
        };
        PortalView.prototype.renderPortals = function () {
            var _this = this;
            var portals = this.state.portals;
            var method = ".renderPortals()";
            Object.keys(portals).forEach(function (key) {
                var portal = portals[key];
                _this.debug(method, "ReactDOM.createPortal(".concat(key, ")"), '', portal.childUIViewProps, portal.portalTarget);
            });
            return Object.keys(portals).map(function (key) {
                var portal = portals[key];
                // No mechanism to provide a key when creating a portals array?
                return (React__namespace.createElement("div", { style: { display: 'none' }, key: "".concat(key) }, ReactDOM__namespace.createPortal(React__namespace.createElement(ReactUIView, __assign$1({}, portal.childUIViewProps)), portal.portalTarget)));
            });
        };
        PortalView.prototype.render = function () {
            this.debug('.render()', '');
            return (React__namespace.createElement(React__namespace.Fragment, null,
                React__namespace.createElement(AngularUIView, __assign$1({}, this.props, { portalView: this })),
                this.renderPortals()));
        };
        return PortalView;
    }(React__namespace.PureComponent));

    var __assign = (undefined && undefined.__assign) || function () {
        __assign = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    var realRender = react.UIView.prototype.render;
    /**
     * Monkey patches the @uirouter/react UIView such that:
     *
     * When a @uirouter/react `<UIView/>` is rendered (from react code),
     * it renders first to an AngularJS `<ui-view>` component,
     * inside the `ui-view` is an AngularJS `<react-ui-view-adapter>`,
     * which finally renders a real @uirouter/react `<UIView/>`:
     *
     * <ui-view name="name">
     *   <react-ui-view-adapter name="name">
     *     <UIView wrap={false} name="name">
     *       <RoutedReactComponent/>
     *     </UIView>
     *   </react-ui-view-adapter>
     * </ui-view>
     */
    react.UIView.prototype.render = function () {
        if (this.props.wrap === false) {
            var id = "".concat(this.$id, "/").concat(this.props['name']);
            debugLog('react', 'UIViewMonkeyPatch', id, '.render()', 'realRender.apply(this, arguments)');
            return realRender.apply(this, arguments);
        }
        return React__namespace.createElement(PortalView, __assign({}, this.props));
    };

    /**
     * A decorator that provides the UIRouter state context allowing
     * React components to use the @uirouter/react components such as UISref
     *
     * Example:
     *
     * import { UISref, UISrefActive, UIView } from '@uirouter/react';
     *
     * @UIRouterContext
     * class MyComponent extends React.Component<any, any> {
     *   render() {
     *     return (
     *       <UISrefActive class="active">
     *         <UISref to=".neststate" params={{ id: this.props.someid }}>
     *           <a>Go to item {this.props.someid}</a>
     *         </UISref>
     *       </UISrefActive>
     *
     *       <UIView/>
     *     )
     *   }
     * }
     *
     * @param Component the react component to wrap
     */
    function UIRouterContext(Component) {
        return function (props) { return React__namespace.createElement(UIRouterContextComponent, null, React__namespace.createElement(Component, props)); };
    }

    exports.UIRouterContext = UIRouterContext;
    exports.UIRouterContextComponent = UIRouterContextComponent;
    exports.UI_ROUTER_REACT_HYBRID = UI_ROUTER_REACT_HYBRID;
    exports.hybridModule = hybridModule;

}));
//# sourceMappingURL=ui-router-react-hybrid.js.map

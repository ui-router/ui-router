export declare const debugLog: (angularOrReact: 'angularjs' | 'react', component: string, id: string, method: string, message: string, ...args: any[]) => void;

import * as _uirouter_core from '@uirouter/core';
import { ViewContext, UIRouter, StateDeclaration, ViewConfig, StateOrName, TransitionOptions, TargetState, Obj, UIRouterGlobals, UrlRuleHandlerFn, TargetStateDef, TransitionService, Transition, LazyLoadResult, HookResult, _ViewDeclaration, StateRegistry, StateService, UrlMatcherFactory, UrlRouter, UrlService, ViewService, StateObject, BuilderFunction, PathNode } from '@uirouter/core';
export * from '@uirouter/core';
import * as i0 from '@angular/core';
import { OnInit, OnDestroy, ViewContainerRef, ComponentRef, ElementRef, Renderer2, OnChanges, SimpleChanges, EventEmitter, InjectionToken, Injector, ModuleWithProviders, Provider, Type, NgModuleRef, Component, EnvironmentProviders } from '@angular/core';
import { ReplaySubject } from 'rxjs';
import { LocationStrategy, PathLocationStrategy, HashLocationStrategy } from '@angular/common';
import * as _uirouter_angular from '@uirouter/angular';

/** @internal These are provide()d as the string UIView.PARENT_INJECT */
interface ParentUIViewInject {
    context: ViewContext;
    fqn: string;
}
/**
 * A UI-Router viewport directive, which is filled in by a view (component) on a state.
 *
 * ### Selector
 *
 * A `ui-view` directive can be created as an element: `<ui-view></ui-view>` or as an attribute: `<div ui-view></div>`.
 *
 * ### Purpose
 *
 * This directive is used in a Component template (or as the root component) to create a viewport.  The viewport
 * is filled in by a view (as defined by a [[Ng2ViewDeclaration]] inside a [[Ng2StateDeclaration]]) when the view's
 * state has been activated.
 *
 * #### Example:
 * ```js
 * // This app has two states, 'foo' and 'bar'
 * stateRegistry.register({ name: 'foo', url: '/foo', component: FooComponent });
 * stateRegistry.register({ name: 'bar', url: '/bar', component: BarComponent });
 * ```
 * ```html
 * <!-- This ui-view will be filled in by the foo state's component or
 *      the bar state's component when the foo or bar state is activated -->
 * <ui-view></ui-view>
 * ```
 *
 * ### Named ui-views
 *
 * A `ui-view` may optionally be given a name via the attribute value: `<div ui-view='header'></div>`.  *Note:
 * an unnamed `ui-view` is internally named `$default`*.   When a `ui-view` has a name, it will be filled in
 * by a matching named view.
 *
 * #### Example:
 * ```js
 * stateRegistry.register({
 *   name: 'foo',
 *   url: '/foo',
 *   views: { header: HeaderComponent, $default: FooComponent });
 * ```
 * ```html
 * <!-- When 'foo' state is active, filled by HeaderComponent -->
 * <div ui-view="header"></div>
 *
 * <!-- When 'foo' state is active, filled by FooComponent -->
 * <ui-view></ui-view>
 * ```
 */
declare class UIView implements OnInit, OnDestroy {
    router: UIRouter;
    viewContainerRef: ViewContainerRef;
    static PARENT_INJECT: string;
    _componentTarget: ViewContainerRef;
    name: string;
    set _name(val: string);
    /** The reference to the component currently inside the viewport */
    readonly _componentRef: i0.WritableSignal<ComponentRef<any>>;
    /** Deregisters the ui-view from the view service */
    private _deregisterUIView;
    /** Deregisters the master uiCanExit transition hook (returns Function from @uirouter/core) */
    private _deregisterUiCanExitHook;
    /** Deregisters the master uiOnParamsChanged transition hook (returns Function from @uirouter/core) */
    private _deregisterUiOnParamsChangedHook;
    /** Data about the this UIView */
    private _uiViewData;
    private _parent;
    constructor(router: UIRouter, parent: any, viewContainerRef: ViewContainerRef);
    /**
     * @returns the UI-Router `state` that is filling this uiView, or `undefined`.
     */
    get state(): StateDeclaration;
    ngOnInit(): void;
    /**
     * For each transition, checks the component loaded in the ui-view for:
     *
     * - has a uiCanExit() component hook
     * - is being exited
     *
     * If both are true, adds the uiCanExit component function as a hook to that singular Transition.
     */
    private _invokeUiCanExitHook;
    /**
     * For each transition, checks if any param values changed and notify component
     */
    private _invokeUiOnParamsChangedHook;
    private _disposeLast;
    ngOnDestroy(): void;
    /**
     * The view service is informing us of an updated ViewConfig
     * (usually because a transition activated some state and its views)
     */
    _viewConfigUpdated(config: ViewConfig): void;
    private _applyUpdatedConfig;
    /**
     * Creates a new Injector for a routed component.
     *
     * Adds resolve values to the Injector
     * Adds providers from the NgModule for the state
     * Adds providers from the parent Component in the component tree
     * Adds a PARENT_INJECT view context object
     *
     * @returns an Injector
     */
    private _getComponentInjector;
    /**
     * Supplies component inputs with resolve data
     *
     * Finds component inputs which match resolves (by name) and sets the input value
     * to the resolve data.
     */
    private _applyInputBindings;
    static ɵfac: i0.ɵɵFactoryDeclaration<UIView, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UIView, "ui-view, [ui-view]", ["uiView"], { "name": { "alias": "name"; "required": false; }; "_name": { "alias": "ui-view"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/**
 * @internal
 * # blah blah blah
 */
declare class AnchorUISref {
    _el: ElementRef;
    _renderer: Renderer2;
    constructor(_el: ElementRef, _renderer: Renderer2);
    openInNewTab(): boolean;
    update(href: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnchorUISref, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AnchorUISref, "a[uiSref]", never, {}, {}, never, never, true, never>;
}
/**
 * A directive when clicked, initiates a [[Transition]] to a [[TargetState]].
 *
 * ### Purpose
 *
 * This directive is applied to anchor tags (`<a>`) or any other clickable element.  It is a state reference (or sref --
 * similar to an href).  When clicked, the directive will transition to that state by calling [[StateService.go]],
 * and optionally supply state parameter values and transition options.
 *
 * When this directive is on an anchor tag, it will also add an `href` attribute to the anchor.
 *
 * ### Selector
 *
 * - `[uiSref]`: The directive is created as an attribute on an element, e.g., `<a uiSref></a>`
 *
 * ### Inputs
 *
 * - `uiSref`: the target state's name, e.g., `uiSref="foostate"`.  If a component template uses a relative `uiSref`,
 * e.g., `uiSref=".child"`, the reference is relative to that component's state.
 *
 * - `uiParams`: any target state parameter values, as an object, e.g., `[uiParams]="{ fooId: bar.fooId }"`
 *
 * - `uiOptions`: [[TransitionOptions]], e.g., `[uiOptions]="{ inherit: false }"`
 *
 * @example
 * ```html
 *
 * <!-- Targets bar state' -->
 * <a uiSref="bar">Bar</a>
 *
 * <!-- Assume this component's state is "foo".
 *      Relatively targets "foo.child" -->
 * <a uiSref=".child">Foo Child</a>
 *
 * <!-- Targets "bar" state and supplies parameter value -->
 * <a uiSref="bar" [uiParams]="{ barId: foo.barId }">Bar {{foo.barId}}</a>
 *
 * <!-- Targets "bar" state and parameter, doesn't inherit existing parameters-->
 * <a uiSref="bar" [uiParams]="{ barId: foo.barId }" [uiOptions]="{ inherit: false }">Bar {{foo.barId}}</a>
 * ```
 */
declare class UISref implements OnChanges {
    /**
     * `@Input('uiSref')` The name of the state to link to
     *
     * ```html
     * <a uiSref="hoome">Home</a>
     * ```
     */
    state: StateOrName;
    /**
     * `@Input('uiParams')` The parameter values to use (as key/values)
     *
     * ```html
     * <a uiSref="book" [uiParams]="{ bookId: book.id }">Book {{ book.name }}</a>
     * ```
     */
    params: any;
    /**
     * `@Input('uiOptions')` The transition options
     *
     * ```html
     * <a uiSref="books" [uiOptions]="{ reload: true }">Book {{ book.name }}</a>
     * ```
     */
    options: TransitionOptions;
    /**
     * An observable (ReplaySubject) of the state this UISref is targeting.
     * When the UISref is clicked, it will transition to this [[TargetState]].
     */
    targetState$: ReplaySubject<TargetState>;
    /** @internal */ private _emit;
    /** @internal */ private _statesSub;
    /** @internal */ private _router;
    /** @internal */ private _anchorUISref;
    /** @internal */ private _parent;
    constructor(_router: UIRouter, _anchorUISref: AnchorUISref, parent: ParentUIViewInject);
    /** @internal */
    set uiSref(val: StateOrName);
    /** @internal */
    set uiParams(val: Obj);
    /** @internal */
    set uiOptions(val: TransitionOptions);
    ngOnInit(): void;
    ngOnChanges(_changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private update;
    getOptions(): any;
    /** When triggered by a (click) event, this function transitions to the UISref's target state */
    go(button: number, ctrlKey: boolean, metaKey: boolean): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UISref, [null, { optional: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UISref, "[uiSref]", ["uiSref"], { "state": { "alias": "uiSref"; "required": false; }; "params": { "alias": "uiParams"; "required": false; }; "options": { "alias": "uiOptions"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * UISref status emitted from [[UISrefStatus]]
 */
interface SrefStatus {
    /** The sref's target state (or one of its children) is currently active */
    active: boolean;
    /** The sref's target state is currently active */
    exact: boolean;
    /** A transition is entering the sref's target state */
    entering: boolean;
    /** A transition is exiting the sref's target state */
    exiting: boolean;
    /** The enclosed sref(s) target state(s) */
    targetStates: TargetState[];
}
/**
 * A directive which emits events when a paired [[UISref]] status changes.
 *
 * This directive is primarily used by the [[UISrefActive]] directives to monitor `UISref`(s).
 *
 * This directive shares two attribute selectors with `UISrefActive`:
 *
 * - `[uiSrefActive]`
 * - `[uiSrefActiveEq]`.
 *
 * Thus, whenever a `UISrefActive` directive is created, a `UISrefStatus` directive is also created.
 *
 * Most apps should simply use `UISrefActive`, but some advanced components may want to process the
 * [[SrefStatus]] events directly.
 *
 * ```js
 * <li (uiSrefStatus)="onSrefStatusChanged($event)">
 *   <a uiSref="book" [uiParams]="{ bookId: book.id }">Book {{ book.name }}</a>
 * </li>
 * ```
 *
 * The `uiSrefStatus` event is emitted whenever an enclosed `uiSref`'s status changes.
 * The event emitted is of type [[SrefStatus]], and has boolean values for `active`, `exact`, `entering`, and `exiting`; also has a [[StateOrName]] `identifier`value.
 *
 * The values from this event can be captured and stored on a component (then applied, e.g., using ngClass).
 *
 * ---
 *
 * A single `uiSrefStatus` can enclose multiple `uiSref`.
 * Each status boolean (`active`, `exact`, `entering`, `exiting`) will be true if *any of the enclosed `uiSref` status is true*.
 * In other words, all enclosed `uiSref` statuses  are merged to a single status using `||` (logical or).
 *
 * ```js
 * <li (uiSrefStatus)="onSrefStatus($event)" uiSref="admin">
 *   Home
 *   <ul>
 *     <li> <a uiSref="admin.users">Users</a> </li>
 *     <li> <a uiSref="admin.groups">Groups</a> </li>
 *   </ul>
 * </li>
 * ```
 *
 * In the above example, `$event.active === true` when either `admin.users` or `admin.groups` is active.
 *
 * ---
 *
 * This API is subject to change.
 */
declare class UISrefStatus {
    /** current statuses of the state/params the uiSref directive is linking to */
    uiSrefStatus: EventEmitter<SrefStatus>;
    /** Monitor all child components for UISref(s) */
    private _srefs;
    /** The current status */
    status: SrefStatus;
    /** @internal */ private _subscription;
    /** @internal */ private _srefChangesSub;
    /** @internal */ private _srefs$;
    /** @internal */ private _globals;
    /** @internal */ private _hostUiSref;
    constructor(_hostUiSref: UISref, _globals: UIRouterGlobals);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    private _setStatus;
    static ɵfac: i0.ɵɵFactoryDeclaration<UISrefStatus, [{ optional: true; host: true; self: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UISrefStatus, "[uiSrefStatus]", ["uiSrefStatus"], {}, { "uiSrefStatus": "uiSrefStatus"; }, ["_srefs"], never, true, never>;
}

/**
 * A directive that adds a CSS class when its associated `uiSref` link is active.
 *
 * ### Purpose
 *
 * This directive should be paired with one (or more) [[UISref]] directives.
 * It will apply a CSS class to its element when the state the `uiSref` targets is activated.
 *
 * This can be used to create navigation UI where the active link is highlighted.
 *
 * ### Selectors
 *
 * - `[uiSrefActive]`: When this selector is used, the class is added when the target state or any
 * child of the target state is active
 * - `[uiSrefActiveEq]`: When this selector is used, the class is added when the target state is
 * exactly active (the class is not added if a child of the target state is active).
 *
 * ### Inputs
 *
 * - `uiSrefActive`/`uiSrefActiveEq`: one or more CSS classes to add to the element, when the `uiSref` is active
 *
 * #### Example:
 * The anchor tag has the `active` class added when the `foo` state is active.
 * ```html
 * <a uiSref="foo" uiSrefActive="active">Foo</a>
 * ```
 *
 * ### Matching parameters
 *
 * If the `uiSref` includes parameters, the current state must be active, *and* the parameter values must match.
 *
 * #### Example:
 * The first anchor tag has the `active` class added when the `foo.bar` state is active and the `id` parameter
 * equals 25.
 * The second anchor tag has the `active` class added when the `foo.bar` state is active and the `id` parameter
 * equals 32.
 * ```html
 * <a uiSref="foo.bar" [uiParams]="{ id: 25 }" uiSrefActive="active">Bar #25</a>
 * <a uiSref="foo.bar" [uiParams]="{ id: 32 }" uiSrefActive="active">Bar #32</a>
 * ```
 *
 * #### Example:
 * A list of anchor tags are created for a list of `bar` objects.
 * An anchor tag will have the `active` class when `foo.bar` state is active and the `id` parameter matches
 * that object's `id`.
 * ```html
 * <li *ngFor="let bar of bars">
 *   <a uiSref="foo.bar" [uiParams]="{ id: bar.id }" uiSrefActive="active">Bar #{{ bar.id }}</a>
 * </li>
 * ```
 *
 * ### Multiple uiSrefs
 *
 * A single `uiSrefActive` can be used for multiple `uiSref` links.
 * This can be used to create (for example) a drop down navigation menu, where the menui is highlighted
 * if *any* of its inner links are active.
 *
 * The `uiSrefActive` should be placed on an ancestor element of the `uiSref` list.
 * If anyof the `uiSref` links are activated, the class will be added to the ancestor element.
 *
 * #### Example:
 * This is a dropdown nagivation menu for "Admin" states.
 * When any of `admin.users`, `admin.groups`, `admin.settings` are active, the `<li>` for the dropdown
 * has the `dropdown-child-active` class applied.
 * Additionally, the active anchor tag has the `active` class applied.
 * ```html
 * <ul class="dropdown-menu">
 *   <li uiSrefActive="dropdown-child-active" class="dropdown admin">
 *     Admin
 *     <ul>
 *       <li><a uiSref="admin.users" uiSrefActive="active">Users</a></li>
 *       <li><a uiSref="admin.groups" uiSrefActive="active">Groups</a></li>
 *       <li><a uiSref="admin.settings" uiSrefActive="active">Settings</a></li>
 *     </ul>
 *   </li>
 * </ul>
 * ```
 */
declare class UISrefActive {
    private _classes;
    set active(val: string);
    private _classesEq;
    set activeEq(val: string);
    private _subscription;
    constructor(uiSrefStatus: UISrefStatus, rnd: Renderer2, host: ElementRef);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UISrefActive, [null, null, { host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UISrefActive, "[uiSrefActive],[uiSrefActiveEq]", never, { "active": { "alias": "uiSrefActive"; "required": false; }; "activeEq": { "alias": "uiSrefActiveEq"; "required": false; }; }, {}, never, never, true, [{ directive: typeof UISrefStatus; inputs: {}; outputs: { "uiSrefStatus": "uiSrefStatus"; }; }]>;
}

/** @internal */
declare const _UIROUTER_DIRECTIVES: (typeof UIView | typeof UISref | typeof AnchorUISref | typeof UISrefActive | typeof UISrefStatus)[];
/**
 * References to the UI-Router directive classes, for use within a @Component's `directives:` property
 * @deprecated use [[UIRouterModule]]
 * @internal
 */
declare const UIROUTER_DIRECTIVES: (typeof UIView | typeof UISref | typeof AnchorUISref | typeof UISrefActive | typeof UISrefStatus)[];

/** @hidden */ declare const UIROUTER_ROOT_MODULE: InjectionToken<unknown>;
/** @hidden */ declare const UIROUTER_MODULE_TOKEN: InjectionToken<unknown>;
/** @hidden */ declare const UIROUTER_STATES: InjectionToken<unknown>;

declare function onTransitionReady(transitionService: TransitionService, root: RootModule[]): () => Promise<unknown>;
declare function makeRootProviders(module: RootModule): Provider[];
declare function makeChildProviders(module: StatesModule): Provider[];
declare function locationStrategy(useHash: any): {
    provide: typeof LocationStrategy;
    useClass: typeof PathLocationStrategy | typeof HashLocationStrategy;
};
/**
 * Creates UI-Router Modules
 *
 * This class has two static factory methods which create UIRouter Modules.
 * A UI-Router Module is an [Angular NgModule](https://angular.io/docs/ts/latest/guide/ngmodule.html)
 * with support for UI-Router.
 *
 * ### UIRouter Directives
 *
 * When a UI-Router Module is imported into a `NgModule`, that module's components
 * can use the UIRouter Directives such as [[UIView]], [[UISref]], [[UISrefActive]].
 *
 * ### State Definitions
 *
 * State definitions found in the `states:` property are provided to the Dependency Injector.
 * This enables UI-Router to automatically register the states with the [[StateRegistry]] at bootstrap (and during lazy load).
 */
declare class UIRouterModule {
    /**
     * Creates a UI-Router Module for the root (bootstrapped) application module to import
     *
     * This factory function creates an [Angular NgModule](https://angular.io/docs/ts/latest/guide/ngmodule.html)
     * with UI-Router support.
     *
     * The `forRoot` module should be added to the `imports:` of the `NgModule` being bootstrapped.
     * An application should only create and import a single `NgModule` using `forRoot()`.
     * All other modules should be created using [[UIRouterModule.forChild]].
     *
     * Unlike `forChild`, an `NgModule` returned by this factory provides the [[UIRouter]] singleton object.
     * This factory also accepts root-level router configuration.
     * These are the only differences between `forRoot` and `forChild`.
     *
     * Example:
     * ```js
     * let routerConfig = {
     *   otherwise: '/home',
     *   states: [homeState, aboutState]
     * };
     *
     * @ NgModule({
     *   imports: [
     *     BrowserModule,
     *     UIRouterModule.forRoot(routerConfig),
     *     FeatureModule1
     *   ]
     * })
     * class MyRootAppModule {}
     *
     * browserPlatformDynamic.bootstrapModule(MyRootAppModule);
     * ```
     *
     * @param config declarative UI-Router configuration
     * @returns an `NgModule` which provides the [[UIRouter]] singleton instance
     */
    static forRoot(config?: RootModule): ModuleWithProviders<UIRouterModule>;
    /**
     * Creates an `NgModule` for a UIRouter module
     *
     * This function creates an [Angular NgModule](https://angular.io/docs/ts/latest/guide/ngmodule.html)
     * with UI-Router support.
     *
     * #### Example:
     * ```js
     * var homeState = { name: 'home', url: '/home', component: Home };
     * var aboutState = { name: 'about', url: '/about', component: About };
     *
     * @ NgModule({
     *   imports: [
     *     UIRouterModule.forChild({ states: [ homeState, aboutState ] }),
     *     SharedModule,
     *   ],
     *   declarations: [ Home, About ],
     * })
     * export class AppModule {};
     * ```
     *
     * @param module UI-Router module options
     * @returns an `NgModule`
     */
    static forChild(module?: StatesModule): ModuleWithProviders<UIRouterModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UIRouterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UIRouterModule, never, [typeof UISref, typeof AnchorUISref, typeof UIView, typeof UISrefActive, typeof UISrefStatus], [typeof UISref, typeof AnchorUISref, typeof UIView, typeof UISrefActive, typeof UISrefStatus]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UIRouterModule>;
}
/**
 * UI-Router declarative configuration which can be provided to [[UIRouterModule.forRoot]]
 */
interface RootModule extends StatesModule {
    /**
     * Chooses a `LocationStrategy`.
     *
     * The location strategy enables either HTML5 Push State
     * (Requires server-side support) or "HashBang" URLs.
     *
     * When `false`, uses [`PathLocationStrategy`](https://angular.io/docs/ts/latest/api/common/index/PathLocationStrategy-class.html)
     * When `true`, uses [`HashLocationStrategy`](https://angular.io/docs/ts/latest/api/common/index/HashLocationStrategy-class.html)
     *
     * Defaults to `false`
     */
    useHash?: boolean;
    /**
     * Configures the `otherwise` rule, which chooses the state or URL to activate when no other routes matched.
     *
     * See: [[UrlRulesApi.otherwise]].
     */
    otherwise?: string | UrlRuleHandlerFn | TargetState | TargetStateDef;
    /**
     * Configures the `initial` rule, which chooses the state or URL to activate when the
     * application initially starts, and no other routes matched.
     *
     * See: [[UrlRulesApi.initial]].
     */
    initial?: string | UrlRuleHandlerFn | TargetState | TargetStateDef;
    /**
     * Sets [[UrlRouterProvider.deferIntercept]]
     */
    deferIntercept?: boolean;
    /**
     * Tells Angular to defer the first render until after the initial transition is complete.
     *
     * When `true`, adds an async `APP_INITIALIZER` which is resolved after any `onSuccess` or `onError`.
     * The initializer stops angular from rendering the root component until after the first transition completes.
     * This may prevent initial page flicker while the state is being loaded.
     *
     * Defaults to `false`
     */
    deferInitialRender?: boolean;
}
/**
 * UI-Router Module declarative configuration which can be passed to [[UIRouterModule.forChild]]
 */
interface StatesModule {
    /**
     * The module's UI-Router states
     *
     * This list of [[Ng2StateDeclaration]] objects will be registered with the [[StateRegistry]].
     */
    states?: Ng2StateDeclaration[];
    /**
     * A UI-Router Module's imperative configuration
     *
     * If a UI-Router Module needs to perform some configuration (such as registering
     * parameter types or Transition Hooks) a `configFn` should be supplied.
     * The function will be passed the `UIRouter` instance, the module's `Injector`,
     * and the module object.
     *
     * #### Example:
     * ```js
     * import { Injector } from "@angular/core";
     * import { UIRouter } from "@uirouter/angular";
     * import { requireAuthHook } from "./requireAuthHook";
     * import { MyService } from "./myService";
     *
     * export function configureMyModule(uiRouter: UIRouter, injector: Injector, module: StatesModule) {
     *   // Get UIRouter services off the UIRouter object
     *   let urlConfig = uiRouter.urlService.config;
     *   let transitionService = uiRouter.transitionService;
     *   uiRouter.trace.enable("TRANSITION");
     *
     *   transitionService.onBefore({ to: (state) => state.requiresAuth }, requireAuthHook);
     *
     *   // Create a slug type based on the string type
     *   let builtInStringType = urlConfig.type('string');
     *   let slugType = Object.assign({}, builtInStringType, { encode: (str) => str, decode: (str) => str });
     *   urlConfig.type('slug', slugType);
     *
     *   // Inject arbitrary services from DI using the Injector argument
     *   let myService: MyService = injector.get(MyService)
     *   myService.useFastMode();
     * }
     * ```
     *
     * ```js
     * @NgModule({
     *   imports: [
     *     UIRouterModule.forChild({ states: STATES, config: configureMyModule });
     *   ]
     * })
     * class MyModule {}
     * ```
     */
    config?: (uiRouterInstance: UIRouter, injector: Injector, module: StatesModule) => any;
}

/**
 * A function that returns an NgModule, or a promise for an NgModule
 *
 * #### Example:
 * ```js
 * export function loadFooModule() {
 *   return import('../foo/foo.module').then(result => result.FooModule);
 * }
 * ```
 */
type ModuleTypeCallback<T = unknown> = () => Type<T> | Promise<Type<T>>;
/**
 * Returns a function which lazy loads a nested module
 *
 * This is primarily used by the [[ng2LazyLoadBuilder]] when processing [[Ng2StateDeclaration.loadChildren]].
 *
 * It could also be used manually as a [[StateDeclaration.lazyLoad]] property to lazy load an `NgModule` and its state(s).
 *
 * #### Example:
 * ```ts
 * var futureState = {
 *   name: 'home.**',
 *   url: '/home',
 *   lazyLoad: loadNgModule(() => import('./home/home.module').then(result => result.HomeModule))
 * }
 * ```
 *
 *
 * @param moduleToLoad function which loads the NgModule code which should
 *    return a reference to  the `NgModule` class being loaded (or a `Promise` for it).
 *
 * @returns A function which takes a transition, which:
 * - Gets the Injector (scoped properly for the destination state)
 * - Loads and creates the NgModule
 * - Finds the "replacement state" for the target state, and adds the new NgModule Injector to it (as a resolve)
 * - Returns the new states array
 */
declare function loadNgModule<T>(moduleToLoad: ModuleTypeCallback<T>): (transition: Transition, stateObject: StateDeclaration) => Promise<LazyLoadResult>;
/**
 * Returns the module factory that can be used to instantiate a module
 *
 * For a Type<any> or Promise<Type<any>> this:
 * - Compiles the component type (if not running with AOT)
 * - Returns the NgModuleFactory resulting from compilation (or direct loading if using AOT) as a Promise
 *
 * @internal
 */
declare function loadModuleFactory<T>(moduleToLoad: ModuleTypeCallback<T>, ng2Injector: Injector): Promise<NgModuleRef<T>>;
/**
 * Apply the UI-Router Modules found in the lazy loaded module.
 *
 * Apply the Lazy Loaded NgModule's newly created Injector to the right state in the state tree.
 *
 * Lazy loading uses a placeholder state which is removed (and replaced) after the module is loaded.
 * The NgModule should include a state with the same name as the placeholder.
 *
 * Find the *newly loaded state* with the same name as the *placeholder state*.
 * The NgModule's Injector (and ComponentFactoryResolver) will be added to that state.
 * The Injector/Factory are used when creating Components for the `replacement` state and all its children.
 *
 * @internal
 */
declare function applyNgModule<T>(ng2Module: NgModuleRef<T>, parentInjector: Injector, lazyLoadState: StateDeclaration): LazyLoadResult;
/**
 * Returns the new dependency injection values from the Child Injector
 *
 * When a DI token is defined as multi: true, the child injector
 * can add new values for the token.
 *
 * This function returns the values added by the child injector,  and excludes all values from the parent injector.
 *
 * @internal
 */
declare function multiProviderParentChildDelta<T>(parent: Injector, child: Injector, token: InjectionToken<T>): RootModule[];
/**
 * A function that returns a Component, or a promise for a Component
 *
 * #### Example:
 * ```ts
 * export function loadFooComponent() {
 *   return import('../foo/foo.component').then(result => result.FooComponent);
 * }
 * ```
 */
type ComponentTypeCallback<T> = ModuleTypeCallback<T>;
/**
 * Returns a function which lazy loads a standalone component for the target state
 *
 * #### Example:
 * ```ts
 * var futureComponentState = {
 *   name: 'home',
 *   url: '/home',
 *   lazyLoad: loadComponent(() => import('./home.component').then(result => result.HomeComponent))
 * }
 * ```
 *
 * @param callback function which loads the Component code which should
 *    return a reference to  the `Component` class being loaded (or a `Promise` for it).
 *
 * @returns A function which takes a transition, stateObject, and:
 * - Loads a standalone component
 * - replaces the component configuration of the stateObject.
 * - Returns the new states array
 */
declare function loadComponent<T>(callback: ComponentTypeCallback<T>): (transition: Transition, stateObject: Ng2StateDeclaration) => Promise<LazyLoadResult>;
/**
 * Apply the lazy-loaded component to the stateObject.
 *
 * @internal
 * @param component reference to the component class
 * @param transition Transition object reference
 * @param stateObject target state configuration object
 *
 * @returns the new states array
 */
declare function applyComponent<T>(component: Type<T>, transition: Transition, stateObject: Ng2StateDeclaration): LazyLoadResult;

/**
 * The StateDeclaration object is used to define a state or nested state.
 * It should be registered with the [[StateRegistry]].
 *
 * #### Example:
 * ```js
 * import {FoldersComponent} from "./folders";
 *
 * export function getAllFolders(FolderService) {
 *   return FolderService.list();
 * }
 *
 * // StateDeclaration object
 * export let foldersState = {
 *   name: 'folders',
 *   url: '/folders',
 *   component: FoldersComponent,
 *   resolve: [
 *     { token: 'allfolders', deps: [FolderService], resolveFn: getAllFolders }
 *   ]
 * }
 * ```
 */
interface Ng2StateDeclaration<T = unknown> extends StateDeclaration, Ng2ViewDeclaration<T> {
    /**
     * An optional object used to define multiple named views.
     *
     * Each key is the name of a view, and each value is a [[Ng2ViewDeclaration]].
     * Unnamed views are internally renamed to `$default`.
     *
     * A view's name is used to match an active `<ui-view>` directive in the DOM.  When the state
     * is entered, the state's views are activated and then matched with active `<ui-view>` directives:
     *
     * - The view's name is processed into a ui-view target:
     *   - ui-view address: an address to a ui-view
     *   - state anchor: the state to anchor the address to
     *
     *  Examples:
     *
     *  Targets three named ui-views in the parent state's template
     *
     * #### Example:
     * ```js
     * views: {
     *   header: {component: HeaderComponent},
     *   body: {component: BodyComponent},
     *   footer: {component: FooterComponent}
     * }
     * ```
     *
     * #### Example:
     * ```js
     * // Targets named ui-view="header" in the template of the ancestor state 'top'
     * // and the named `ui-view="body" from the parent state's template.
     * views: {
     *   'header@top': {component: MsgHeaderComponent},
     *   'body': {component: MessagesComponent}
     * }
     * ```
     *
     * ## View targeting details
     *
     * There are a few styles of view addressing/targeting.  The most common is a simple `ui-view` name
     *
     *
     * #### Simple ui-view name
     *
     * Addresses without an `@` are anchored to the parent state.
     *
     * #### Example:
     * ```js
     * // target the `<div ui-view='foo'></div>` created in the parent state's view
     * views: { foo: {...} }
     * ```
     *
     * #### View name anchored to a state
     *
     * You can anchor the `ui-view` name to a specific state by including an `@`
     *
     * @example
     *
     * ```js
     *
     * // target the `<div ui-view='foo'></div>` which was created in a
     * // view owned by the state `bar.baz`
     * views: { 'foo@bar.baz': {...} }
     * ```
     *
     * #### Absolute addressing
     *
     * You can address a `ui-view` absolutely, using dotted notation, by prefixing the address with a `!`.  Dotted
     * addresses map to the hierarchy of `ui-view`s active in the DOM:
     *
     * #### Example:
     * ```js
     * // absolutely target the `<div ui-view='nested'></div>`... which was created
     * // in the unnamed/$default root `<ui-view></ui-view>`
     * views: { '!$default.nested': {...} }
     * ```
     *
     * #### Relative addressing
     *
     * Absolute addressing is actually relative addressing, only anchored to the unnamed root state.  You can also use
     * relative addressing anchored to any state, in order to target a target deeply nested `ui-views`:
     *
     * #### Example:
     * ```js
     *
     * // target the `<div ui-view='bar'></div>`... which was created inside the
     * // `<div ui-view='bar'></div>`... which was created inside the parent state's template.
     * views: { 'foo.bar': {...} }
     * ```
     *
     * #### Example:
     * ```js
     * // target the `<div ui-view='bar'></div>`...  which was created in
     * // `<div ui-view='foo'></div>`... which was created in a template crom the state `baz.qux`
     * views: { 'foo.bar@baz.qux': {...} }
     *
     * ---
     *
     * ## State `component:` and `views:` incompatiblity
     *
     * If a state has a `views` object, the state-level `component:` property is ignored.  Therefore,
     * if _any view_ for a state is declared in the `views` object, then _all of the state's views_ must be defined in
     * the `views` object.
     */
    views?: {
        [key: string]: Ng2ViewDeclaration;
    };
    /**
     * A function used to lazy load an `NgModule`
     *
     * The `loadChildren` property should be added to a Future State (a lazy loaded state whose name ends in `.**`).
     * The Future State is a placeholder for a tree of states that will be lazy loaded in the future.
     *
     * When the future state is activated, the `loadChildren` property should lazy load an `NgModule`
     * which contains the fully loaded states.
     * The `NgModule` should contain the fully loaded states which will be registered.
     * The fully loaded states will replace the temporary future states once lazy loading is complete.
     *
     * #### Example:
     * ```js
     * var futureState = {
     *   name: 'home.**',
     *   url: '/home',
     *   loadChildren: () => import('./home/home.module')
     *       .then(result => result.HomeModule);
     * }
     * ```
     */
    loadChildren?: ModuleTypeCallback<T>;
    /**
     * A function used to lazy load a `Component`.
     *
     * When the state is activate the `loadComponent` property should lazy load a standalone `Component`
     * and use it to render the view of the state
     *
     * ### Example:
     * ```ts
     * var homeState = {
     *    name: 'home',
     *    url: '/home',
     *    loadComponent: () => import('./home/home.component')
     *        .then(result => result.HomeComponent)
     * }
     * ```
     */
    loadComponent?: ComponentTypeCallback<T>;
}
interface Ng2ViewDeclaration<T = unknown> extends _ViewDeclaration {
    /**
     * The `Component` class to use for this view.
     *
     * A property of [[Ng2StateDeclaration]] or [[Ng2ViewDeclaration]]:
     *
     * ### The component class which will be used for this view.
     *
     * #### Example:
     * ```js
     * .state('profile', {
     *   // Use the <my-profile></my-profile> component for the Unnamed view
     *   component: MyProfileComponent,
     * }
     *
     * .state('messages', {
     *   // use the <nav-bar></nav-bar> component for the view named 'header'
     *   // use the <message-list></message-list> component for the view named 'content'
     *   views: {
     *     header: { component: NavBar },
     *     content: { component: MessageList }
     *   }
     * }
     *
     * // Named views shorthand:
     * // Inside a "views:" block, a Component class (NavBar) is shorthand for { component: NavBar }
     * .state('contacts', {
     *   // use the <nav-bar></nav-bar> component for the view named 'header'
     *   // use the <contact-list></contact-list> component for the view named 'content'
     *   views: {
     *     header: NavBar,
     *     content: ContactList
     *   }
     * }
     * ```
     *
     * ### Accessing Resolve Data
     *
     * The component can access the Transition's [[Ng2StateDeclaration.resolve]] data in one of two ways:
     *
     * 1) Using Dependency Injection in the component constructor
     *
     * (using Typescript)
     * ```js
     * class MyComponent {
     *   constructor(@Inject("myResolveData") public resolveValueA, resolveValueB: public SomeClass) {
     *   }
     * }
     * ```
     *
     * (using ES6/7/babel)
     * ```js
     * class MyComponent {
     *   static get parameters() {
     *     return [["myResolveData"], [MyResolveClass]];
     *   }
     *   constructor(resolveValueA, resolveValueB) {
     *     this.resolveValueA = resolveValueA;
     *     this.resolveValueB = resolveValueB;
     *   }
     * }
     * ```
     *
     * See also: https://github.com/shuhei/babel-plugin-angular2-annotations
     *
     * 2) Using a component input
     *
     * Note: To bind a resolve to a component input, the resolves must `provide:` a string value
     *
     * ```js
     * @Component() {
     *   inputs: ['resolveValueA']
     * }
     * class MyComponent {
     *   myResolveValueA;
     *   @Input() resolveValueB;
     *   @Input("resolveValueC") resolveValueC;
     *
     *   constructor() {
     *   }
     * }
     * ```
     */
    component?: Type<T>;
    /**
     * An object which maps `resolve` keys to [[component]] `bindings`.
     *
     * A property of [[Ng2StateDeclaration]] or [[Ng2ViewDeclaration]]:
     *
     * When using a [[component]] declaration (`component: MyComponent`), each input binding for the component is supplied
     * data from a resolve of the same name, by default.  You may supply data from a different resolve name by mapping it here.
     * This might be useful if you want to reuse the same resolve value with various components with different input binding names.
     *
     * Each key in this object is the name of one of the component's input bindings.
     * Each value is the name of the resolve that should be provided to that binding.
     *
     * Any component bindings that are omitted from this map get the default behavior of mapping to a resolve of the * same name.
     *
     * #### Example:
     * ```js
     * export const fooState = {
     *   name: 'foo',
     *   component: MyComponent,
     *   resolve: [
     *     { token: 'users', deps: [UserService], resolveFn: getUsers }
     *   ],
     *   bindings: {
     *     resolveData: 'users'
     *   }
     * }
     *
     * export function getUsers(userservice) {
     *   return userservice.getUsers();
     * }
     *
     * @Component() {
     * }
     * class MyComponent {
     *   @Input() resolveData;
     *   constructor() { }
     * }
     * ```
     *
     */
    bindings?: {
        [key: string]: string;
    };
}
interface UiOnParamsChanged {
    /**
     * A UI-Router view has an Angular `Component` (see [[Ng2ViewDeclaration.component]]).
     * The `Component` may define component-level hooks which UI-Router will call at the appropriate times.
     * These callbacks are similar to Transition Hooks ([[IHookRegistry]]), but are only called if the view/component is currently active.
     *
     * The uiOnParamsChanged callback is called when parameter values change.
     *
     * This callback is used to respond dynamic parameter values changing.
     * It is called when a transition changed one or more dynamic parameter values,
     * and the routed component was not destroyed.
     *
     * It receives two parameters:
     *
     * - An object with (only) changed parameter values.
     *   The keys are the parameter names and the values are the new parameter values.
     * - The [[Transition]] which changed the parameter values.
     *
     * #### Example:
     * ```js
     * @Component({
     *   template: '<input type="text">'
     * })
     * class MyComponent {
     *   uiOnParamsChanged(newParams: { [paramName: string]: any }, trans: Transition) {
     *     Object.keys(newParams).forEach(paramName => {
     *       console.log(`${paramName} changed to ${newParams[paramName]}`)
     *     });
     *   }
     * }
     * ```
     */
    uiOnParamsChanged(newParams: {
        [paramName: string]: any;
    }, trans?: Transition): void;
}
interface UiOnExit {
    /**
     * A UI-Router view has an Angular `Component` (see [[Ng2ViewDeclaration.component]]).
     * The `Component` may define component-level hooks which UI-Router will call at the appropriate times.
     * These callbacks are similar to Transition Hooks ([[IHookRegistry]]), but are only called if the view/component is currently active.
     *
     * The uiCanExit callback is called when the routed component's state is about to be exited.
     *
     * The callback can be used to cancel or alter the new Transition that would otherwise exit the component's state.
     *
     * This callback is used to inform a view that it is about to be exited, due to a new [[Transition]].
     * The callback can ask for user confirmation, and cancel or alter the new Transition.  The callback should
     * return a value, or a promise for a value.  If a promise is returned, the new Transition waits until the
     * promise settles.
     *
     * Called when:
     * - The component is still active inside a `ui-view`
     * - A new Transition is about to run
     * - The new Transition will exit the view's state
     *
     * Called with:
     * - The `Transition` that is about to exit the component's state
     *
     * #### Example:
     * ```js
     * @Component({
     *   template: '<input type="text">'
     * })
     * class MyComponent {
     *   dirty = true;
     *
     *   constructor(public confirmService: confirmService) {
     *
     *   }
     *
     *   uiCanExit(newTransition: Transition) {
     *     if (this.dirty && newTransition.to() !== 'logout') {
     *       return this.confirmService.confirm("Exit without saving changes?");
     *     }
     *   }
     * }
     * ```
     *
     * @return a hook result which may cancel or alter the pending Transition (see [[HookResult]])
     */
    uiCanExit(newTransition?: Transition): HookResult;
}
/**
 * The shape of a controller for a view (and/or component), defining the controller callbacks.
 *
 * A UI-Router view has an Angular `Component` (see [[Ng2ViewDeclaration.component]]).
 * The `Component` may define component-level hooks which UI-Router will call at the appropriate times.
 * These callbacks are similar to Transition Hooks ([[IHookRegistry]]), but are only called if the view/component is currently active.
 *
 * This interface defines the UI-Router component callbacks.
 *
 * @deprecated This interface has been replaced by UiOnExit and UiOnParamsChanged.
 */
interface Ng2Component extends Component {
    /**
     * This callback is called when parameter values change
     *
     * This callback is used to respond dynamic parameter values changing.
     * It is called when a transition changed one or more dynamic parameter values,
     * and the routed component was not destroyed.
     *
     * It receives two parameters:
     *
     * - An object with (only) changed parameter values.
     *   The keys are the parameter names and the values are the new parameter values.
     * - The [[Transition]] which changed the parameter values.
     *
     * #### Example:
     * ```js
     * @Component({
     *   template: '<input type="text">'
     * })
     * class MyComponent {
     *   uiOnParamsChanged(newParams: { [paramName: string]: any }, trans: Transition) {
     *     Object.keys(newParams).forEach(paramName => {
     *       console.log(`${paramName} changed to ${newParams[paramName]}`)
     *     });
     *   }
     * }
     * ```
     */
    uiOnParamsChanged?(newParams: {
        [paramName: string]: any;
    }, trans?: Transition): void;
    /**
     * This callback is called when the routed component's state is about to be exited.
     *
     * The callback can be used to cancel or alter the new Transition that would otherwise exit the component's state.
     *
     * This callback is used to inform a view that it is about to be exited, due to a new [[Transition]].
     * The callback can ask for user confirmation, and cancel or alter the new Transition.  The callback should
     * return a value, or a promise for a value.  If a promise is returned, the new Transition waits until the
     * promise settles.
     *
     * Called when:
     * - The component is still active inside a `ui-view`
     * - A new Transition is about to run
     * - The new Transition will exit the view's state
     *
     * Called with:
     * - The `Transition` that is about to exit the component's state
     *
     * #### Example:
     * ```js
     * @Component({
     *   template: '<input type="text">'
     * })
     * class MyComponent {
     *   dirty = true;
     *
     *   constructor(public confirmService: confirmService) {
     *
     *   }
     *
     *   uiCanExit(newTransition: Transition) {
     *     if (this.dirty && newTransition.to() !== 'logout') {
     *       return this.confirmService.confirm("Exit without saving changes?");
     *     }
     *   }
     * }
     * ```
     *
     * @return a hook result which may cancel or alter the pending Transition (see [[HookResult]])
     */
    uiCanExit?(newTransition?: Transition): HookResult;
}

/**
 * # UI-Router for Angular (v2+)
 *
 * - [@uirouter/angular home page](https://ui-router.github.io/ng2)
 * - [tutorials](https://ui-router.github.io/tutorial/ng2/helloworld)
 * - [quick start repository](http://github.com/ui-router/quickstart-ng2)
 *
 * Getting started:
 *
 * - Use npm. Add a dependency on latest `@uirouter/angular`
 * - Import UI-Router classes directly from `"@uirouter/angular"`
 *
 * ```js
 * import {StateRegistry} from "@uirouter/angular";
 * ```
 *
 * - Create application states (as defined by [[Ng2StateDeclaration]]).
 *
 * ```js
 * export let state1: Ng2StateDeclaration = {
 *   name: 'state1',
 *   component: State1Component,
 *   url: '/one'
 * }
 *
 * export let state2: Ng2StateDeclaration = {
 *   name: 'state2',
 *   component: State2Component,
 *   url: '/two'
 * }
 * ```
 *
 * - Import a [[UIRouterModule.forChild]] module into your feature `NgModule`s.
 *
 * ```js
 * @ NgModule({
 *   imports: [
 *     SharedModule,
 *     UIRouterModule.forChild({ states: [state1, state2 ] })
 *   ],
 *   declarations: [
 *     State1Component,
 *     State2Component,
 *   ]
 * })
 * export class MyFeatureModule {}
 * ```
 *
 * - Import a [[UIRouterModule.forRoot]] module into your application root `NgModule`
 * - Either bootstrap a [[UIView]] component, or add a `<ui-view></ui-view>` viewport to your root component.
 *
 * ```js
 * @ NgModule({
 *   imports: [
 *     BrowserModule,
 *     UIRouterModule.forRoot({ states: [ homeState ] }),
 *     MyFeatureModule,
 *   ],
 *   declarations: [
 *     HomeComponent
 *   ]
 *   bootstrap: [ UIView ]
 * })
 * class RootAppModule {}
 *
 * browserPlatformDynamic.bootstrapModule(RootAppModule);
 * ```
 *
 * - Optionally specify a configuration class [[ChildModule.configClass]] for any module
 * to perform any router configuration during bootstrap or lazyload.
 * Pass the class to [[UIRouterModule.forRoot]] or [[UIRouterModule.forChild]].
 *
 * ```js
 * import {UIRouter} from "@uirouter/angular";
 *
 * @ Injectable()
 * export class MyUIRouterConfig {
 *   // Constructor is injectable
 *   constructor(uiRouter: UIRouter) {
 *     uiRouter.urlMatcherFactory.type('datetime', myDateTimeParamType);
 *   }
 * }
 * ```
 */

/**
 * This is a factory function for a UIRouter instance
 *
 * Creates a UIRouter instance and configures it for Angular, then invokes router bootstrap.
 * This function is used as an Angular `useFactory` Provider.
 */
declare function uiRouterFactory(locationStrategy: LocationStrategy, rootModules: RootModule[], modules: StatesModule[], injector: Injector): UIRouter;
declare function appInitializer(router: UIRouter): () => void;
declare function parentUIViewInjectFactory(r: StateRegistry): ParentUIViewInject;
declare const _UIROUTER_INSTANCE_PROVIDERS: Provider[];
declare function fnStateService(r: UIRouter): StateService;
declare function fnTransitionService(r: UIRouter): TransitionService;
declare function fnUrlMatcherFactory(r: UIRouter): UrlMatcherFactory;
declare function fnUrlRouter(r: UIRouter): UrlRouter;
declare function fnUrlService(r: UIRouter): UrlService;
declare function fnViewService(r: UIRouter): ViewService;
declare function fnStateRegistry(r: UIRouter): StateRegistry;
declare function fnGlobals(r: any): any;
declare const _UIROUTER_SERVICE_PROVIDERS: Provider[];
/**
 * The UI-Router providers, for use in your application bootstrap
 *
 * @deprecated use [[UIRouterModule.forRoot]]
 */
declare const UIROUTER_PROVIDERS: Provider[];

/**
 * This is a [[StateBuilder.builder]] function for ngModule lazy loading in Angular.
 *
 * When the [[StateBuilder]] builds a [[State]] object from a raw [[StateDeclaration]], this builder
 * decorates the `lazyLoad` property for states that have a [[Ng2StateDeclaration.ngModule]] declaration.
 *
 * If the state has a [[Ng2StateDeclaration.ngModule]], it will create a `lazyLoad` function
 * that in turn calls `loadNgModule(loadNgModuleFn)`.
 *
 * #### Example:
 * A state that has a `ngModule`
 * ```js
 * var decl = {
 *   ngModule: () => import('./childModule.ts')
 * }
 * ```
 * would build a state with a `lazyLoad` function like:
 * ```js
 * import { loadNgModule } from "@uirouter/angular";
 * var decl = {
 *   lazyLoad: loadNgModule(() => import('./childModule.ts')
 * }
 * ```
 *
 * If the state has both a `ngModule:` *and* a `lazyLoad`, then the `lazyLoad` is run first.
 *
 * #### Example:
 * ```js
 * var decl = {
 *   lazyLoad: () => import('third-party-library'),
 *   ngModule: () => import('./childModule.ts')
 * }
 * ```
 * would build a state with a `lazyLoad` function like:
 * ```js
 * import { loadNgModule } from "@uirouter/angular";
 * var decl = {
 *   lazyLoad: () => import('third-party-library')
 *       .then(() => loadNgModule(() => import('./childModule.ts'))
 * }
 * ```
 *
 */
declare function ng2LazyLoadBuilder(state: StateObject, _parent: BuilderFunction): (transition: _uirouter_core.Transition, stateObject: _uirouter_angular.Ng2StateDeclaration) => Promise<_uirouter_core.LazyLoadResult>;

/**
 * This is a [[StateBuilder.builder]] function for Angular `views`.
 *
 * When the [[StateBuilder]] builds a [[State]] object from a raw [[StateDeclaration]], this builder
 * handles the `views` property with logic specific to @uirouter/angular.
 *
 * If no `views: {}` property exists on the [[StateDeclaration]], then it creates the `views` object and
 * applies the state-level configuration to a view named `$default`.
 */
declare function ng2ViewsBuilder(state: StateObject): {
    [key: string]: Ng2ViewDeclaration<unknown>;
};
declare class Ng2ViewConfig implements ViewConfig {
    path: PathNode[];
    viewDecl: Ng2ViewDeclaration;
    $id: number;
    loaded: boolean;
    constructor(path: PathNode[], viewDecl: Ng2ViewDeclaration);
    load(): Promise<this>;
}

declare function applyModuleConfig(uiRouter: UIRouter, injector: Injector, module?: StatesModule): StateObject[];
declare function applyRootModuleConfig(uiRouter: UIRouter, injector: Injector, module: RootModule): void;

/**
 * Sets up providers necessary to enable UI-Router for the application. Intended as a replacement
 * for [[UIRouterModule.forRoot]] in newer standalone based applications.
 *
 * Example:
 * ```js
 * const routerConfig = {
 *   otherwise: '/home',
 *   states: [homeState, aboutState]
 * };
 *
 * const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideZoneChangeDetection({ eventCoalescing: true }),
 *     provideUIRouter(routerConfig)
 *   ]
 * };
 *
 * bootstrapApplication(AppComponent, appConfig)
 *  .catch((err) => console.error(err));
 * ```
 *
 * @param config declarative UI-Router configuration
 * @returns an `EnvironmentProviders` which provides the [[UIRouter]] singleton instance
 */
declare function provideUIRouter(config?: RootModule): EnvironmentProviders;

export { AnchorUISref, Ng2ViewConfig, UIROUTER_DIRECTIVES, UIROUTER_MODULE_TOKEN, UIROUTER_PROVIDERS, UIROUTER_ROOT_MODULE, UIROUTER_STATES, UIRouterModule, UISref, UISrefActive, UISrefStatus, UIView, _UIROUTER_DIRECTIVES, _UIROUTER_INSTANCE_PROVIDERS, _UIROUTER_SERVICE_PROVIDERS, appInitializer, applyComponent, applyModuleConfig, applyNgModule, applyRootModuleConfig, fnGlobals, fnStateRegistry, fnStateService, fnTransitionService, fnUrlMatcherFactory, fnUrlRouter, fnUrlService, fnViewService, loadComponent, loadModuleFactory, loadNgModule, locationStrategy, makeChildProviders, makeRootProviders, multiProviderParentChildDelta, ng2LazyLoadBuilder, ng2ViewsBuilder, onTransitionReady, parentUIViewInjectFactory, provideUIRouter, uiRouterFactory };
export type { ComponentTypeCallback, ModuleTypeCallback, Ng2Component, Ng2StateDeclaration, Ng2ViewDeclaration, ParentUIViewInject, RootModule, SrefStatus, StatesModule, UiOnExit, UiOnParamsChanged };

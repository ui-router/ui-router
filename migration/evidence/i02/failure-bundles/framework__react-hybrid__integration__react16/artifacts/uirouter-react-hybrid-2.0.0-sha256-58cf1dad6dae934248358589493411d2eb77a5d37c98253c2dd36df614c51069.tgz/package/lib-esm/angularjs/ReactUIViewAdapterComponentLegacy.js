import * as ReactDOM from 'react-dom';
import { registerReactUIViewAdapter } from './ReactUIViewAdapterComponent.base';
// React 16/17 adapter using legacy ReactDOM.render API
var legacyReactDOM = ReactDOM;
var adapter = {
    render: function (element, container) {
        legacyReactDOM.render(element, container);
    },
    unmount: function (container) {
        legacyReactDOM.unmountComponentAtNode(container);
    },
};
registerReactUIViewAdapter(adapter);
//# sourceMappingURL=ReactUIViewAdapterComponentLegacy.js.map
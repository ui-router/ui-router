var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
import { padString } from '@uirouter/core';
export var debugLog = function (angularOrReact, component, id, method, message) {
    var args = [];
    for (var _i = 5; _i < arguments.length; _i++) {
        args[_i - 5] = arguments[_i];
    }
    if (window && window['debugReactHybrid'] !== true)
        return;
    console.log.apply(console, __spreadArray(["".concat(padString(12, angularOrReact), " ").concat(padString(40, "".concat(component, "[").concat(id, "]")), " ").concat(padString(35, "".concat(method, ":")), " ").concat(message)], args, false));
};
//# sourceMappingURL=debug.js.map